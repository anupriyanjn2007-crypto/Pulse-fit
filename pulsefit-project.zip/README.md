# PULSEFIT — AI-Powered Personal Health & Fitness Tracking Platform

> **PULSEFIT** is a production-grade, privacy-first personal health and fitness web application engineered with Next.js 15 (App Router), Supabase PostgreSQL with Row Level Security (RLS), Google Gemini AI intelligence, hardware DeviceMotion sensor tracking, and native support for regional Indian and Tamil Nadu whole food nutrition.

---

## 🌟 Key Capabilities

1. **Precision Biometrics & Age-Aware BMI Screening**
   - Live BMI calculation: $\text{BMI} = \text{weight} / (\text{height}/100)^2$.
   - **Pediatric Safety**: Adult BMI categories and weight-loss goals are strictly disabled for minors (under 18).
   - Historical snapshots are immutable to prevent retroactive data distortion.

2. **Accurate Multi-Source Step Tracking**
   - Source Priority: Android Health Connect $\rightarrow$ Wearables $\rightarrow$ Live Browser DeviceMotion $\rightarrow$ Manual Input.
   - Live 3D accelerometer magnitude peak detection (`sqrt(x^2 + y^2 + z^2) > 11.5 m/s^2` with ~320ms debounce).
   - Biomechanical stride length calibration ($\text{height} \times 0.415$).
   - Explicit origin tags on all records to prevent confusion between sensor-measured and manual inputs.

3. **Advanced 4-Phase Daily Checklist Engine**
   - Time-of-day habit buckets: **Morning**, **Afternoon**, **Evening**, **Night**.
   - Timezone-aware daily auto-generation with persistent historical records.
   - Constructive non-shaming philosophy for missed habits.
   - Interactive checkboxes with real-time percentage progress score.

4. **AI Personal Fitness Coach**
   - Powered by Google Gemini 2.5 Flash via `@google/genai` on server API routes.
   - **Natural Language Logging**: Type or say *"I walked 4,000 steps"* or *"Drank 500 ml water"*; Coach parses the intent and presents a confirmation modal before logging.
   - **Clinical Guardrails**: Refuses medical diagnoses, refuses crash diets, warns against calorie restriction for underweight/minors, and flags emergency cardiac/respiratory symptoms.

5. **Regional Indian & Tamil Nadu Nutrition Engine**
   - Built-in database of traditional whole foods: Steamed Idli with Sambar, Ragi Kali with Keerai Kulambu, Kambu Koozh, Sundal, Meen Kulambu, Neer Mor, and Egg Podimas.
   - Clear disclosure that macro/calorie metrics are scientific approximations, not laboratory assays.

6. **Fortified Database Security (23 Relational Tables)**
   - Every table is protected with Supabase Row Level Security (RLS) enforcing `auth.uid() = user_id`.
   - Zero advertising trackers, no public leaderboards, and no cross-user data leakage.
   - Full data export in JSON/CSV and one-click permanent account purging.

---

## 🏗️ Technology Architecture

- **Frontend**: Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS, Lucide Icons, Framer Motion, Recharts, Canvas-Confetti.
- **Backend**: Next.js Server-Side API Routes, Edge Runtime, Supabase Server Client (`@supabase/ssr`).
- **Database**: Supabase PostgreSQL with 23 tables, foreign keys with `ON DELETE CASCADE`, indexes, and strict RLS policies.
- **AI Service**: Google Gemini API via official `@google/genai` SDK with rule-based fallback and medical safety filters.
- **Mobile**: Progressive Web Application (PWA) with manifest, installability, and Capacitor Android companion setup for Health Connect.

---

## 📂 Project Directory Structure

```
pulsefit/
├── public/
│   ├── favicon.ico
│   └── manifest.json                # PWA configuration
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   │   ├── auth/signup/page.tsx
│   │   │   ├── auth/login/page.tsx
│   │   │   ├── auth/verify/page.tsx
│   │   │   └── auth/forgot-password/page.tsx
│   │   ├── (onboarding)/
│   │   │   └── onboarding/page.tsx   # 6-step personalized onboarding
│   │   ├── (dashboard)/
│   │   │   ├── layout.tsx            # Sidebar + Header + Mobile nav wrapper
│   │   │   ├── dashboard/page.tsx    # Sporty athletic dashboard
│   │   │   ├── activity/page.tsx     # Exercise bouts & RPE logging
│   │   │   ├── steps/page.tsx        # Live accelerometer & manual step tracker
│   │   │   ├── body/page.tsx         # BMI screening & biometric history
│   │   │   ├── weight/page.tsx       # Weight progression & sustainable pacing
│   │   │   ├── workouts/page.tsx     # Workout planner & interactive runner with timers
│   │   │   ├── exercises/page.tsx    # Filterable exercise library & technique cues
│   │   │   ├── nutrition/page.tsx    # Tamil Nadu & Indian nutrition diary
│   │   │   ├── water/page.tsx        # Hydration progress & beverage logger
│   │   │   ├── sleep/page.tsx        # Nightly sleep & daily wellness check-in
│   │   │   ├── checklist/page.tsx    # 4-phase daily habit checklist system
│   │   │   ├── coach/page.tsx        # AI Coach chat & natural language logger
│   │   │   ├── analytics/page.tsx    # Longitudinal charts, CSV & print reports
│   │   │   ├── calendar/page.tsx     # Monthly schedule & streak calendar
│   │   │   ├── achievements/page.tsx # Badges, streaks & milestone celebration
│   │   │   ├── notifications/page.tsx# Habit reminder schedules & browser push
│   │   │   ├── devices/page.tsx      # Sensor & Health Connect hardware bridge
│   │   │   ├── privacy/page.tsx      # RLS transparency, data export & deletion
│   │   │   └── settings/page.tsx     # Account settings & target customization
│   │   ├── api/
│   │   │   ├── coach/route.ts        # Server-side Gemini AI coach endpoint
│   │   │   └── export/route.ts       # Secure user data export endpoint
│   │   ├── globals.css               # Athletic theme tokens & print styling
│   │   ├── layout.tsx                # Root layout with PulseFitProvider
│   │   └── page.tsx                  # High-converting sporty landing page
│   ├── components/
│   │   ├── ui/                       # Button, Card, Input, Modal, Badge, Progress
│   │   └── layout/                   # Sidebar, Header, MobileNav
│   ├── lib/
│   │   ├── ai/                       # Gemini SDK service & safety filters
│   │   ├── calculations/             # BMI formulas, stride metrics, calories
│   │   ├── data/                     # Exercise library, Tamil Nadu foods, checklists
│   │   ├── store/                    # Unified client state with Supabase sync & offline mode
│   │   └── supabase/                 # Browser & server Supabase clients
│   └── types/                        # Comprehensive TypeScript domain types
├── supabase/
│   └── migrations/
│       └── 20261106000000_pulsefit_complete_schema.sql # Full 23 tables + RLS
├── capacitor.config.json             # Capacitor companion configuration
└── .env.example                      # Environment variables reference
```

---

## ⚡ Quick Start & Local Development

### 1. Prerequisites
- Node.js 18.17+ or Node.js 20+ (tested on Node v24.20.0).
- npm 9+ or 11+.

### 2. Installation
```bash
# Navigate to the project directory
cd pulsefit

# Install dependencies (if not already installed)
npm install --legacy-peer-deps
```

### 3. Environment Setup
Create a `.env.local` file by copying the template:
```bash
cp .env.example .env.local
```

Populate the keys:
- `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase Project URL.
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase Public Anon Key.
- `GEMINI_API_KEY`: Your Google Gemini API Key from Google AI Studio.

*(Note: PULSEFIT automatically features an out-of-the-box local demo mode if credentials are not yet supplied, allowing immediate full-featured UI testing and inspection!)*

### 4. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🗄️ Database Setup (Supabase)

1. Create a project at [supabase.com](https://supabase.com).
2. Go to **SQL Editor** in the Supabase Dashboard.
3. Open `supabase/migrations/20261106000000_pulsefit_complete_schema.sql` from this repository.
4. Copy and execute the SQL script. It will automatically:
   - Create all 23 relational tables.
   - Enable Row Level Security (RLS) on every table.
   - Apply user isolation policies (`auth.uid() = user_id`).
   - Create triggers for automatic user profile generation and timestamp updates.

---

## 🚀 Vercel Deployment

1. Push your repository to GitHub / GitLab.
2. In the Vercel Dashboard, click **Add New Project** and import the repository.
3. Under **Environment Variables**, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `GEMINI_API_KEY`
   - `NEXT_PUBLIC_APP_URL`
4. Click **Deploy**. Vercel will build the Next.js App Router project cleanly.

---

## 📱 Mobile PWA & Android Companion

- **Installable PWA**: Open PULSEFIT in Chrome on Android or Safari on iOS and select *"Install App"* or *"Add to Home Screen"*.
- **Android Health Connect**: The project includes `capacitor.config.json` configured with Android Health permissions (`android.permission.health.READ_STEPS`, `READ_DISTANCE`, `READ_TOTAL_CALORIES_BURNED`) ready to build using Capacitor CLI:
  ```bash
  npx cap add android
  npx cap sync
  ```

---

## 🛡️ Privacy & Medical Ethics Statement

PULSEFIT is an athletic tracking and wellness education software platform. It is not intended for the diagnosis, cure, mitigation, treatment, or prevention of any disease or physiological disorder. All calorie expenditures, distances, and nutritional compositions are estimates. Always consult a qualified healthcare provider before initiating new intense exercise regimens or dietary alterations.
