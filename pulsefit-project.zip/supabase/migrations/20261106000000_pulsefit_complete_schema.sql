-- ====================================================================
-- PULSEFIT MASTER DATABASE SCHEMA & ROW LEVEL SECURITY POLICIES
-- Target: Supabase PostgreSQL (auth.users integration)
-- Version: 1.0.0
-- ====================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. HELPER TRIGGER FOR UPDATED_AT
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ====================================================================
-- TABLE 1: profiles
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL DEFAULT '',
    dob DATE,
    age INT,
    country TEXT DEFAULT 'US',
    preferred_language TEXT DEFAULT 'en',
    timezone TEXT DEFAULT 'UTC',
    gender TEXT,
    avatar_url TEXT,
    onboarding_completed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 2: user_preferences
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    exercise_preferences TEXT[] DEFAULT '{}',
    equipment_available TEXT[] DEFAULT '{}',
    health_limitations TEXT DEFAULT '',
    dietary_type TEXT DEFAULT 'omnivore',
    cuisine_preferences TEXT[] DEFAULT '{}',
    budget_friendly BOOLEAN DEFAULT TRUE,
    allergies TEXT[] DEFAULT '{}',
    meal_schedule JSONB DEFAULT '{"breakfast": "08:00", "lunch": "13:00", "snack": "17:00", "dinner": "20:00"}',
    daily_available_minutes INT DEFAULT 45,
    workout_location_preference TEXT DEFAULT 'home',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_user_preferences_user UNIQUE (user_id)
);

-- ====================================================================
-- TABLE 3: fitness_goals
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.fitness_goals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    primary_goal TEXT NOT NULL DEFAULT 'general_fitness',
    secondary_goals TEXT[] DEFAULT '{}',
    target_weight_kg NUMERIC(5, 2),
    target_date DATE,
    weekly_workout_target INT DEFAULT 4,
    daily_step_goal INT DEFAULT 8000,
    daily_water_goal_ml INT DEFAULT 2500,
    daily_sleep_goal_hrs NUMERIC(3, 1) DEFAULT 8.0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_fitness_goals_user UNIQUE (user_id)
);

-- ====================================================================
-- TABLE 4: body_measurements
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.body_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    measured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    weight_kg NUMERIC(5, 2) NOT NULL,
    height_cm NUMERIC(5, 2) NOT NULL,
    bmi NUMERIC(4, 1) NOT NULL,
    bmi_category TEXT NOT NULL,
    waist_cm NUMERIC(5, 2),
    body_fat_pct NUMERIC(4, 1),
    is_minor BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 5: daily_health_logs
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.daily_health_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    total_steps INT NOT NULL DEFAULT 0,
    distance_meters NUMERIC(8, 2) NOT NULL DEFAULT 0,
    active_minutes INT NOT NULL DEFAULT 0,
    active_calories INT NOT NULL DEFAULT 0,
    water_ml INT NOT NULL DEFAULT 0,
    sleep_minutes INT NOT NULL DEFAULT 0,
    checklist_completion_pct INT NOT NULL DEFAULT 0,
    wellness_score INT DEFAULT 75,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_daily_health_logs_user_date UNIQUE (user_id, date)
);

-- ====================================================================
-- TABLE 6: step_records
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.step_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    recorded_date DATE NOT NULL,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    step_count INT NOT NULL,
    distance_meters NUMERIC(8, 2) NOT NULL DEFAULT 0,
    active_seconds INT NOT NULL DEFAULT 0,
    source TEXT NOT NULL CHECK (source IN ('health_connect', 'device_motion', 'wearable', 'manual')),
    source_device TEXT,
    external_sync_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 7: activity_sessions
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.activity_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    activity_type TEXT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL,
    ended_at TIMESTAMPTZ,
    duration_minutes INT NOT NULL,
    calories_burned INT,
    avg_heart_rate INT,
    perceived_exertion INT CHECK (perceived_exertion BETWEEN 1 AND 10),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 8: workout_plans
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.workout_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    difficulty TEXT NOT NULL CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
    goal_type TEXT NOT NULL,
    days_per_week INT DEFAULT 4,
    estimated_duration_min INT DEFAULT 45,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_ai_generated BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 9: workout_exercises
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.workout_exercises (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID NOT NULL REFERENCES public.workout_plans(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    exercise_name TEXT NOT NULL,
    target_muscle TEXT NOT NULL,
    sets INT NOT NULL DEFAULT 3,
    reps INT,
    duration_sec INT,
    rest_sec INT NOT NULL DEFAULT 60,
    order_index INT NOT NULL DEFAULT 0,
    low_impact_alternative TEXT,
    instructions TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 10: workout_history
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.workout_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    plan_id UUID REFERENCES public.workout_plans(id) ON DELETE SET NULL,
    workout_title TEXT NOT NULL,
    completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    duration_minutes INT NOT NULL,
    calories_burned INT,
    perceived_exertion INT CHECK (perceived_exertion BETWEEN 1 AND 10),
    exercises_completed JSONB DEFAULT '[]',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 11: checklist_templates
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.checklist_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'habit',
    time_of_day TEXT NOT NULL CHECK (time_of_day IN ('morning', 'afternoon', 'evening', 'night')),
    order_index INT NOT NULL DEFAULT 0,
    is_system_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 12: daily_checklists
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.daily_checklists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    total_items INT NOT NULL DEFAULT 0,
    completed_items INT NOT NULL DEFAULT 0,
    is_fully_completed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_daily_checklists_user_date UNIQUE (user_id, date)
);

-- ====================================================================
-- TABLE 13: checklist_items
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.checklist_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    checklist_id UUID NOT NULL REFERENCES public.daily_checklists(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'habit',
    time_of_day TEXT NOT NULL CHECK (time_of_day IN ('morning', 'afternoon', 'evening', 'night')),
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    completed_at TIMESTAMPTZ,
    order_index INT NOT NULL DEFAULT 0,
    reminder_time TIME,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 14: water_logs
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.water_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    logged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    log_date DATE NOT NULL,
    amount_ml INT NOT NULL CHECK (amount_ml > 0),
    beverage_type TEXT NOT NULL DEFAULT 'water',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 15: meal_logs
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.meal_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    meal_date DATE NOT NULL,
    meal_type TEXT NOT NULL CHECK (meal_type IN ('breakfast', 'lunch', 'snack', 'dinner')),
    food_items TEXT NOT NULL,
    est_calories INT DEFAULT 0,
    est_protein_g NUMERIC(5, 1) DEFAULT 0,
    est_carbs_g NUMERIC(5, 1) DEFAULT 0,
    est_fat_g NUMERIC(5, 1) DEFAULT 0,
    is_estimate BOOLEAN NOT NULL DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 16: sleep_logs
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.sleep_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    sleep_date DATE NOT NULL,
    sleep_start TIMESTAMPTZ NOT NULL,
    sleep_end TIMESTAMPTZ NOT NULL,
    duration_minutes INT NOT NULL,
    quality_score INT CHECK (quality_score BETWEEN 1 AND 100),
    restlessness_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 17: wellness_checkins
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.wellness_checkins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    checkin_date DATE NOT NULL,
    mood TEXT NOT NULL CHECK (mood IN ('great', 'good', 'okay', 'tired', 'stressed')),
    energy_level INT NOT NULL CHECK (energy_level BETWEEN 1 AND 10),
    stress_level INT NOT NULL CHECK (stress_level BETWEEN 1 AND 10),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_wellness_checkins_user_date UNIQUE (user_id, checkin_date)
);

-- ====================================================================
-- TABLE 18: reminders
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.reminders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    reminder_type TEXT NOT NULL CHECK (reminder_type IN ('water', 'workout', 'walking', 'movement', 'sleep', 'checklist', 'weight', 'weekly_review')),
    time_of_day TIME NOT NULL,
    days_of_week INT[] DEFAULT '{1,2,3,4,5,6,7}',
    is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    notification_channel TEXT NOT NULL DEFAULT 'in_app' CHECK (notification_channel IN ('in_app', 'browser_push', 'both')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 19: achievements
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.achievements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    badge_code TEXT NOT NULL,
    badge_name TEXT NOT NULL,
    badge_category TEXT NOT NULL,
    badge_description TEXT NOT NULL,
    icon_name TEXT NOT NULL DEFAULT 'Award',
    unlocked_at TIMESTAMPTZ,
    progress_val INT NOT NULL DEFAULT 0,
    target_val INT NOT NULL DEFAULT 100,
    is_unlocked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_achievements_user_badge UNIQUE (user_id, badge_code)
);

-- ====================================================================
-- TABLE 20: ai_conversations
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.ai_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT 'Fitness Coaching Session',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 21: ai_messages
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.ai_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.ai_conversations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'model', 'system')),
    content TEXT NOT NULL,
    extracted_data JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- TABLE 22: device_integrations
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.device_integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL CHECK (provider IN ('health_connect', 'device_motion', 'wearable', 'manual_only')),
    status TEXT NOT NULL DEFAULT 'disconnected' CHECK (status IN ('connected', 'disconnected', 'syncing', 'error')),
    device_name TEXT,
    last_sync_at TIMESTAMPTZ,
    sync_settings JSONB DEFAULT '{"sync_steps": true, "sync_workouts": true}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_device_integrations_user_provider UNIQUE (user_id, provider)
);

-- ====================================================================
-- TABLE 23: consent_records
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.consent_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    consent_type TEXT NOT NULL CHECK (consent_type IN ('terms_privacy', 'ai_processing', 'sensor_motion', 'notifications')),
    is_granted BOOLEAN NOT NULL DEFAULT FALSE,
    granted_at TIMESTAMPTZ,
    ip_address_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- 3. INDEXES FOR PERFORMANCE
-- ====================================================================
CREATE INDEX IF NOT EXISTS idx_body_measurements_user_date ON public.body_measurements(user_id, measured_at DESC);
CREATE INDEX IF NOT EXISTS idx_daily_health_logs_user_date ON public.daily_health_logs(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_step_records_user_date ON public.step_records(user_id, recorded_date DESC);
CREATE INDEX IF NOT EXISTS idx_activity_sessions_user_date ON public.activity_sessions(user_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_workout_history_user_date ON public.workout_history(user_id, completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_daily_checklists_user_date ON public.daily_checklists(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_checklist_items_checklist ON public.checklist_items(checklist_id);
CREATE INDEX IF NOT EXISTS idx_water_logs_user_date ON public.water_logs(user_id, log_date DESC);
CREATE INDEX IF NOT EXISTS idx_meal_logs_user_date ON public.meal_logs(user_id, meal_date DESC);
CREATE INDEX IF NOT EXISTS idx_sleep_logs_user_date ON public.sleep_logs(user_id, sleep_date DESC);
CREATE INDEX IF NOT EXISTS idx_wellness_checkins_user_date ON public.wellness_checkins(user_id, checkin_date DESC);
CREATE INDEX IF NOT EXISTS idx_ai_messages_conv ON public.ai_messages(conversation_id, created_at ASC);

-- ====================================================================
-- 4. ROW LEVEL SECURITY (RLS) FOR ALL 23 TABLES
-- ====================================================================

-- Helper macro function or explicit statements per table
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_delete_own" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Macro for user_id based tables:
DO $$
DECLARE
    tbl text;
    tables text[] := ARRAY[
        'user_preferences', 'fitness_goals', 'body_measurements', 'daily_health_logs',
        'step_records', 'activity_sessions', 'workout_plans', 'workout_exercises',
        'workout_history', 'checklist_templates', 'daily_checklists', 'checklist_items',
        'water_logs', 'meal_logs', 'sleep_logs', 'wellness_checkins', 'reminders',
        'achievements', 'ai_conversations', 'ai_messages', 'device_integrations', 'consent_records'
    ];
BEGIN
    FOREACH tbl IN ARRAY tables LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', tbl);
        EXECUTE format('CREATE POLICY "%s_select_own" ON public.%I FOR SELECT USING (auth.uid() = user_id);', tbl, tbl);
        EXECUTE format('CREATE POLICY "%s_insert_own" ON public.%I FOR INSERT WITH CHECK (auth.uid() = user_id);', tbl, tbl);
        EXECUTE format('CREATE POLICY "%s_update_own" ON public.%I FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);', tbl, tbl);
        EXECUTE format('CREATE POLICY "%s_delete_own" ON public.%I FOR DELETE USING (auth.uid() = user_id);', tbl, tbl);
    END LOOP;
END $$;

-- ====================================================================
-- 5. AUTOMATIC PROFILE INITIALIZATION TRIGGER ON USER REGISTRATION
-- ====================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, full_name, created_at, updated_at)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        NOW(),
        NOW()
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Trigger for profiles updated_at
CREATE TRIGGER tr_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_user_preferences_updated_at BEFORE UPDATE ON public.user_preferences FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_fitness_goals_updated_at BEFORE UPDATE ON public.fitness_goals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_daily_health_logs_updated_at BEFORE UPDATE ON public.daily_health_logs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_workout_plans_updated_at BEFORE UPDATE ON public.workout_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_daily_checklists_updated_at BEFORE UPDATE ON public.daily_checklists FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_ai_conversations_updated_at BEFORE UPDATE ON public.ai_conversations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER tr_device_integrations_updated_at BEFORE UPDATE ON public.device_integrations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
