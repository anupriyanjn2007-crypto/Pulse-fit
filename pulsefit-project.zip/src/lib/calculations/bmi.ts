import { BMICategory } from '@/types/pulsefit';

export interface BMIResult {
  bmi: number;
  category: BMICategory;
  isMinor: boolean;
  color: string;
  bgColor: string;
  explanation: string;
  healthyWeightRange?: {
    minKg: number;
    maxKg: number;
  };
  warning?: string;
}

const STATIC_REFERENCE_DATE = new Date('2026-11-06T00:00:00Z');

export function calculateAge(dobString: string, referenceDate?: Date): number {
  const dob = new Date(dobString);
  const today = referenceDate || STATIC_REFERENCE_DATE;
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return Math.max(0, age);
}

export function calculateBMI(
  weightKg: number,
  heightCm: number,
  age?: number
): BMIResult {
  if (heightCm <= 0 || weightKg <= 0) {
    return {
      bmi: 0,
      category: 'Normal weight',
      isMinor: false,
      color: 'text-slate-400',
      bgColor: 'bg-slate-800',
      explanation: 'Please enter valid height and weight measurements.',
    };
  }

  const heightM = heightCm / 100;
  const rawBMI = weightKg / (heightM * heightM);
  const bmi = Math.round(rawBMI * 10) / 10;
  const isMinor = age !== undefined && age < 18;

  // Healthy weight range for adult height (BMI 18.5 - 24.9)
  const minKg = Math.round(18.5 * heightM * heightM * 10) / 10;
  const maxKg = Math.round(24.9 * heightM * heightM * 10) / 10;

  if (isMinor) {
    return {
      bmi,
      category: 'Youth / Age-Adjusted',
      isMinor: true,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
      explanation:
        'Standard adult BMI categories do not apply to minors (under 18). BMI for children and adolescents varies significantly by growth patterns and age percentiles. PULSEFIT does not set weight-loss targets for minors. Please consult a qualified pediatric healthcare professional.',
      warning: 'Notice: Pediatric guidance applies. No weight loss target is generated.',
    };
  }

  let category: BMICategory = 'Normal weight';
  let color = 'text-[#CCFF00]';
  let bgColor = 'bg-[#CCFF00]/10';
  let explanation = 'Your BMI is within the standard healthy range for adults.';

  if (bmi < 18.5) {
    category = 'Underweight';
    color = 'text-amber-400';
    bgColor = 'bg-amber-500/10';
    explanation =
      'Your BMI is below the standard range. PULSEFIT recommends focusing on nutrient-dense meals and strength building rather than weight restriction. Consult a healthcare provider if experiencing unintentional weight loss.';
  } else if (bmi <= 24.9) {
    category = 'Normal weight';
    color = 'text-[#CCFF00]';
    bgColor = 'bg-[#CCFF00]/10';
    explanation =
      'Your BMI is in the normal range. Maintaining a balanced routine with regular physical activity and nourishing food supports long-term vitality.';
  } else if (bmi <= 29.9) {
    category = 'Overweight';
    color = 'text-amber-400';
    bgColor = 'bg-amber-500/10';
    explanation =
      'Your BMI is slightly elevated above the standard range. Gradual, sustainable lifestyle adjustments like daily walking and whole foods are encouraged.';
  } else if (bmi <= 34.9) {
    category = 'Obesity Class I';
    color = 'text-orange-400';
    bgColor = 'bg-orange-500/10';
    explanation =
      'Your BMI falls in the Class I category. Consistent daily movement and professional dietary guidance can help you progress comfortably.';
  } else if (bmi <= 39.9) {
    category = 'Obesity Class II';
    color = 'text-red-400';
    bgColor = 'bg-red-500/10';
    explanation =
      'Your BMI falls in the Class II category. Focus on safe, low-impact exercise and consult a medical professional for a holistic wellness plan.';
  } else {
    category = 'Obesity Class III';
    color = 'text-red-500';
    bgColor = 'bg-red-500/15';
    explanation =
      'Your BMI falls in the Class III category. Prioritize gentle joint-friendly activity and collaborate with a physician for health screening.';
  }

  return {
    bmi,
    category,
    isMinor: false,
    color,
    bgColor,
    explanation,
    healthyWeightRange: {
      minKg,
      maxKg,
    },
  };
}
