/**
 * Stride and Distance Calculation Engine
 * 
 * Accurately translates step counts to approximate walking distance and active calories.
 * Highlights that distance and energy burn are approximations based on height and body weight.
 */

export interface StepMetrics {
  distanceMeters: number;
  distanceKm: number;
  distanceMiles: number;
  estimatedActiveCalories: number;
  activeMinutesEstimate: number;
  strideLengthMeters: number;
}

export function calculateStrideLength(heightCm: number, gender?: string): number {
  if (heightCm <= 0) return 0.72; // default 72cm average stride
  // Biomechanical constant: approx 0.415 of height
  const multiplier = gender === 'female' ? 0.413 : 0.415;
  const strideMeters = (heightCm * multiplier) / 100;
  return Math.round(strideMeters * 100) / 100;
}

export function calculateStepMetrics(
  stepCount: number,
  heightCm: number = 175,
  weightKg: number = 70,
  gender?: string
): StepMetrics {
  const strideLengthMeters = calculateStrideLength(heightCm, gender);
  const distanceMeters = Math.round(stepCount * strideLengthMeters);
  const distanceKm = Math.round((distanceMeters / 1000) * 100) / 100;
  const distanceMiles = Math.round((distanceKm * 0.621371) * 100) / 100;

  // Standard MET for moderate walking (~3.5 METs):
  // Calories = MET * 3.5 * weightKg / 200 * durationMinutes
  // Average cadence ~100-115 steps/min -> ~100 steps = 1 min
  const activeMinutesEstimate = Math.round(stepCount / 105);

  // Approximately 0.04 to 0.05 kcal per step per 70kg individual
  const weightFactor = weightKg / 70;
  const estimatedActiveCalories = Math.round(stepCount * 0.045 * weightFactor);

  return {
    distanceMeters,
    distanceKm,
    distanceMiles,
    estimatedActiveCalories,
    activeMinutesEstimate,
    strideLengthMeters,
  };
}
