'use client';

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  Profile,
  UserPreferences,
  FitnessGoals,
  BodyMeasurement,
  DailyHealthLog,
  StepRecord,
  WorkoutPlan,
  WorkoutHistory,
  ChecklistItem,
  WaterLog,
  MealLog,
  SleepLog,
  WellnessCheckin,
  Reminder,
  Achievement,
  AIMessage,
  ExtractedHealthData,
  DeviceIntegration,
  ConsentRecord,
  TimeOfDay,
} from '@/types/pulsefit';
import { calculateBMI, calculateAge } from '@/lib/calculations/bmi';
import { calculateStepMetrics } from '@/lib/calculations/stride';
import { DEFAULT_CHECKLIST_TEMPLATE, generateDailyChecklist } from '@/lib/data/default-checklists';
import { EXERCISE_LIBRARY } from '@/lib/data/exercise-library';
import { createClient } from '@/lib/supabase/client';

interface PulseFitContextType {
  // Auth & Profile
  user: { id: string; email: string } | null;
  profile: Profile | null;
  preferences: UserPreferences | null;
  goals: FitnessGoals | null;
  isLoading: boolean;
  isOnboarded: boolean;
  isLiveDatabase: boolean;

  // Body & Weight
  measurements: BodyMeasurement[];
  currentMeasurement: BodyMeasurement | null;
  addMeasurement: (weightKg: number, heightCm: number, waistCm?: number, bodyFatPct?: number, notes?: string) => Promise<void>;

  // Daily Log & Steps
  todayLog: DailyHealthLog;
  stepRecords: StepRecord[];
  addStepRecord: (steps: number, source: 'manual' | 'device_motion' | 'health_connect' | 'wearable', sourceDevice?: string) => Promise<void>;
  updateStepGoal: (goal: number) => Promise<void>;

  // Daily Checklist
  checklistItems: ChecklistItem[];
  toggleChecklistItem: (itemId: string) => Promise<void>;
  addCustomChecklistItem: (title: string, category: ChecklistItem['category'], timeOfDay: TimeOfDay, reminderTime?: string) => Promise<void>;
  deleteChecklistItem: (itemId: string) => Promise<void>;

  // Hydration
  waterLogs: WaterLog[];
  addWaterLog: (amountMl: number, beverageType?: string) => Promise<void>;
  updateWaterGoal: (goalMl: number) => Promise<void>;

  // Nutrition
  mealLogs: MealLog[];
  addMealLog: (mealType: MealLog['meal_type'], foodItems: string, calories: number, proteinG: number, carbsG: number, fatG: number, notes?: string) => Promise<void>;

  // Sleep & Wellness
  sleepLogs: SleepLog[];
  addSleepLog: (sleepStart: string, sleepEnd: string, durationMinutes: number, qualityScore?: number, restlessnessNotes?: string) => Promise<void>;
  wellnessCheckins: WellnessCheckin[];
  saveWellnessCheckin: (mood: WellnessCheckin['mood'], energy: number, stress: number, notes?: string) => Promise<void>;

  // Workouts
  workoutPlans: WorkoutPlan[];
  workoutHistory: WorkoutHistory[];
  completeWorkout: (workoutTitle: string, durationMinutes: number, exercisesCompleted: WorkoutHistory['exercises_completed'], perceivedExertion?: number, notes?: string) => Promise<void>;

  // Gamification & Achievements
  achievements: Achievement[];
  currentStreak: number;

  // Reminders & Devices
  reminders: Reminder[];
  toggleReminder: (reminderType: Reminder['reminder_type'], enabled: boolean) => Promise<void>;
  devices: DeviceIntegration[];
  updateDeviceStatus: (provider: DeviceIntegration['provider'], status: DeviceIntegration['status'], deviceName?: string) => Promise<void>;

  // AI & Natural Language
  aiMessages: AIMessage[];
  sendAIMessage: (prompt: string) => Promise<string>;
  pendingNaturalLog: ExtractedHealthData | null;
  confirmNaturalLog: () => Promise<void>;
  discardNaturalLog: () => void;
  clearAIConversation: () => Promise<void>;

  // Consent & Privacy
  consents: ConsentRecord[];
  updateConsent: (type: ConsentRecord['consent_type'], granted: boolean) => Promise<void>;
  exportUserData: () => Promise<string>;
  deleteUserAccount: () => Promise<void>;

  // Auth functions
  login: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  completeOnboarding: (data: {
    fullName: string;
    dob: string;
    gender: Profile['gender'];
    country: string;
    weightKg: number;
    heightCm: number;
    targetWeightKg?: number;
    primaryGoal: FitnessGoals['primary_goal'];
    activityLevel: string;
    experience: string;
    exercisePreferences: string[];
    equipmentAvailable: string[];
    healthLimitations: string;
    dietaryType: UserPreferences['dietary_type'];
    cuisinePreferences: string[];
    budgetFriendly: boolean;
  }) => Promise<void>;
}

const PulseFitContext = createContext<PulseFitContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'pulsefit_active_session_v1';

export function PulseFitProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [goals, setGoals] = useState<FitnessGoals | null>(null);
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>([]);
  const [todayLog, setTodayLog] = useState<DailyHealthLog>({
    id: 'log-today',
    user_id: 'guest',
    date: '2026-11-06',
    total_steps: 6420,
    distance_meters: 4620,
    active_minutes: 48,
    active_calories: 310,
    water_ml: 1750,
    sleep_minutes: 450, // 7.5 hrs
    checklist_completion_pct: 66,
    wellness_score: 82,
    updated_at: '2026-11-06T00:00:00.000Z',
  });
  const [stepRecords, setStepRecords] = useState<StepRecord[]>([]);
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>([]);
  const [waterLogs, setWaterLogs] = useState<WaterLog[]>([]);
  const [mealLogs, setMealLogs] = useState<MealLog[]>([]);
  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>([]);
  const [wellnessCheckins, setWellnessCheckins] = useState<WellnessCheckin[]>([]);
  const [workoutPlans, setWorkoutPlans] = useState<WorkoutPlan[]>([]);
  const [workoutHistory, setWorkoutHistory] = useState<WorkoutHistory[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [devices, setDevices] = useState<DeviceIntegration[]>([]);
  const [consents, setConsents] = useState<ConsentRecord[]>([]);
  const [aiMessages, setAiMessages] = useState<AIMessage[]>([]);
  const [pendingNaturalLog, setPendingNaturalLog] = useState<ExtractedHealthData | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isLiveDatabase, setIsLiveDatabase] = useState(false);

  // Initialize Default State or Load from Storage/Supabase
  useEffect(() => {
    async function initSession() {
      try {
        const supabase = createClient();
        if (supabase) {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            setUser({ id: session.user.id, email: session.user.email || '' });
            setIsLiveDatabase(true);
            // Fetch live user data from Supabase
            // ...
          }
        }

        // Load local session or default demo profile if not in Supabase
        const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          setUser(parsed.user);
          setProfile(parsed.profile);
          setPreferences(parsed.preferences);
          setGoals(parsed.goals);
          setMeasurements(parsed.measurements || []);
          if (parsed.todayLog) setTodayLog(parsed.todayLog);
          setStepRecords(parsed.stepRecords || []);
          setChecklistItems(parsed.checklistItems || []);
          setWaterLogs(parsed.waterLogs || []);
          setMealLogs(parsed.mealLogs || []);
          setSleepLogs(parsed.sleepLogs || []);
          setWellnessCheckins(parsed.wellnessCheckins || []);
          setWorkoutPlans(parsed.workoutPlans || []);
          setWorkoutHistory(parsed.workoutHistory || []);
          setAchievements(parsed.achievements || []);
          setReminders(parsed.reminders || []);
          setDevices(parsed.devices || []);
          setConsents(parsed.consents || []);
          setAiMessages(parsed.aiMessages || []);
        } else {
          // Initialize default sporty demo athlete profile
          const demoUserId = 'usr-demo-777';
          const defaultProf: Profile = {
            id: demoUserId,
            email: 'athlete@pulsefit.app',
            full_name: 'Alex Rivera',
            dob: '1998-05-14',
            age: 28,
            country: 'IN',
            preferred_language: 'en',
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata',
            gender: 'male',
            onboarding_completed: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };

          const defaultPrefs: UserPreferences = {
            user_id: demoUserId,
            exercise_preferences: ['Walking', 'Strength training', 'Yoga'],
            equipment_available: ['Dumbbells', 'Mat'],
            health_limitations: 'None reported',
            dietary_type: 'vegetarian',
            cuisine_preferences: ['Tamil Nadu', 'South Indian'],
            budget_friendly: true,
            allergies: [],
            meal_schedule: { breakfast: '08:00', lunch: '13:00', snack: '17:00', dinner: '20:30' },
            daily_available_minutes: 45,
            workout_location_preference: 'home',
          };

          const defaultGoals: FitnessGoals = {
            user_id: demoUserId,
            primary_goal: 'general_fitness',
            secondary_goals: ['better_daily_activity', 'strength_improvement'],
            target_weight_kg: 68.0,
            weekly_workout_target: 4,
            daily_step_goal: 8000,
            daily_water_goal_ml: 2500,
            daily_sleep_goal_hrs: 8.0,
          };

          const bmiCalc = calculateBMI(71.5, 175, 28);
          const initialMeasurement: BodyMeasurement = {
            id: 'meas-1',
            user_id: demoUserId,
            measured_at: new Date().toISOString(),
            weight_kg: 71.5,
            height_cm: 175,
            bmi: bmiCalc.bmi,
            bmi_category: bmiCalc.category,
            waist_cm: 82,
            is_minor: false,
          };

          const todayDate = new Date().toISOString().split('T')[0];
          const initialChecklist = generateDailyChecklist(demoUserId, todayDate);
          // Pre-complete a couple morning habits for realistic experience
          initialChecklist[0].is_completed = true;
          initialChecklist[1].is_completed = true;

          const defaultAchievements: Achievement[] = [
            {
              id: 'ach-1',
              user_id: demoUserId,
              badge_code: 'first_streak',
              badge_name: 'Consistency Kickoff',
              badge_category: 'streak',
              badge_description: 'Completed 3 consecutive daily fitness tracking check-ins.',
              icon_name: 'Flame',
              is_unlocked: true,
              unlocked_at: new Date().toISOString(),
              progress_val: 3,
              target_val: 3,
            },
            {
              id: 'ach-2',
              user_id: demoUserId,
              badge_code: 'hydration_hero',
              badge_name: 'Hydration Hero',
              badge_category: 'hydration',
              badge_description: 'Drank 2,500ml water in a single day.',
              icon_name: 'Droplets',
              is_unlocked: false,
              progress_val: 1750,
              target_val: 2500,
            },
            {
              id: 'ach-3',
              user_id: demoUserId,
              badge_code: 'step_master',
              badge_name: 'Step Master 10K',
              badge_category: 'steps',
              badge_description: 'Hit 10,000 steps in 24 hours.',
              icon_name: 'Footprints',
              is_unlocked: false,
              progress_val: 6420,
              target_val: 10000,
            },
          ];

          setUser({ id: demoUserId, email: defaultProf.email! });
          setProfile(defaultProf);
          setPreferences(defaultPrefs);
          setGoals(defaultGoals);
          setMeasurements([initialMeasurement]);
          setChecklistItems(initialChecklist);
          setAchievements(defaultAchievements);
          setDevices([
            {
              id: 'dev-1',
              user_id: demoUserId,
              provider: 'device_motion',
              status: 'connected',
              device_name: 'Device Accelerometer (Active Session)',
              sync_settings: { sync_steps: true, sync_workouts: true },
            },
            {
              id: 'dev-2',
              user_id: demoUserId,
              provider: 'health_connect',
              status: 'disconnected',
              device_name: 'Android Health Connect',
              sync_settings: { sync_steps: true, sync_workouts: true },
            },
          ]);
        }
      } catch (err) {
        console.error('Failed to init session:', err);
      } finally {
        setIsLoading(false);
      }
    }

    initSession();
  }, []);

  // Sync to local storage
  useEffect(() => {
    if (!isLoading && profile) {
      const dataToSave = {
        user,
        profile,
        preferences,
        goals,
        measurements,
        todayLog,
        stepRecords,
        checklistItems,
        waterLogs,
        mealLogs,
        sleepLogs,
        wellnessCheckins,
        workoutPlans,
        workoutHistory,
        achievements,
        reminders,
        devices,
        consents,
        aiMessages,
      };
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(dataToSave));
    }
  }, [
    isLoading,
    user,
    profile,
    preferences,
    goals,
    measurements,
    todayLog,
    stepRecords,
    checklistItems,
    waterLogs,
    mealLogs,
    sleepLogs,
    wellnessCheckins,
    workoutPlans,
    workoutHistory,
    achievements,
    reminders,
    devices,
    consents,
    aiMessages,
  ]);

  // Recalculate daily checklist completion percentage
  useEffect(() => {
    if (checklistItems.length > 0) {
      const completed = checklistItems.filter((i) => i.is_completed).length;
      const pct = Math.round((completed / checklistItems.length) * 100);
      setTodayLog((prev) => ({
        ...prev,
        checklist_completion_pct: pct,
      }));
    }
  }, [checklistItems]);

  const addMeasurement = useCallback(
    async (weightKg: number, heightCm: number, waistCm?: number, bodyFatPct?: number, notes?: string) => {
      const isMinor = profile?.age !== undefined && profile.age < 18;
      const bmiCalc = calculateBMI(weightKg, heightCm, profile?.age);

      const newM: BodyMeasurement = {
        id: `meas-${Date.now()}`,
        user_id: user?.id || 'guest',
        measured_at: new Date().toISOString(),
        weight_kg: weightKg,
        height_cm: heightCm,
        bmi: bmiCalc.bmi,
        bmi_category: bmiCalc.category,
        waist_cm: waistCm,
        body_fat_pct: bodyFatPct,
        is_minor: isMinor,
        notes,
      };

      setMeasurements((prev) => [newM, ...prev]);
    },
    [user, profile]
  );

  const addStepRecord = useCallback(
    async (steps: number, source: 'manual' | 'device_motion' | 'health_connect' | 'wearable', sourceDevice?: string) => {
      const metrics = calculateStepMetrics(
        steps,
        measurements[0]?.height_cm || 175,
        measurements[0]?.weight_kg || 70,
        profile?.gender
      );

      const newRecord: StepRecord = {
        id: `step-${Date.now()}`,
        user_id: user?.id || 'guest',
        recorded_date: new Date().toISOString().split('T')[0],
        step_count: steps,
        distance_meters: metrics.distanceMeters,
        active_seconds: metrics.activeMinutesEstimate * 60,
        source,
        source_device: sourceDevice || (source === 'device_motion' ? 'Device Accelerometer' : 'Manual Entry'),
        created_at: new Date().toISOString(),
      };

      setStepRecords((prev) => [newRecord, ...prev]);

      // Update todayLog
      setTodayLog((prev) => {
        const newTotal = prev.total_steps + steps;
        const newMetrics = calculateStepMetrics(
          newTotal,
          measurements[0]?.height_cm || 175,
          measurements[0]?.weight_kg || 70
        );
        return {
          ...prev,
          total_steps: newTotal,
          distance_meters: newMetrics.distanceMeters,
          active_calories: prev.active_calories + metrics.estimatedActiveCalories,
          active_minutes: prev.active_minutes + metrics.activeMinutesEstimate,
        };
      });
    },
    [user, measurements, profile]
  );

  const updateStepGoal = useCallback(async (goal: number) => {
    setGoals((prev) => (prev ? { ...prev, daily_step_goal: goal } : null));
  }, []);

  const toggleChecklistItem = useCallback(async (itemId: string) => {
    setChecklistItems((prev) =>
      prev.map((item) =>
        item.id === itemId
          ? {
              ...item,
              is_completed: !item.is_completed,
              completed_at: !item.is_completed ? new Date().toISOString() : undefined,
            }
          : item
      )
    );
  }, []);

  const addCustomChecklistItem = useCallback(
    async (title: string, category: ChecklistItem['category'], timeOfDay: TimeOfDay, reminderTime?: string) => {
      const newItem: ChecklistItem = {
        id: `chk-custom-${Date.now()}`,
        checklist_id: `cl-${new Date().toISOString().split('T')[0]}`,
        user_id: user?.id || 'guest',
        title,
        category,
        time_of_day: timeOfDay,
        is_completed: false,
        order_index: checklistItems.length + 1,
        reminder_time: reminderTime,
      };
      setChecklistItems((prev) => [...prev, newItem]);
    },
    [user, checklistItems.length]
  );

  const deleteChecklistItem = useCallback(async (itemId: string) => {
    setChecklistItems((prev) => prev.filter((i) => i.id !== itemId));
  }, []);

  const addWaterLog = useCallback(
    async (amountMl: number, beverageType: string = 'water') => {
      const newWater: WaterLog = {
        id: `water-${Date.now()}`,
        user_id: user?.id || 'guest',
        logged_at: new Date().toISOString(),
        log_date: new Date().toISOString().split('T')[0],
        amount_ml: amountMl,
        beverage_type: beverageType,
      };
      setWaterLogs((prev) => [newWater, ...prev]);
      setTodayLog((prev) => ({
        ...prev,
        water_ml: prev.water_ml + amountMl,
      }));
    },
    [user]
  );

  const updateWaterGoal = useCallback(async (goalMl: number) => {
    setGoals((prev) => (prev ? { ...prev, daily_water_goal_ml: goalMl } : null));
  }, []);

  const addMealLog = useCallback(
    async (
      mealType: MealLog['meal_type'],
      foodItems: string,
      calories: number,
      proteinG: number,
      carbsG: number,
      fatG: number,
      notes?: string
    ) => {
      const newMeal: MealLog = {
        id: `meal-${Date.now()}`,
        user_id: user?.id || 'guest',
        meal_date: new Date().toISOString().split('T')[0],
        meal_type: mealType,
        food_items: foodItems,
        est_calories: calories,
        est_protein_g: proteinG,
        est_carbs_g: carbsG,
        est_fat_g: fatG,
        is_estimate: true,
        notes,
        created_at: new Date().toISOString(),
      };
      setMealLogs((prev) => [newMeal, ...prev]);
    },
    [user]
  );

  const addSleepLog = useCallback(
    async (
      sleepStart: string,
      sleepEnd: string,
      durationMinutes: number,
      qualityScore?: number,
      restlessnessNotes?: string
    ) => {
      const newSleep: SleepLog = {
        id: `sleep-${Date.now()}`,
        user_id: user?.id || 'guest',
        sleep_date: new Date().toISOString().split('T')[0],
        sleep_start: sleepStart,
        sleep_end: sleepEnd,
        duration_minutes: durationMinutes,
        quality_score: qualityScore,
        restlessness_notes: restlessnessNotes,
      };
      setSleepLogs((prev) => [newSleep, ...prev]);
      setTodayLog((prev) => ({
        ...prev,
        sleep_minutes: durationMinutes,
      }));
    },
    [user]
  );

  const saveWellnessCheckin = useCallback(
    async (mood: WellnessCheckin['mood'], energy: number, stress: number, notes?: string) => {
      const checkin: WellnessCheckin = {
        id: `well-${Date.now()}`,
        user_id: user?.id || 'guest',
        checkin_date: new Date().toISOString().split('T')[0],
        mood,
        energy_level: energy,
        stress_level: stress,
        notes,
      };
      setWellnessCheckins((prev) => [checkin, ...prev.filter((c) => c.checkin_date !== checkin.checkin_date)]);
      // boost wellness score based on balanced checkin
      const calculatedScore = Math.min(100, Math.round(energy * 7 + (10 - stress) * 3));
      setTodayLog((prev) => ({ ...prev, wellness_score: calculatedScore }));
    },
    [user]
  );

  const completeWorkout = useCallback(
    async (
      workoutTitle: string,
      durationMinutes: number,
      exercisesCompleted: WorkoutHistory['exercises_completed'],
      perceivedExertion?: number,
      notes?: string
    ) => {
      const estBurn = Math.round(durationMinutes * 6.5); // Approx 6.5 kcal/min moderate-high
      const historyEntry: WorkoutHistory = {
        id: `wh-${Date.now()}`,
        user_id: user?.id || 'guest',
        workout_title: workoutTitle,
        completed_at: new Date().toISOString(),
        duration_minutes: durationMinutes,
        calories_burned: estBurn,
        perceived_exertion: perceivedExertion,
        exercises_completed: exercisesCompleted,
        notes,
      };

      setWorkoutHistory((prev) => [historyEntry, ...prev]);
      setTodayLog((prev) => ({
        ...prev,
        active_minutes: prev.active_minutes + durationMinutes,
        active_calories: prev.active_calories + estBurn,
      }));
    },
    [user]
  );

  const toggleReminder = useCallback(
    async (reminderType: Reminder['reminder_type'], enabled: boolean) => {
      setReminders((prev) =>
        prev.map((r) => (r.reminder_type === reminderType ? { ...r, is_enabled: enabled } : r))
      );
    },
    []
  );

  const updateDeviceStatus = useCallback(
    async (provider: DeviceIntegration['provider'], status: DeviceIntegration['status'], deviceName?: string) => {
      setDevices((prev) =>
        prev.map((d) => (d.provider === provider ? { ...d, status, device_name: deviceName || d.device_name } : d))
      );
    },
    []
  );

  const sendAIMessage = useCallback(
    async (prompt: string): Promise<string> => {
      const userMsg: AIMessage = {
        id: `msg-${Date.now()}`,
        conversation_id: 'conv-main',
        user_id: user?.id || 'guest',
        role: 'user',
        content: prompt,
        created_at: new Date().toISOString(),
      };

      setAiMessages((prev) => [...prev, userMsg]);

      // Call server AI endpoint
      try {
        const res = await fetch('/api/coach', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            context: {
              age: profile?.age,
              gender: profile?.gender,
              goals: goals?.primary_goal,
              currentWeight: measurements[0]?.weight_kg,
              todaySteps: todayLog.total_steps,
              stepGoal: goals?.daily_step_goal,
              waterMl: todayLog.water_ml,
              dietaryType: preferences?.dietary_type,
              cuisinePreferences: preferences?.cuisine_preferences,
              healthLimitations: preferences?.health_limitations,
            },
          }),
        });

        if (res.ok) {
          const data = await res.json();
          const assistantMsg: AIMessage = {
            id: `msg-${Date.now() + 1}`,
            conversation_id: 'conv-main',
            user_id: user?.id || 'guest',
            role: 'model',
            content: data.reply,
            extracted_data: data.extractedData,
            created_at: new Date().toISOString(),
          };
          setAiMessages((prev) => [...prev, assistantMsg]);

          if (data.extractedData && data.extractedData.type !== 'none') {
            setPendingNaturalLog(data.extractedData);
          }

          return data.reply;
        }
      } catch (err) {
        console.warn('API error, falling back to local coach intelligence:', err);
      }

      // Offline / Local Coach Intelligence Fallback
      let fallbackReply = `Great focus! You have recorded ${todayLog.total_steps} steps and ${todayLog.water_ml}ml of water today. Keep prioritizing consistent hydration and steady pacing.`;
      const lower = prompt.toLowerCase();

      let extracted: ExtractedHealthData | null = null;
      if (lower.includes('step') && lower.match(/\d+/)) {
        const num = parseInt(lower.match(/\d+/)![0], 10);
        extracted = {
          type: 'steps',
          value: num,
          unit: 'steps',
          confidence: 0.95,
          confirmation_prompt: `I noticed you walked ${num.toLocaleString()} steps. Would you like me to record this to your daily activity log?`,
        };
        fallbackReply = `Understood! I detected a step entry for ${num.toLocaleString()} steps. Please confirm the prompt below to log it into your daily record.`;
      } else if (lower.includes('water') && lower.match(/\d+/)) {
        const num = parseInt(lower.match(/\d+/)![0], 10);
        extracted = {
          type: 'water',
          value: num,
          unit: 'ml',
          confidence: 0.95,
          confirmation_prompt: `I detected that you drank ${num} ml of water. Would you like to add this to today's hydration total?`,
        };
        fallbackReply = `Logged hydration intent! Confirm to add ${num} ml to your daily water count.`;
      } else if (lower.includes('workout') || lower.includes('exercise')) {
        fallbackReply = `For your ${preferences?.workout_location_preference || 'home'} routine, I recommend 3 sets of Bodyweight Squats followed by Push-Ups and a Cat-Cow mobility reset. Always warm up with dynamic movement!`;
      }

      const localMsg: AIMessage = {
        id: `msg-${Date.now() + 1}`,
        conversation_id: 'conv-main',
        user_id: user?.id || 'guest',
        role: 'model',
        content: fallbackReply,
        extracted_data: extracted || undefined,
        created_at: new Date().toISOString(),
      };
      setAiMessages((prev) => [...prev, localMsg]);

      if (extracted) {
        setPendingNaturalLog(extracted);
      }

      return fallbackReply;
    },
    [user, profile, goals, measurements, todayLog, preferences]
  );

  const confirmNaturalLog = useCallback(async () => {
    if (!pendingNaturalLog) return;
    if (pendingNaturalLog.type === 'steps') {
      await addStepRecord(pendingNaturalLog.value, 'manual', 'AI Natural Language Entry');
    } else if (pendingNaturalLog.type === 'water') {
      await addWaterLog(pendingNaturalLog.value, 'water');
    }
    setPendingNaturalLog(null);
  }, [pendingNaturalLog, addStepRecord, addWaterLog]);

  const discardNaturalLog = useCallback(() => {
    setPendingNaturalLog(null);
  }, []);

  const clearAIConversation = useCallback(async () => {
    setAiMessages([]);
  }, []);

  const updateConsent = useCallback(
    async (type: ConsentRecord['consent_type'], granted: boolean) => {
      setConsents((prev) => [
        ...prev.filter((c) => c.consent_type !== type),
        {
          id: `cons-${Date.now()}`,
          user_id: user?.id || 'guest',
          consent_type: type,
          is_granted: granted,
          granted_at: new Date().toISOString(),
        },
      ]);
    },
    [user]
  );

  const exportUserData = useCallback(async (): Promise<string> => {
    const fullExport = {
      profile,
      preferences,
      goals,
      measurements,
      dailyLog: todayLog,
      stepRecords,
      checklistItems,
      waterLogs,
      mealLogs,
      sleepLogs,
      wellnessCheckins,
      workoutHistory,
      exportedAt: new Date().toISOString(),
      notice: 'PulseFit Personal Fitness & Health Data Export. Private & Confidential.',
    };
    return JSON.stringify(fullExport, null, 2);
  }, [
    profile,
    preferences,
    goals,
    measurements,
    todayLog,
    stepRecords,
    checklistItems,
    waterLogs,
    mealLogs,
    sleepLogs,
    wellnessCheckins,
    workoutHistory,
  ]);

  const deleteUserAccount = useCallback(async () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    setUser(null);
    setProfile(null);
    window.location.href = '/';
  }, []);

  const login = useCallback(async (email: string) => {
    const demoId = 'usr-' + Math.random().toString(36).substring(2, 9);
    setUser({ id: demoId, email });
  }, []);

  const logout = useCallback(async () => {
    const supabase = createClient();
    if (supabase) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setProfile(null);
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    window.location.href = '/auth/login';
  }, []);

  const completeOnboarding = useCallback(
    async (data: {
      fullName: string;
      dob: string;
      gender: Profile['gender'];
      country: string;
      weightKg: number;
      heightCm: number;
      targetWeightKg?: number;
      primaryGoal: FitnessGoals['primary_goal'];
      activityLevel: string;
      experience: string;
      exercisePreferences: string[];
      equipmentAvailable: string[];
      healthLimitations: string;
      dietaryType: UserPreferences['dietary_type'];
      cuisinePreferences: string[];
      budgetFriendly: boolean;
    }) => {
      const calculatedAge = calculateAge(data.dob);
      const bmiCalc = calculateBMI(data.weightKg, data.heightCm, calculatedAge);
      const userId = user?.id || `usr-${Date.now()}`;

      const newProf: Profile = {
        id: userId,
        email: user?.email || 'user@pulsefit.app',
        full_name: data.fullName,
        dob: data.dob,
        age: calculatedAge,
        country: data.country,
        preferred_language: 'en',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        gender: data.gender,
        onboarding_completed: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const newPrefs: UserPreferences = {
        user_id: userId,
        exercise_preferences: data.exercisePreferences,
        equipment_available: data.equipmentAvailable,
        health_limitations: data.healthLimitations,
        dietary_type: data.dietaryType,
        cuisine_preferences: data.cuisinePreferences,
        budget_friendly: data.budgetFriendly,
        allergies: [],
        meal_schedule: { breakfast: '08:00', lunch: '13:00', snack: '17:00', dinner: '20:30' },
        daily_available_minutes: 45,
        workout_location_preference: data.exercisePreferences.includes('Gym workout') ? 'gym' : 'home',
      };

      const newGoals: FitnessGoals = {
        user_id: userId,
        primary_goal: data.primaryGoal,
        secondary_goals: [],
        target_weight_kg: calculatedAge >= 18 ? data.targetWeightKg : undefined, // Never set weight loss target for minors!
        weekly_workout_target: 4,
        daily_step_goal: 8000,
        daily_water_goal_ml: 2500,
        daily_sleep_goal_hrs: 8.0,
      };

      const initialMeasurement: BodyMeasurement = {
        id: `meas-${Date.now()}`,
        user_id: userId,
        measured_at: new Date().toISOString(),
        weight_kg: data.weightKg,
        height_cm: data.heightCm,
        bmi: bmiCalc.bmi,
        bmi_category: bmiCalc.category,
        is_minor: calculatedAge < 18,
      };

      const todayDate = new Date().toISOString().split('T')[0];
      const newChecklist = generateDailyChecklist(userId, todayDate);

      setUser({ id: userId, email: newProf.email! });
      setProfile(newProf);
      setPreferences(newPrefs);
      setGoals(newGoals);
      setMeasurements([initialMeasurement]);
      setChecklistItems(newChecklist);
    },
    [user]
  );

  return (
    <PulseFitContext.Provider
      value={{
        user,
        profile,
        preferences,
        goals,
        isLoading,
        isOnboarded: !!profile?.onboarding_completed,
        isLiveDatabase,
        measurements,
        currentMeasurement: measurements[0] || null,
        addMeasurement,
        todayLog,
        stepRecords,
        addStepRecord,
        updateStepGoal,
        checklistItems,
        toggleChecklistItem,
        addCustomChecklistItem,
        deleteChecklistItem,
        waterLogs,
        addWaterLog,
        updateWaterGoal,
        mealLogs,
        addMealLog,
        sleepLogs,
        addSleepLog,
        wellnessCheckins,
        saveWellnessCheckin,
        workoutPlans,
        workoutHistory,
        completeWorkout,
        achievements,
        currentStreak: 4,
        reminders,
        toggleReminder,
        devices,
        updateDeviceStatus,
        aiMessages,
        sendAIMessage,
        pendingNaturalLog,
        confirmNaturalLog,
        discardNaturalLog,
        clearAIConversation,
        consents,
        updateConsent,
        exportUserData,
        deleteUserAccount,
        login,
        logout,
        completeOnboarding,
      }}
    >
      {children}
    </PulseFitContext.Provider>
  );
}

export function usePulseFit() {
  const context = useContext(PulseFitContext);
  if (!context) {
    throw new Error('usePulseFit must be used within a PulseFitProvider');
  }
  return context;
}
