import { GoogleGenAI } from '@google/genai';
import { ExtractedHealthData } from '@/types/pulsefit';

export interface AICoachContext {
  age?: number;
  gender?: string;
  goals?: string;
  currentWeight?: number;
  todaySteps?: number;
  stepGoal?: number;
  waterMl?: number;
  dietaryType?: string;
  cuisinePreferences?: string[];
  healthLimitations?: string;
}

export interface AICoachResponse {
  reply: string;
  extractedData?: ExtractedHealthData;
  safetyAlert?: string;
}

const SYSTEM_SAFETY_INSTRUCTIONS = `
You are the PULSEFIT AI Personal Health & Fitness Coach.
Your persona is knowledgeable, encouraging, athletic, and scientifically grounded.

CRITICAL SAFETY & MEDICAL BOUNDARIES:
1. You are NOT a medical doctor. Never diagnose medical conditions or prescribe medication or supplements.
2. If the user mentions acute symptoms (e.g., chest pain, shortness of breath, severe dizziness, faintness), immediately advise them to seek emergency medical care.
3. For minors (under 18 years old): NEVER suggest weight-loss diets, calorie restriction, or aggressive fat-loss workouts. Encourage balanced nutrition, active play, sports, and pediatric healthcare consultation.
4. For underweight individuals: DO NOT recommend calorie deficits or weight reduction. Focus on progressive strength, nutrient density, and healthy habit building.
5. Emphasize that all calorie burns, distance calculations, and nutrition stats are estimates, not lab measurements.
6. Support diverse food cultures, especially South Indian and Tamil Nadu cuisines (Idli, Sambar, Ragi kali, Kambu koozh, Sundal, Neer mor, Dal, etc.) with balanced nutrient combinations.
7. NEVER request or accept personal identifying information like passwords or government IDs.

NATURAL LANGUAGE LOGGING PARSING:
If the user indicates they completed an activity or logged intake (e.g., "I walked 4,000 steps today", "Drank 500 ml water", "Completed 30 min yoga"), provide an encouraging brief response and format the extracted intent as a clean log entry.
`;

export async function generateAICoachReply(
  prompt: string,
  context: AICoachContext
): Promise<AICoachResponse> {
  const apiKey = process.env.GEMINI_API_KEY;

  // Rule-based safety check before external network calls
  const lowerPrompt = prompt.toLowerCase();
  if (
    lowerPrompt.includes('chest pain') ||
    lowerPrompt.includes('heart attack') ||
    lowerPrompt.includes('cannot breathe') ||
    lowerPrompt.includes('severe dizziness')
  ) {
    return {
      reply:
        'CRITICAL HEALTH ALERT: Please stop physical activity immediately and seek urgent emergency medical assistance or call your local emergency medical services. PULSEFIT cannot provide emergency medical support.',
      safetyAlert: 'Emergency medical referral triggered.',
    };
  }

  // Check minor restriction
  if (context.age !== undefined && context.age < 18) {
    if (lowerPrompt.includes('lose weight') || lowerPrompt.includes('fasting') || lowerPrompt.includes('calorie deficit')) {
      return {
        reply:
          'Because you are under 18, PULSEFIT strictly avoids calorie restriction or weight-loss plans. During growth and development, your body requires wholesome nourishment. Focus on fun athletic movement, sports, adequate sleep, and talk with a doctor or registered pediatric dietitian for personal guidance.',
        safetyAlert: 'Minor safety protocol applied.',
      };
    }
  }

  // Check natural language patterns locally
  let extractedData: ExtractedHealthData | undefined = undefined;

  // Steps matching
  const stepMatch = lowerPrompt.match(/(\d+[\d,]*)\s*(steps|step)/i);
  if (stepMatch) {
    const rawVal = parseInt(stepMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(rawVal) && rawVal > 0) {
      extractedData = {
        type: 'steps',
        value: rawVal,
        unit: 'steps',
        confidence: 0.95,
        confirmation_prompt: `I noticed you completed ${rawVal.toLocaleString()} steps. Confirm to log this into your daily activity history.`,
      };
    }
  }

  // Water matching
  const waterMatch = lowerPrompt.match(/(\d+[\d,]*)\s*(ml|milliliters|millilitres|liters|litres|glass|glasses)/i);
  if (waterMatch && !extractedData) {
    let rawVal = parseInt(waterMatch[1].replace(/,/g, ''), 10);
    const unit = waterMatch[2].toLowerCase();
    if (unit.startsWith('liter') || unit === 'l') {
      rawVal = rawVal * 1000;
    } else if (unit.startsWith('glass')) {
      rawVal = rawVal * 250; // standard 250ml glass
    }
    if (!isNaN(rawVal) && rawVal > 0) {
      extractedData = {
        type: 'water',
        value: rawVal,
        unit: 'ml',
        confidence: 0.95,
        confirmation_prompt: `I detected a hydration log of ${rawVal} ml. Confirm to add this to your daily water intake.`,
      };
    }
  }

  // If Gemini API Key is available, make the LLM call using the official SDK
  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const contextSummary = `
User Context (Anonymous):
- Age: ${context.age ?? 'Not disclosed'}
- Target/Primary Goal: ${context.goals ?? 'General fitness'}
- Activity Level: ${context.todaySteps ?? 0} steps recorded today (Target: ${context.stepGoal ?? 8000})
- Water logged: ${context.waterMl ?? 0} ml
- Dietary Preference: ${context.dietaryType ?? 'Omnivore'}
- Regional Cuisine: ${context.cuisinePreferences?.join(', ') || 'Standard / Indian'}
- Reported limitations: ${context.healthLimitations || 'None'}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          { role: 'user', parts: [{ text: `${SYSTEM_SAFETY_INSTRUCTIONS}\n\n${contextSummary}\n\nUser Message: ${prompt}` }] },
        ],
      });

      const replyText = response.text || 'I am here to support your fitness routine. How can I assist you today?';
      return {
        reply: replyText,
        extractedData,
      };
    } catch (apiErr) {
      console.warn('Gemini API call failed, falling back to local coach reasoning:', apiErr);
    }
  }

  // Intelligent Local Rule-Based Engine (when no external key configured or offline)
  let fallbackText = '';
  if (extractedData) {
    fallbackText = `I have recognized your entry: ${extractedData.confirmation_prompt} Please review and confirm below so we keep your records accurate without accidental inputs.`;
  } else if (lowerPrompt.includes('workout') || lowerPrompt.includes('exercise') || lowerPrompt.includes('routine')) {
    fallbackText = `Based on your goal (${context.goals || 'general fitness'}), here is a recommended session:
1. Dynamic Warm-up: 5 minutes of arm circles and leg swings.
2. Main Work: 3 sets of Bodyweight Squats (12 reps), Incline Push-ups (10 reps), and Plank hold (30 sec).
3. Cool-down: 5 minutes of Cat-Cow mobility and deep breathing.
Remember to hydrate before and after!`;
  } else if (lowerPrompt.includes('food') || lowerPrompt.includes('diet') || lowerPrompt.includes('meal') || lowerPrompt.includes('eat')) {
    fallbackText = `For balanced energy with ${context.dietaryType || 'vegetarian'} preferences, focus on protein and fiber:
• Breakfast: Steamed Idlis with Drumstick Sambar or Oatmeal with nuts.
• Lunch: Brown rice with Lentil Dal, Keerai (greens) poriyal, and a cup of fresh curd.
• Snack: Boiled chickpea sundal or roasted makhanas with Neer Mor (spiced buttermilk).
• Dinner: Warm millet pongal or whole wheat roti with vegetables.`;
  } else if (lowerPrompt.includes('step') || lowerPrompt.includes('walk')) {
    const steps = context.todaySteps || 0;
    const goal = context.stepGoal || 8000;
    const remaining = Math.max(0, goal - steps);
    fallbackText = `You have completed ${steps.toLocaleString()} steps today (${Math.round((steps / goal) * 100)}% of your ${goal.toLocaleString()} target). ${
      remaining > 0
        ? `A brisk ${Math.round(remaining / 100)}-minute walk will help you comfortably reach your milestone!`
        : `Outstanding effort—you have surpassed your daily walking target!`
    }`;
  } else {
    fallbackText = `Consistency is the foundation of athletic longevity. You are tracking ${context.todaySteps || 0} steps and ${context.waterMl || 0} ml of water today. Focus on small, repeatable wins: stay hydrated, stretch periodically, and take movement breaks. How else can I guide your routine today?`;
  }

  return {
    reply: fallbackText,
    extractedData,
  };
}
