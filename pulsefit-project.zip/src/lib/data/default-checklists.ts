import { ChecklistItem, TimeOfDay } from '@/types/pulsefit';

export interface ChecklistTemplateItem {
  title: string;
  category: 'hydration' | 'movement' | 'nutrition' | 'recovery' | 'mindset' | 'custom';
  time_of_day: TimeOfDay;
  order_index: number;
  reminder_time?: string;
}

export const DEFAULT_CHECKLIST_TEMPLATE: ChecklistTemplateItem[] = [
  // Morning
  {
    title: 'Wake up on schedule & take 3 deep breaths',
    category: 'mindset',
    time_of_day: 'morning',
    order_index: 1,
    reminder_time: '07:00'
  },
  {
    title: 'Drink 500 ml fresh water',
    category: 'hydration',
    time_of_day: 'morning',
    order_index: 2,
    reminder_time: '07:15'
  },
  {
    title: 'Complete 10-minute morning mobility / stretching',
    category: 'movement',
    time_of_day: 'morning',
    order_index: 3,
    reminder_time: '07:30'
  },
  {
    title: 'Take a brisk morning walk (2,000 steps)',
    category: 'movement',
    time_of_day: 'morning',
    order_index: 4,
    reminder_time: '08:00'
  },
  {
    title: 'Complete morning wellness check-in',
    category: 'mindset',
    time_of_day: 'morning',
    order_index: 5,
    reminder_time: '08:30'
  },

  // Afternoon
  {
    title: 'Log balanced lunch & note dietary satisfaction',
    category: 'nutrition',
    time_of_day: 'afternoon',
    order_index: 6,
    reminder_time: '13:00'
  },
  {
    title: 'Midday hydration (500 ml water)',
    category: 'hydration',
    time_of_day: 'afternoon',
    order_index: 7,
    reminder_time: '14:30'
  },
  {
    title: 'Take 5-minute active movement break from desk',
    category: 'movement',
    time_of_day: 'afternoon',
    order_index: 8,
    reminder_time: '15:30'
  },
  {
    title: 'Complete scheduled exercise / workout session',
    category: 'movement',
    time_of_day: 'afternoon',
    order_index: 9,
    reminder_time: '17:00'
  },

  // Evening
  {
    title: 'Check and hit daily walking step goal',
    category: 'movement',
    time_of_day: 'evening',
    order_index: 10,
    reminder_time: '18:30'
  },
  {
    title: 'Evening hydration (drink 400 ml water)',
    category: 'hydration',
    time_of_day: 'evening',
    order_index: 11,
    reminder_time: '19:30'
  },
  {
    title: 'Record dinner & review portion balance',
    category: 'nutrition',
    time_of_day: 'evening',
    order_index: 12,
    reminder_time: '20:30'
  },
  {
    title: 'Screen wind-down 45 minutes prior to sleep',
    category: 'recovery',
    time_of_day: 'evening',
    order_index: 13,
    reminder_time: '21:30'
  },

  // Night
  {
    title: 'Record sleep schedule & lights out time',
    category: 'recovery',
    time_of_day: 'night',
    order_index: 14,
    reminder_time: '22:15'
  },
  {
    title: 'Complete daily health review & celebrate wins',
    category: 'mindset',
    time_of_day: 'night',
    order_index: 15,
    reminder_time: '22:30'
  }
];

export function generateDailyChecklist(userId: string, date: string): ChecklistItem[] {
  return DEFAULT_CHECKLIST_TEMPLATE.map((tpl, idx) => ({
    id: `chk-${date}-${idx + 1}`,
    checklist_id: `cl-${date}`,
    user_id: userId,
    title: tpl.title,
    category: tpl.category,
    time_of_day: tpl.time_of_day,
    is_completed: false,
    order_index: tpl.order_index,
    reminder_time: tpl.reminder_time
  }));
}
