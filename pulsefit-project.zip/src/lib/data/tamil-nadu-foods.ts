export interface FoodItemDef {
  id: string;
  name: string;
  region: 'Tamil Nadu' | 'South Indian' | 'North Indian' | 'General Healthy';
  dietType: 'vegetarian' | 'non_vegetarian' | 'vegan' | 'eggetarian';
  mealType: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  serving: string;
  estCalories: number;
  estProteinG: number;
  estCarbsG: number;
  estFatG: number;
  isBudgetFriendly: boolean;
  healthBenefits: string;
}

export const REGIONAL_FOOD_DATABASE: FoodItemDef[] = [
  {
    id: 'tn-1',
    name: 'Steamed Idli with Drumstick Sambar & Mint Chutney',
    region: 'Tamil Nadu',
    dietType: 'vegan',
    mealType: 'breakfast',
    serving: '3 idlis with 1 cup sambar',
    estCalories: 260,
    estProteinG: 8.5,
    estCarbsG: 50.0,
    estFatG: 2.5,
    isBudgetFriendly: true,
    healthBenefits: 'Fermented naturally for gut microbiome, easy to digest, low in saturated fat.'
  },
  {
    id: 'tn-2',
    name: 'Ragi Kali (Finger Millet Mudde) with Keerai Kulambu',
    region: 'Tamil Nadu',
    dietType: 'vegan',
    mealType: 'lunch',
    serving: '1 medium kali ball with 1.5 cups greens curry',
    estCalories: 340,
    estProteinG: 10.0,
    estCarbsG: 64.0,
    estFatG: 3.5,
    isBudgetFriendly: true,
    healthBenefits: 'High calcium and dietary fiber, slow-releasing complex carbs for steady energy.'
  },
  {
    id: 'tn-3',
    name: 'Kambu Koozh (Pearl Millet Porridge) with Small Onions & Curd',
    region: 'Tamil Nadu',
    dietType: 'vegetarian',
    mealType: 'breakfast',
    serving: '1 large bowl (350ml)',
    estCalories: 220,
    estProteinG: 7.0,
    estCarbsG: 41.0,
    estFatG: 3.0,
    isBudgetFriendly: true,
    healthBenefits: 'Traditional cooling summer staple, rich in magnesium, iron, and probiotics.'
  },
  {
    id: 'tn-4',
    name: 'Brown Rice with Paruppu (Dal), Ghee & Vazhaithandu Poriyal (Plantain Stem)',
    region: 'Tamil Nadu',
    dietType: 'vegetarian',
    mealType: 'lunch',
    serving: '1 cup brown rice, 1/2 cup dal, 1 cup stem poriyal',
    estCalories: 430,
    estProteinG: 14.0,
    estCarbsG: 72.0,
    estFatG: 8.0,
    isBudgetFriendly: true,
    healthBenefits: 'Plantain stem provides excellent dietary fiber and supports renal health.'
  },
  {
    id: 'tn-5',
    name: 'Sundal (Spiced Chickpea / Black Chana Stir-fry)',
    region: 'Tamil Nadu',
    dietType: 'vegan',
    mealType: 'snack',
    serving: '1 medium cup (150g)',
    estCalories: 190,
    estProteinG: 9.5,
    estCarbsG: 28.0,
    estFatG: 4.5,
    isBudgetFriendly: true,
    healthBenefits: 'Wholesome evening protein snack with antioxidant mustard seeds and curry leaves.'
  },
  {
    id: 'tn-6',
    name: 'Meen Kulambu (Tamarind Fish Curry) with Steamed Rice',
    region: 'Tamil Nadu',
    dietType: 'non_vegetarian',
    mealType: 'lunch',
    serving: '1 piece fish in curry with 1 cup rice',
    estCalories: 410,
    estProteinG: 26.0,
    estCarbsG: 52.0,
    estFatG: 9.0,
    isBudgetFriendly: true,
    healthBenefits: 'Abundant in heart-healthy Omega-3 fatty acids and lean protein.'
  },
  {
    id: 'tn-7',
    name: 'Country Chicken Sukka (Nattu Kozhi) with Whole Wheat Chapati',
    region: 'Tamil Nadu',
    dietType: 'non_vegetarian',
    mealType: 'dinner',
    serving: '120g chicken sukka with 2 chapatis',
    estCalories: 460,
    estProteinG: 32.0,
    estCarbsG: 44.0,
    estFatG: 14.0,
    isBudgetFriendly: false,
    healthBenefits: 'Lean protein source seasoned with black pepper, garlic, and fresh turmeric.'
  },
  {
    id: 'tn-8',
    name: 'Egg Podimas (Spiced Scrambled Eggs) with Wheat Dosa',
    region: 'Tamil Nadu',
    dietType: 'eggetarian',
    mealType: 'dinner',
    serving: '2 eggs podimas with 2 thin wheat dosas',
    estCalories: 350,
    estProteinG: 18.0,
    estCarbsG: 38.0,
    estFatG: 13.0,
    isBudgetFriendly: true,
    healthBenefits: 'High bioavailability complete protein and essential choline.'
  },
  {
    id: 'tn-9',
    name: 'Neer Mor (Spiced Buttermilk with Ginger & Coriander)',
    region: 'Tamil Nadu',
    dietType: 'vegetarian',
    mealType: 'snack',
    serving: '1 large glass (250ml)',
    estCalories: 45,
    estProteinG: 2.5,
    estCarbsG: 4.0,
    estFatG: 2.0,
    isBudgetFriendly: true,
    healthBenefits: 'Natural electrolytes, excellent hydration, and digestive cooling.'
  },
  {
    id: 'tn-10',
    name: 'Thinai (Foxtail Millet) Pongal with Veg Kootu',
    region: 'Tamil Nadu',
    dietType: 'vegetarian',
    mealType: 'dinner',
    serving: '1 cup millet pongal with 1/2 cup kootu',
    estCalories: 330,
    estProteinG: 11.0,
    estCarbsG: 52.0,
    estFatG: 7.5,
    isBudgetFriendly: true,
    healthBenefits: 'Low glycemic index millet ideal for evening satiety and metabolic balance.'
  }
];
