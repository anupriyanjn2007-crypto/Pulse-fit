export interface ExerciseDef {
  id: string;
  name: string;
  category: 'strength' | 'cardio' | 'mobility' | 'yoga' | 'core';
  targetMuscle: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  equipment: 'none' | 'dumbbells' | 'barbell' | 'resistance_band' | 'mat' | 'kettlebell';
  location: 'home' | 'gym' | 'both';
  instructions: string[];
  tips: string;
  lowImpactAlternative?: string;
}

export const EXERCISE_LIBRARY: ExerciseDef[] = [
  {
    id: 'ex-1',
    name: 'Bodyweight Squats',
    category: 'strength',
    targetMuscle: 'Quadriceps & Glutes',
    difficulty: 'beginner',
    equipment: 'none',
    location: 'both',
    instructions: [
      'Stand with feet shoulder-width apart, toes pointing slightly outward.',
      'Hinge hips backward and bend knees as if sitting back into a chair.',
      'Lower down until thighs are parallel to the ground or comfortable depth.',
      'Press through full foot to return smoothly to standing.'
    ],
    tips: 'Keep chest upright and knees tracking aligned with second toes.',
    lowImpactAlternative: 'Chair-assisted sit-to-stands'
  },
  {
    id: 'ex-2',
    name: 'Push-Ups',
    category: 'strength',
    targetMuscle: 'Chest, Shoulders & Triceps',
    difficulty: 'intermediate',
    equipment: 'none',
    location: 'both',
    instructions: [
      'Begin in high plank with hands slightly wider than shoulder width.',
      'Engage core and glutes to maintain a straight line from heels to head.',
      'Lower chest towards floor by bending elbows at roughly 45 degrees.',
      'Push firmly through palms to full arm extension without locking joints.'
    ],
    tips: 'Avoid arching your lower back or letting hips sag.',
    lowImpactAlternative: 'Incline wall push-ups or knee-supported push-ups'
  },
  {
    id: 'ex-3',
    name: 'Dumbbell Romanian Deadlift',
    category: 'strength',
    targetMuscle: 'Hamstrings & Glutes',
    difficulty: 'intermediate',
    equipment: 'dumbbells',
    location: 'both',
    instructions: [
      'Hold a dumbbell in each hand with palms facing thighs.',
      'Soft bend in knees, push hips backward while lowering weights along shins.',
      'Keep back flat and lats engaged until feeling a gentle hamstring stretch.',
      'Drive hips forward to stand tall and squeeze glutes at the top.'
    ],
    tips: 'Movement originates at the hip hinge, not by bending the spine.',
    lowImpactAlternative: 'Unweighted bodyweight good mornings'
  },
  {
    id: 'ex-4',
    name: 'Brisk Walking Interval',
    category: 'cardio',
    targetMuscle: 'Cardiovascular & Calves',
    difficulty: 'beginner',
    equipment: 'none',
    location: 'both',
    instructions: [
      'Start with a comfortable 2-minute warmup stroll.',
      'Accelerate to a brisk pace where conversation is possible but slightly breathless.',
      'Swing arms naturally in rhythm with footsteps.',
      'Complete 15-30 minutes and cool down with gentle pacing.'
    ],
    tips: 'Focus on tall posture and landing gently through midfoot.',
    lowImpactAlternative: 'Flat surface walking'
  },
  {
    id: 'ex-5',
    name: 'Plank Hold',
    category: 'core',
    targetMuscle: 'Core & Transverse Abdominis',
    difficulty: 'beginner',
    equipment: 'mat',
    location: 'both',
    instructions: [
      'Rest forearms on mat with elbows under shoulders.',
      'Step feet back to balance on toes.',
      'Contract abdomen, glutes, and quadriceps firmly.',
      'Breathe steadily while holding position for 20-45 seconds.'
    ],
    tips: 'Imagine pulling elbows toward toes to intensify abdominal engagement.',
    lowImpactAlternative: 'Elevated forearm plank on bench'
  },
  {
    id: 'ex-6',
    name: 'Glute Bridges',
    category: 'strength',
    targetMuscle: 'Glutes & Lower Back',
    difficulty: 'beginner',
    equipment: 'mat',
    location: 'both',
    instructions: [
      'Lie face up on mat with knees bent and feet flat on floor hip-width apart.',
      'Drive through heels to lift hips towards ceiling until thighs and torso align.',
      'Pause at top for 2 seconds with strong glute contraction.',
      'Lower down under control.'
    ],
    tips: 'Avoid hyperextending the lower back at the peak.',
    lowImpactAlternative: 'Isometric glute bridge hold'
  },
  {
    id: 'ex-7',
    name: 'Cat-Cow Mobility Flow',
    category: 'mobility',
    targetMuscle: 'Spine & Back Extensors',
    difficulty: 'beginner',
    equipment: 'mat',
    location: 'both',
    instructions: [
      'Start on hands and knees with wrists under shoulders and knees under hips.',
      'Inhale: Drop belly gently, lift chest and tailbone (Cow pose).',
      'Exhale: Round spine upward toward ceiling, tucking chin to chest (Cat pose).',
      'Transition smoothly between poses for 10-12 rhythmic breaths.'
    ],
    tips: 'Move smoothly and do not force range of motion.',
    lowImpactAlternative: 'Seated chair cat-cow'
  },
  {
    id: 'ex-8',
    name: 'Dumbbell Overhead Shoulder Press',
    category: 'strength',
    targetMuscle: 'Deltoids & Triceps',
    difficulty: 'intermediate',
    equipment: 'dumbbells',
    location: 'both',
    instructions: [
      'Sit or stand tall with dumbbells at shoulder height, palms forward.',
      'Brace core and press weights overhead until arms are extended overhead.',
      'Lower smoothly back to starting position at ear level.'
    ],
    tips: 'Do not arch lower back; press straight up without tilting neck.',
    lowImpactAlternative: 'Resistance band seated overhead press'
  },
  {
    id: 'ex-9',
    name: 'Surya Namaskar (Sun Salutation)',
    category: 'yoga',
    targetMuscle: 'Full Body Mobility & Mind-Body',
    difficulty: 'beginner',
    equipment: 'mat',
    location: 'both',
    instructions: [
      'Pranamasana (Prayer pose) standing grounded.',
      'Hastauttanasana (Raised arms pose) with gentle reach upward.',
      'Padahastasana (Forward fold) with soft knees.',
      'Ashwa Sanchalanasana (Lunge) followed by Dandasana (Plank).',
      'Ashtanga Namaskara, Bhujangasana (Cobra), Adho Mukha Svanasana (Downward Dog).',
      'Flow rhythmically back to standing with synchronized breathing.'
    ],
    tips: 'Move mindfully and listen to your joint comfort levels.',
    lowImpactAlternative: 'Gentle chair Surya Namaskar'
  },
  {
    id: 'ex-10',
    name: 'Kettlebell Deadlift / Goblet Squat',
    category: 'strength',
    targetMuscle: 'Legs, Hips & Upper Back',
    difficulty: 'intermediate',
    equipment: 'kettlebell',
    location: 'both',
    instructions: [
      'Stand over kettlebell with feet hip-width apart.',
      'Hinge hips, grip handle firmly with both hands.',
      'Engage lats, drive feet into the floor to stand tall.',
      'Return weight to floor under continuous control.'
    ],
    tips: 'Keep weight close to body center throughout movement.',
    lowImpactAlternative: 'Dumbbell sumo deadlift'
  }
];
