export type Gender = 'male' | 'female' | 'non_binary' | 'prefer_not_to_say';

export type ActivityLevel = 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active' | 'extremely_active';

export type FitnessExperience = 'beginner' | 'intermediate' | 'advanced';

export type PrimaryGoal = 
  | 'weight_management'
  | 'muscle_building'
  | 'strength_improvement'
  | 'fat_loss'
  | 'general_fitness'
  | 'endurance_improvement'
  | 'flexibility_mobility'
  | 'healthy_lifestyle'
  | 'better_daily_activity';

export type DietaryType = 'vegetarian' | 'non_vegetarian' | 'vegan' | 'eggetarian' | 'other';

export type BMICategory = 
  | 'Underweight'
  | 'Normal weight'
  | 'Overweight'
  | 'Obesity Class I'
  | 'Obesity Class II'
  | 'Obesity Class III'
  | 'Youth / Age-Adjusted';

export interface Profile {
  id: string;
  email?: string;
  full_name: string;
  dob?: string;
  age?: number;
  country: string;
  preferred_language: string;
  timezone: string;
  gender?: Gender;
  avatar_url?: string;
  onboarding_completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserPreferences {
  user_id: string;
  exercise_preferences: string[];
  equipment_available: string[];
  health_limitations: string;
  dietary_type: DietaryType;
  cuisine_preferences: string[];
  budget_friendly: boolean;
  allergies: string[];
  meal_schedule: {
    breakfast: string;
    lunch: string;
    snack: string;
    dinner: string;
  };
  daily_available_minutes: number;
  workout_location_preference: 'home' | 'gym' | 'outdoor';
}

export interface FitnessGoals {
  user_id: string;
  primary_goal: PrimaryGoal;
  secondary_goals: string[];
  target_weight_kg?: number;
  target_date?: string;
  weekly_workout_target: number;
  daily_step_goal: number;
  daily_water_goal_ml: number;
  daily_sleep_goal_hrs: number;
}

export interface BodyMeasurement {
  id: string;
  user_id: string;
  measured_at: string;
  weight_kg: number;
  height_cm: number;
  bmi: number;
  bmi_category: BMICategory;
  waist_cm?: number;
  body_fat_pct?: number;
  is_minor: boolean;
  notes?: string;
}

export interface DailyHealthLog {
  id: string;
  user_id: string;
  date: string; // YYYY-MM-DD
  total_steps: number;
  distance_meters: number;
  active_minutes: number;
  active_calories: number;
  water_ml: number;
  sleep_minutes: number;
  checklist_completion_pct: number;
  wellness_score: number;
  updated_at: string;
}

export type StepDataSource = 'health_connect' | 'device_motion' | 'wearable' | 'manual';

export interface StepRecord {
  id: string;
  user_id: string;
  recorded_date: string;
  start_time?: string;
  end_time?: string;
  step_count: number;
  distance_meters: number;
  active_seconds: number;
  source: StepDataSource;
  source_device?: string;
  external_sync_id?: string;
  created_at: string;
}

export interface WorkoutExercise {
  id: string;
  plan_id?: string;
  exercise_name: string;
  target_muscle: string;
  sets: number;
  reps?: number;
  duration_sec?: number;
  rest_sec: number;
  order_index: number;
  low_impact_alternative?: string;
  instructions: string;
}

export interface WorkoutPlan {
  id: string;
  user_id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  goal_type: string;
  days_per_week: number;
  estimated_duration_min: number;
  is_active: boolean;
  is_ai_generated: boolean;
  exercises: WorkoutExercise[];
  created_at: string;
}

export interface WorkoutHistory {
  id: string;
  user_id: string;
  plan_id?: string;
  workout_title: string;
  completed_at: string;
  duration_minutes: number;
  calories_burned?: number;
  perceived_exertion?: number; // 1-10
  exercises_completed: {
    exercise_name: string;
    sets_completed: number;
    weight_kg?: number;
    notes?: string;
  }[];
  notes?: string;
}

export type TimeOfDay = 'morning' | 'afternoon' | 'evening' | 'night';

export interface ChecklistItem {
  id: string;
  checklist_id: string;
  user_id: string;
  title: string;
  category: 'hydration' | 'movement' | 'nutrition' | 'recovery' | 'mindset' | 'custom';
  time_of_day: TimeOfDay;
  is_completed: boolean;
  completed_at?: string;
  order_index: number;
  reminder_time?: string;
}

export interface DailyChecklist {
  id: string;
  user_id: string;
  date: string;
  total_items: number;
  completed_items: number;
  is_fully_completed: boolean;
  items: ChecklistItem[];
}

export interface WaterLog {
  id: string;
  user_id: string;
  logged_at: string;
  log_date: string;
  amount_ml: number;
  beverage_type: string;
}

export interface MealLog {
  id: string;
  user_id: string;
  meal_date: string;
  meal_type: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  food_items: string;
  est_calories: number;
  est_protein_g: number;
  est_carbs_g: number;
  est_fat_g: number;
  is_estimate: boolean;
  notes?: string;
  created_at: string;
}

export interface SleepLog {
  id: string;
  user_id: string;
  sleep_date: string;
  sleep_start: string;
  sleep_end: string;
  duration_minutes: number;
  quality_score?: number; // 1-100
  restlessness_notes?: string;
}

export type MoodType = 'great' | 'good' | 'okay' | 'tired' | 'stressed';

export interface WellnessCheckin {
  id: string;
  user_id: string;
  checkin_date: string;
  mood: MoodType;
  energy_level: number; // 1-10
  stress_level: number; // 1-10
  notes?: string;
}

export interface Reminder {
  id: string;
  user_id: string;
  reminder_type: 'water' | 'workout' | 'walking' | 'movement' | 'sleep' | 'checklist' | 'weight' | 'weekly_review';
  time_of_day: string; // HH:mm
  days_of_week: number[]; // 1=Mon, 7=Sun
  is_enabled: boolean;
  notification_channel: 'in_app' | 'browser_push' | 'both';
}

export interface Achievement {
  id: string;
  user_id: string;
  badge_code: string;
  badge_name: string;
  badge_category: 'streak' | 'steps' | 'workout' | 'hydration' | 'consistency';
  badge_description: string;
  icon_name: string;
  unlocked_at?: string;
  progress_val: number;
  target_val: number;
  is_unlocked: boolean;
}

export interface ExtractedHealthData {
  type: 'steps' | 'water' | 'workout' | 'sleep' | 'weight' | 'none';
  value: number;
  unit: string;
  date?: string;
  confidence: number;
  confirmation_prompt: string;
}

export interface AIMessage {
  id: string;
  conversation_id: string;
  user_id: string;
  role: 'user' | 'model' | 'system';
  content: string;
  extracted_data?: ExtractedHealthData;
  created_at: string;
}

export interface DeviceIntegration {
  id: string;
  user_id: string;
  provider: 'health_connect' | 'device_motion' | 'wearable' | 'manual_only';
  status: 'connected' | 'disconnected' | 'syncing' | 'error';
  device_name?: string;
  last_sync_at?: string;
  sync_settings: {
    sync_steps: boolean;
    sync_workouts: boolean;
  };
}

export interface ConsentRecord {
  id: string;
  user_id: string;
  consent_type: 'terms_privacy' | 'ai_processing' | 'sensor_motion' | 'notifications';
  is_granted: boolean;
  granted_at: string;
}
