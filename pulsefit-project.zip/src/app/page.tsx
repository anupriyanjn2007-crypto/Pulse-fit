'use client';

import React from 'react';
import Link from 'next/link';
import {
  Activity,
  ShieldCheck,
  Bot,
  CheckSquare,
  Footprints,
  Flame,
  ArrowRight,
  Sparkles,
  Lock,
  Heart,
  Droplets,
  Moon,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#090D14] text-[#F8FAFC] selection:bg-[#CCFF00] selection:text-black">
      {/* Top Athletic Banner */}
      <div className="bg-[#111827] border-b border-[#1F2E45] px-4 py-2 text-center text-xs text-[#94A3B8]">
        <span className="text-[#CCFF00] font-semibold mr-2">NEW</span>
        PULSEFIT 2.0 with Hardware Motion Sensor Tracking & Indian / Tamil Nadu Nutrition Engine
      </div>

      {/* Navigation Bar */}
      <header className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md group-hover:scale-105 transition-transform">
            ⚡
          </div>
          <span className="text-xl font-black tracking-tight text-[#F8FAFC]">
            PULSE<span className="text-[#CCFF00]">FIT</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8 text-xs font-medium text-[#94A3B8]">
          <a href="#features" className="hover:text-[#F8FAFC] transition-colors">
            Features
          </a>
          <a href="#checklist" className="hover:text-[#F8FAFC] transition-colors">
            Checklist System
          </a>
          <a href="#coach" className="hover:text-[#F8FAFC] transition-colors">
            AI Coach
          </a>
          <a href="#privacy" className="hover:text-[#F8FAFC] transition-colors">
            Database Security
          </a>
        </div>

        <div className="flex items-center gap-3">
          <Link href="/auth/login">
            <Button variant="ghost" size="sm">
              Sign In
            </Button>
          </Link>
          <Link href="/onboarding">
            <Button variant="primary" size="sm" className="hidden sm:inline-flex">
              Get Started <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-20 text-center">
        {/* Glow ambient background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-[#CCFF00]/10 blur-[120px] pointer-events-none rounded-full" />

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#182233] border border-[#CCFF00]/30 text-xs text-[#CCFF00] mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Intelligent Personal Fitness Environment</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight max-w-4xl mx-auto leading-[1.1]">
          Engineered For <span className="text-gradient-lime">Athletic Longevity</span> & Real Daily Progress.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-[#94A3B8] max-w-2xl mx-auto leading-relaxed">
          Not an ordinary data-entry app. PULSEFIT unites live motion step tracking, an advanced four-phase daily
          routine system, and a private AI coach tailored to your unique biological measurements.
        </p>

        {/* Hero CTAs */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/onboarding" className="w-full sm:w-auto">
            <Button size="lg" className="w-full sm:w-auto text-base px-8 py-4">
              Begin Personalized Onboarding <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
          <Link href="/dashboard" className="w-full sm:w-auto">
            <Button variant="secondary" size="lg" className="w-full sm:w-auto text-base px-6">
              Launch Live Dashboard
            </Button>
          </Link>
        </div>

        {/* Trust Badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-xs text-[#94A3B8]">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#00F0FF]" /> Row-Level Security Enforced
          </span>
          <span className="flex items-center gap-1.5">
            <Lock className="w-4 h-4 text-[#CCFF00]" /> 100% Private (No Ads)
          </span>
          <span className="flex items-center gap-1.5">
            <Footprints className="w-4 h-4 text-[#CCFF00]" /> Hardware Accelerometer Support
          </span>
          <span className="flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-[#00F0FF]" /> Age-Appropriate Safety Guardrails
          </span>
        </div>

        {/* Interactive Dashboard Live Mockup */}
        <div className="mt-16 relative rounded-3xl p-1 bg-gradient-to-b from-[#1F2E45] to-[#090D14] shadow-2xl">
          <div className="bg-[#111827] rounded-[22px] p-6 text-left border border-[#1F2E45]">
            {/* Mock Top bar */}
            <div className="flex items-center justify-between pb-4 border-b border-[#1F2E45]/60 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <span className="text-xs font-mono text-[#94A3B8] ml-2">pulsefit.app/dashboard</span>
              </div>
              <Badge variant="lime">Live Activity Sync</Badge>
            </div>

            {/* Quick Metrics Grid Preview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-[#182233] p-4 rounded-xl border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
                  <span>Daily Steps</span>
                  <Footprints className="w-4 h-4 text-[#CCFF00]" />
                </div>
                <div className="text-2xl font-bold text-[#F8FAFC]">6,420</div>
                <div className="text-[11px] text-[#CCFF00] font-mono mt-1">80% of 8,000 target</div>
              </div>

              <div className="bg-[#182233] p-4 rounded-xl border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
                  <span>Active Energy</span>
                  <Flame className="w-4 h-4 text-orange-400" />
                </div>
                <div className="text-2xl font-bold text-[#F8FAFC]">310 kcal</div>
                <div className="text-[11px] text-[#94A3B8] font-mono mt-1">Estimated burn</div>
              </div>

              <div className="bg-[#182233] p-4 rounded-xl border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
                  <span>Hydration</span>
                  <Droplets className="w-4 h-4 text-[#00F0FF]" />
                </div>
                <div className="text-2xl font-bold text-[#F8FAFC]">1,750 ml</div>
                <div className="text-[11px] text-[#00F0FF] font-mono mt-1">Target: 2,500 ml</div>
              </div>

              <div className="bg-[#182233] p-4 rounded-xl border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
                  <span>Checklist Score</span>
                  <CheckSquare className="w-4 h-4 text-[#CCFF00]" />
                </div>
                <div className="text-2xl font-bold text-[#F8FAFC]">66%</div>
                <div className="text-[11px] text-[#CCFF00] font-mono mt-1">10 of 15 habits done</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section */}
      <section id="features" className="max-w-6xl mx-auto px-4 sm:px-6 py-20 border-t border-[#1F2E45]">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <Badge variant="cyan">ARCHITECTURAL PILLARS</Badge>
          <h2 className="text-3xl sm:text-4xl font-black mt-3">Precision Fitness Without Compromise</h2>
          <p className="text-sm text-[#94A3B8] mt-2">
            Engineered from database security to biomechanical calculations for real human athletes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="sports-card p-6">
            <div className="w-10 h-10 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00] mb-4">
              <Footprints className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold">Multi-Tier Step Tracking</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Prioritizes Android Health Connect and live browser DeviceMotion sensor tracking. Includes manual logging
              with explicit origin badges so you never confuse estimated with verified steps.
            </p>
          </Card>

          <Card className="sports-card p-6">
            <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/15 flex items-center justify-center text-[#00F0FF] mb-4">
              <CheckSquare className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold">4-Phase Daily Checklist</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Structured Morning, Afternoon, Evening, and Night routines. Automatically generated in your local
              timezone, fully customizable, and saved permanently to your private history.
            </p>
          </Card>

          <Card className="sports-card p-6">
            <div className="w-10 h-10 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00] mb-4">
              <Bot className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold">AI Fitness Coach</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Understands your actual logged metrics. Features natural language entry—type &quot;Walked 4,000 steps&quot;
              and confirm with one tap. Built with medical guardrails and minor safety protection.
            </p>
          </Card>
        </div>
      </section>

      {/* Checklist Spotlight */}
      <section id="checklist" className="max-w-6xl mx-auto px-4 sm:px-6 py-20 border-t border-[#1F2E45]">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <Badge variant="lime">DAILY HABIT ENGINE</Badge>
            <h2 className="text-3xl sm:text-4xl font-black mt-3">
              Never Guess What Comes Next in Your Routine.
            </h2>
            <p className="text-sm text-[#94A3B8] mt-4 leading-relaxed">
              Traditional fitness apps only measure what happened after the workout. PULSEFIT guides you through
              the critical habit moments that create consistency: morning hydration, mobility breaks, balanced meals,
              and sleep wind-down.
            </p>
            <ul className="mt-6 space-y-3 text-xs text-[#F8FAFC]">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#CCFF00]" />
                Interactive checkboxes with live completion score
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#CCFF00]" />
                Personalized checklists based on your equipment and schedule
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#CCFF00]" />
                Missed tasks handled constructively without guilt or shame
              </li>
            </ul>
            <div className="mt-8">
              <Link href="/checklist">
                <Button variant="primary">
                  Explore Checklist System <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
          </div>

          <div className="bg-[#111827] border border-[#1F2E45] rounded-2xl p-6">
            <h4 className="text-xs font-mono uppercase tracking-wider text-[#94A3B8] mb-4">
              Today&apos;s Routine (Sample)
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center gap-3">
                  <span className="w-5 h-5 rounded-md bg-[#CCFF00] flex items-center justify-center text-black text-xs font-bold">
                    ✓
                  </span>
                  <span className="text-xs line-through text-[#94A3B8]">Drink 500 ml fresh water</span>
                </div>
                <span className="text-[10px] text-[#64748B] font-mono">07:15 AM</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center gap-3">
                  <span className="w-5 h-5 rounded-md bg-[#CCFF00] flex items-center justify-center text-black text-xs font-bold">
                    ✓
                  </span>
                  <span className="text-xs line-through text-[#94A3B8]">10-min morning mobility flow</span>
                </div>
                <span className="text-[10px] text-[#64748B] font-mono">07:30 AM</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#CCFF00]/40">
                <div className="flex items-center gap-3">
                  <span className="w-5 h-5 rounded-md border border-[#94A3B8]" />
                  <span className="text-xs text-[#F8FAFC]">Complete afternoon exercise session</span>
                </div>
                <span className="text-[10px] text-[#CCFF00] font-mono">05:00 PM</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Privacy & Security Section */}
      <section id="privacy" className="max-w-6xl mx-auto px-4 sm:px-6 py-20 border-t border-[#1F2E45]">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <Badge variant="cyan">DATABASE SECURITY</Badge>
          <h2 className="text-3xl sm:text-4xl font-black mt-3">Your Health Data Belongs Exclusively to You</h2>
          <p className="text-sm text-[#94A3B8] mt-2">
            Every table in PULSEFIT is fortified with PostgreSQL Row Level Security.
          </p>
        </div>

        <div className="bg-[#111827] border border-[#1F2E45] rounded-2xl p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div>
              <div className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#CCFF00]" /> No Public Profiles
              </div>
              <p className="text-xs text-[#94A3B8] mt-2">
                PULSEFIT is private by default. There are no public leaderboards or social feeds that expose your weight,
                measurements or routines.
              </p>
            </div>
            <div>
              <div className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00F0FF]" /> auth.uid() Isolation
              </div>
              <p className="text-xs text-[#94A3B8] mt-2">
                Supabase Row Level Security ensures that even at raw SQL level, User A cannot query or mutate User B&apos;s
                records.
              </p>
            </div>
            <div>
              <div className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#CCFF00]" /> Full Data Export & Deletion
              </div>
              <p className="text-xs text-[#94A3B8] mt-2">
                Export your full health history in clean JSON anytime, or permanently delete your account and all associated
                records with one click.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#1F2E45] py-12 px-4 sm:px-6 max-w-7xl mx-auto text-xs text-[#64748B] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-[#CCFF00] flex items-center justify-center text-black font-black text-xs">
            ⚡
          </div>
          <span className="font-bold text-[#F8FAFC]">PULSEFIT</span>
          <span>© 2026. Production Health & Fitness Platform.</span>
        </div>
        <div className="flex items-center gap-6">
          <Link href="/privacy" className="hover:text-[#F8FAFC] transition-colors">
            Privacy Policy
          </Link>
          <Link href="/settings" className="hover:text-[#F8FAFC] transition-colors">
            Account Controls
          </Link>
          <Link href="/devices" className="hover:text-[#F8FAFC] transition-colors">
            Device Bridge
          </Link>
        </div>
      </footer>
    </div>
  );
}
