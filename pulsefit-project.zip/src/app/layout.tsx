import type { Metadata, Viewport } from 'next';
import './globals.css';
import { PulseFitProvider } from '@/lib/store/pulsefit-store';

export const metadata: Metadata = {
  title: 'PULSEFIT — AI-Powered Personal Health & Fitness Platform',
  description:
    'Private, intelligent personal health and fitness companion with real-time tracking, AI workout plans, and daily habits.',
  manifest: '/manifest.json',
};

export const viewport: Viewport = {
  themeColor: '#090D14',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
      </head>
      <body className="bg-[#090D14] text-[#F8FAFC] antialiased selection:bg-[#CCFF00] selection:text-black">
        <PulseFitProvider>{children}</PulseFitProvider>
      </body>
    </html>
  );
}
