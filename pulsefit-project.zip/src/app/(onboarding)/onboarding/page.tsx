'use client';

import React, { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { calculateBMI, calculateAge } from '@/lib/calculations/bmi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  User,
  Scale,
  Target,
  Clock,
  Dumbbell,
  Utensils,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

const TOTAL_STEPS = 6;

export default function OnboardingPage() {
  const router = useRouter();
  const { completeOnboarding, profile } = usePulseFit();

  const [currentStep, setCurrentStep] = useState(1);

  // Step 1: Personal Info
  const [fullName, setFullName] = useState(profile?.full_name || 'Alex Rivera');
  const [dob, setDob] = useState('1998-05-14');
  const [gender, setGender] = useState<'male' | 'female' | 'non_binary' | 'prefer_not_to_say'>('male');
  const [country, setCountry] = useState('IN');

  // Step 2: Body Measurements
  const [weightKg, setWeightKg] = useState<number>(71.5);
  const [heightCm, setHeightCm] = useState<number>(175);
  const [waistCm, setWaistCm] = useState<number>(82);
  const [targetWeightKg, setTargetWeightKg] = useState<number>(68.0);

  // Step 3: Fitness Goals
  const [primaryGoal, setPrimaryGoal] = useState<
    | 'weight_management'
    | 'muscle_building'
    | 'strength_improvement'
    | 'fat_loss'
    | 'general_fitness'
    | 'endurance_improvement'
    | 'flexibility_mobility'
    | 'healthy_lifestyle'
    | 'better_daily_activity'
  >('general_fitness');

  // Step 4: Lifestyle
  const [activityLevel, setActivityLevel] = useState('moderately_active');
  const [experience, setExperience] = useState('intermediate');
  const [dailyMinutes, setDailyMinutes] = useState(45);

  // Step 5: Exercise Preferences
  const [exercisePreferences, setExercisePreferences] = useState<string[]>([
    'Walking',
    'Strength training',
    'Yoga',
  ]);
  const [equipmentAvailable, setEquipmentAvailable] = useState<string[]>(['Dumbbells', 'Mat']);
  const [healthLimitations, setHealthLimitations] = useState('');

  // Step 6: Food Preferences
  const [dietaryType, setDietaryType] = useState<
    'vegetarian' | 'non_vegetarian' | 'vegan' | 'eggetarian' | 'other'
  >('vegetarian');
  const [cuisinePreferences, setCuisinePreferences] = useState<string[]>([
    'Tamil Nadu',
    'South Indian',
  ]);
  const [budgetFriendly, setBudgetFriendly] = useState(true);

  // Calculations
  const age = useMemo(() => calculateAge(dob), [dob]);
  const bmiResult = useMemo(
    () => calculateBMI(weightKg, heightCm, age),
    [weightKg, heightCm, age]
  );

  function toggleArrayItem(arr: string[], item: string, setter: (val: string[]) => void) {
    if (arr.includes(item)) {
      setter(arr.filter((i) => i !== item));
    } else {
      setter([...arr, item]);
    }
  }

  async function handleFinish() {
    await completeOnboarding({
      fullName,
      dob,
      gender,
      country,
      weightKg,
      heightCm,
      targetWeightKg: age >= 18 ? targetWeightKg : undefined,
      primaryGoal,
      activityLevel,
      experience,
      exercisePreferences,
      equipmentAvailable,
      healthLimitations,
      dietaryType,
      cuisinePreferences,
      budgetFriendly,
    });
    router.push('/dashboard');
  }

  return (
    <div className="min-h-screen bg-[#090D14] text-[#F8FAFC] py-10 px-4 sm:px-6 flex flex-col items-center justify-center">
      {/* Top Header */}
      <div className="text-center mb-8 max-w-xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#182233] border border-[#1F2E45] text-xs text-[#94A3B8] mb-3">
          <span>Step {currentStep} of {TOTAL_STEPS}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#F8FAFC]">
          {currentStep === 1 && 'Personal Information'}
          {currentStep === 2 && 'Body Measurements & BMI'}
          {currentStep === 3 && 'Health & Fitness Goals'}
          {currentStep === 4 && 'Daily Lifestyle & Availability'}
          {currentStep === 5 && 'Exercise & Equipment Preferences'}
          {currentStep === 6 && 'Nutrition & Regional Diet'}
        </h1>
        <p className="text-xs text-[#94A3B8] mt-1">
          {currentStep === 1 && 'Help PULSEFIT configure your athletic baseline.'}
          {currentStep === 2 && 'Automatic screening metrics based on scientific formulas.'}
          {currentStep === 3 && 'Select your focus so we can tailor daily plans and recommendations.'}
          {currentStep === 4 && 'We calibrate workout intensity to your actual daily routine.'}
          {currentStep === 5 && 'Choose workouts that fit your environment and joint comfort.'}
          {currentStep === 6 && 'Nutritional suggestions adapted to your culinary preferences.'}
        </p>
      </div>

      {/* Progress Bar */}
      <div className="w-full max-w-xl h-1.5 bg-[#182233] rounded-full overflow-hidden mb-8">
        <div
          className="h-full bg-gradient-to-r from-[#CCFF00] to-[#00F0FF] transition-all duration-300"
          style={{ width: `${(currentStep / TOTAL_STEPS) * 100}%` }}
        />
      </div>

      <Card className="w-full max-w-xl sports-card p-6 sm:p-8">
        {/* STEP 1 */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <Input
              label="Full Name"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Input
                  label="Date of Birth"
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  required
                />
                <span className="text-[11px] text-[#CCFF00] font-mono mt-1 block">
                  Calculated Age: {age} years
                </span>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Gender (Optional)
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="non_binary">Non-binary</option>
                  <option value="prefer_not_to_say">Prefer not to say</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Country
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
                >
                  <option value="IN">India</option>
                  <option value="US">United States</option>
                  <option value="GB">United Kingdom</option>
                  <option value="SG">Singapore</option>
                  <option value="AE">United Arab Emirates</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Time Zone
                </label>
                <input
                  type="text"
                  readOnly
                  value={Intl.DateTimeFormat().resolvedOptions().timeZone}
                  className="w-full bg-[#182233]/50 border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#94A3B8] cursor-not-allowed font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Weight (kg)"
                type="number"
                step="0.1"
                value={weightKg}
                onChange={(e) => setWeightKg(parseFloat(e.target.value) || 0)}
              />
              <Input
                label="Height (cm)"
                type="number"
                value={heightCm}
                onChange={(e) => setHeightCm(parseFloat(e.target.value) || 0)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Waist Circumference (cm, optional)"
                type="number"
                value={waistCm}
                onChange={(e) => setWaistCm(parseFloat(e.target.value) || 0)}
              />
              {age >= 18 && (
                <Input
                  label="Target Weight (kg)"
                  type="number"
                  step="0.5"
                  value={targetWeightKg}
                  onChange={(e) => setTargetWeightKg(parseFloat(e.target.value) || 0)}
                />
              )}
            </div>

            {/* Live BMI Analysis Display */}
            <div className={`p-4 rounded-xl border border-[#1F2E45] ${bmiResult.bgColor}`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#94A3B8]">
                  Screening Metric (BMI)
                </span>
                <Badge variant={bmiResult.isMinor ? 'cyan' : 'lime'}>
                  {bmiResult.category}
                </Badge>
              </div>
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-black ${bmiResult.color}`}>{bmiResult.bmi}</span>
                <span className="text-xs text-[#94A3B8]">kg/m²</span>
              </div>
              <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
                {bmiResult.explanation}
              </p>

              {bmiResult.healthyWeightRange && (
                <p className="text-[11px] text-[#CCFF00] font-mono mt-2">
                  Estimated healthy reference weight range: {bmiResult.healthyWeightRange.minKg} kg –{' '}
                  {bmiResult.healthyWeightRange.maxKg} kg
                </p>
              )}

              {bmiResult.warning && (
                <div className="flex items-center gap-1.5 text-xs text-amber-400 mt-2 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{bmiResult.warning}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 3 */}
        {currentStep === 3 && (
          <div className="space-y-3">
            {[
              { id: 'general_fitness', label: 'General Fitness & Energy', desc: 'Sustain peak daily vitality and balanced movement' },
              { id: 'weight_management', label: 'Weight Management', desc: 'Gradual, healthy body composition progression' },
              { id: 'muscle_building', label: 'Muscle Building & Hypertrophy', desc: 'Progressive strength training and lean muscle gain' },
              { id: 'strength_improvement', label: 'Strength Improvement', desc: 'Functional strength for everyday performance' },
              { id: 'fat_loss', label: 'Fat Loss', desc: 'Sustainable energy balance and aerobic conditioning', adultOnly: true },
              { id: 'endurance_improvement', label: 'Endurance & Stamina', desc: 'Cardiovascular health and sustained stamina' },
              { id: 'flexibility_mobility', label: 'Flexibility & Mobility', desc: 'Joint longevity, range of motion, and posture' },
              { id: 'better_daily_activity', label: 'Better Daily Activity', desc: 'Break sedentary habits and elevate daily step counts' },
            ]
              .filter((g) => (age < 18 ? !g.adultOnly : true))
              .map((goal) => {
                const isSelected = primaryGoal === goal.id;
                return (
                  <button
                    key={goal.id}
                    type="button"
                    onClick={() => setPrimaryGoal(goal.id as any)}
                    className={`w-full p-3.5 rounded-xl text-left border transition-all ${
                      isSelected
                        ? 'bg-[#182233] border-[#CCFF00] shadow-sm'
                        : 'bg-[#111827] border-[#1F2E45] hover:border-[#94A3B8]/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-sm font-bold ${isSelected ? 'text-[#CCFF00]' : 'text-[#F8FAFC]'}`}>
                        {goal.label}
                      </span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-[#CCFF00]" />}
                    </div>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{goal.desc}</p>
                  </button>
                );
              })}
          </div>
        )}

        {/* STEP 4 */}
        {currentStep === 4 && (
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Current Activity Level
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'sedentary', label: 'Sedentary', sub: 'Desk work, minimal walk' },
                  { id: 'lightly_active', label: 'Lightly Active', sub: '1-3 light sessions/wk' },
                  { id: 'moderately_active', label: 'Moderately Active', sub: '3-5 sports/walk/wk' },
                  { id: 'very_active', label: 'Very Active', sub: 'Heavy daily exertion' },
                ].map((act) => (
                  <button
                    key={act.id}
                    type="button"
                    onClick={() => setActivityLevel(act.id)}
                    className={`p-3 rounded-xl text-left border ${
                      activityLevel === act.id
                        ? 'bg-[#182233] border-[#CCFF00]'
                        : 'bg-[#111827] border-[#1F2E45]'
                    }`}
                  >
                    <div className="text-xs font-bold text-[#F8FAFC]">{act.label}</div>
                    <div className="text-[10px] text-[#94A3B8]">{act.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Fitness Experience
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['beginner', 'intermediate', 'advanced'].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setExperience(lvl)}
                    className={`p-2.5 rounded-xl text-center border capitalize text-xs font-semibold ${
                      experience === lvl
                        ? 'bg-[#182233] border-[#00F0FF] text-[#00F0FF]'
                        : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                Daily Available Exercise Time: {dailyMinutes} Minutes
              </label>
              <input
                type="range"
                min="15"
                max="90"
                step="5"
                value={dailyMinutes}
                onChange={(e) => setDailyMinutes(parseInt(e.target.value, 10))}
                className="w-full accent-[#CCFF00] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#64748B] font-mono mt-1">
                <span>15 min</span>
                <span>45 min</span>
                <span>90 min</span>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5 */}
        {currentStep === 5 && (
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Preferred Exercise Types
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  'Home workout',
                  'Gym workout',
                  'Outdoor workout',
                  'Walking',
                  'Running',
                  'Cycling',
                  'Yoga',
                  'Strength training',
                  'Bodyweight exercises',
                ].map((ex) => {
                  const active = exercisePreferences.includes(ex);
                  return (
                    <button
                      key={ex}
                      type="button"
                      onClick={() => toggleArrayItem(exercisePreferences, ex, setExercisePreferences)}
                      className={`p-2.5 rounded-xl text-xs font-medium text-left border ${
                        active
                          ? 'bg-[#182233] border-[#CCFF00] text-[#CCFF00]'
                          : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                      }`}
                    >
                      {ex}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Available Equipment
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {['No Equipment', 'Dumbbells', 'Barbell', 'Resistance Band', 'Mat', 'Kettlebell'].map((eq) => {
                  const active = equipmentAvailable.includes(eq);
                  return (
                    <button
                      key={eq}
                      type="button"
                      onClick={() => toggleArrayItem(equipmentAvailable, eq, setEquipmentAvailable)}
                      className={`p-2 rounded-xl text-xs font-medium border ${
                        active
                          ? 'bg-[#182233] border-[#00F0FF] text-[#00F0FF]'
                          : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                      }`}
                    >
                      {eq}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <Input
                label="Joint or Health Considerations (Optional)"
                placeholder="e.g. Mild lower-back sensitivity, sensitive knees"
                value={healthLimitations}
                onChange={(e) => setHealthLimitations(e.target.value)}
                hint="AI coach will replace high-impact exercises with low-impact alternatives."
              />
            </div>
          </div>
        )}

        {/* STEP 6 */}
        {currentStep === 6 && (
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Dietary Framework
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'vegetarian', label: 'Vegetarian' },
                  { id: 'non_vegetarian', label: 'Non-Vegetarian' },
                  { id: 'vegan', label: 'Vegan' },
                  { id: 'eggetarian', label: 'Eggetarian' },
                  { id: 'other', label: 'Other / Flexitarian' },
                ].map((diet) => (
                  <button
                    key={diet.id}
                    type="button"
                    onClick={() => setDietaryType(diet.id as any)}
                    className={`p-2.5 rounded-xl text-xs font-medium border ${
                      dietaryType === diet.id
                        ? 'bg-[#182233] border-[#CCFF00] text-[#CCFF00]'
                        : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                    }`}
                  >
                    {diet.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
                Culinary Focus & Regional Dishes
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['Tamil Nadu', 'South Indian', 'North Indian', 'Continental Healthy'].map((cuis) => {
                  const active = cuisinePreferences.includes(cuis);
                  return (
                    <button
                      key={cuis}
                      type="button"
                      onClick={() => toggleArrayItem(cuisinePreferences, cuis, setCuisinePreferences)}
                      className={`p-2.5 rounded-xl text-xs font-medium text-left border ${
                        active
                          ? 'bg-[#182233] border-[#00F0FF] text-[#00F0FF]'
                          : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                      }`}
                    >
                      {cuis} Cuisine
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
              <div>
                <span className="text-xs font-bold text-[#F8FAFC]">Budget-Friendly Meal Focus</span>
                <p className="text-[11px] text-[#94A3B8]">
                  Prioritize affordable whole foods (millets, lentils, local greens, seasonal fruit).
                </p>
              </div>
              <input
                type="checkbox"
                checked={budgetFriendly}
                onChange={(e) => setBudgetFriendly(e.target.checked)}
                className="rounded border-[#1F2E45] bg-[#111827] text-[#CCFF00] focus:ring-[#CCFF00] w-4 h-4"
              />
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="mt-8 pt-6 border-t border-[#1F2E45] flex items-center justify-between">
          {currentStep > 1 ? (
            <Button
              type="button"
              variant="outline"
              onClick={() => setCurrentStep((prev) => prev - 1)}
            >
              <ArrowLeft className="w-4 h-4 mr-1" /> Back
            </Button>
          ) : (
            <div />
          )}

          {currentStep < TOTAL_STEPS ? (
            <Button
              type="button"
              variant="primary"
              onClick={() => setCurrentStep((prev) => prev + 1)}
            >
              Continue <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button
              type="button"
              variant="primary"
              onClick={handleFinish}
              className="bg-[#CCFF00] text-black font-bold px-6 shadow-lg shadow-[#CCFF00]/20"
            >
              Generate My Environment <Sparkles className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
