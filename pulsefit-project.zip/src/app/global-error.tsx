'use client';

import React from 'react';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body className="bg-[#090D14] text-[#F8FAFC] flex min-h-screen items-center justify-center p-4">
        <div className="max-w-md text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center mx-auto text-xl font-bold">
            !
          </div>
          <h2 className="text-xl font-black">Something went wrong</h2>
          <p className="text-xs text-[#94A3B8]">{error.message || 'An unexpected application error occurred.'}</p>
          <button
            onClick={() => reset()}
            className="px-4 py-2 bg-[#CCFF00] text-black font-bold text-xs rounded-xl"
          >
            Try Again
          </button>
        </div>
      </body>
    </html>
  );
}
