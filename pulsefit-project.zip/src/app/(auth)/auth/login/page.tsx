'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { createClient } from '@/lib/supabase/client';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { ShieldCheck, Mail, KeyRound, Sparkles } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { login } = usePulseFit();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isMagicLink, setIsMagicLink] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [magicLinkSent, setMagicLinkSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    setLoading(true);

    try {
      const supabase = createClient();

      if (isMagicLink) {
        if (supabase) {
          const { error: otpError } = await supabase.auth.signInWithOtp({
            email,
            options: {
              emailRedirectTo: `${window.location.origin}/dashboard`,
            },
          });
          if (otpError) {
            setError(otpError.message);
            setLoading(false);
            return;
          }
        }
        setMagicLinkSent(true);
        setLoading(false);
        return;
      }

      if (supabase) {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (signInError) {
          setError(signInError.message);
          setLoading(false);
          return;
        }
      }

      await login(email);
      router.push('/dashboard');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Login failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function handleDemoLogin() {
    login('athlete@pulsefit.app');
    router.push('/dashboard');
  }

  return (
    <div className="min-h-screen bg-[#090D14] flex flex-col justify-center items-center px-4 py-12">
      <Link href="/" className="flex items-center gap-2.5 mb-8 group">
        <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md group-hover:scale-105 transition-transform">
          ⚡
        </div>
        <span className="text-2xl font-black tracking-tight text-[#F8FAFC]">
          PULSE<span className="text-[#CCFF00]">FIT</span>
        </span>
      </Link>

      <Card className="w-full max-w-md sports-card p-6 sm:p-8">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-black text-[#F8FAFC]">Sign In to PULSEFIT</h2>
          <p className="text-xs text-[#94A3B8] mt-1">
            Access your private athletic metrics and daily checklist.
          </p>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/15 border border-red-500/30 text-xs text-red-400">
            {error}
          </div>
        )}

        {magicLinkSent ? (
          <div className="p-4 rounded-xl bg-[#00F0FF]/15 border border-[#00F0FF]/30 text-center">
            <Mail className="w-8 h-8 text-[#00F0FF] mx-auto mb-2" />
            <h4 className="text-sm font-bold text-[#F8FAFC]">Magic Link Dispatched</h4>
            <p className="text-xs text-[#94A3B8] mt-1">
              Check <span className="text-[#00F0FF]">{email}</span> for your secure one-click sign in link.
            </p>
          </div>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <Input
              label="Email Address"
              type="email"
              placeholder="athlete@domain.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            {!isMagicLink && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider">
                    Password
                  </label>
                  <Link
                    href="/auth/forgot-password"
                    className="text-xs text-[#CCFF00] hover:underline"
                  >
                    Forgot Password?
                  </Link>
                </div>
                <Input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-xs text-[#94A3B8] cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-[#1F2E45] bg-[#182233] text-[#CCFF00] focus:ring-[#CCFF00]"
                />
                Remember this session
              </label>

              <button
                type="button"
                onClick={() => setIsMagicLink(!isMagicLink)}
                className="text-xs text-[#00F0FF] hover:underline"
              >
                {isMagicLink ? 'Use Password' : 'Use Magic Link'}
              </button>
            </div>

            <Button type="submit" variant="primary" className="w-full py-3" isLoading={loading}>
              {isMagicLink ? 'Send Magic Link' : 'Sign In'}
            </Button>

            {/* Quick Demo Athlete Login */}
            <Button
              type="button"
              variant="secondary"
              onClick={handleDemoLogin}
              className="w-full py-2.5 text-xs text-[#CCFF00] border-[#CCFF00]/30 hover:bg-[#CCFF00]/10"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1" /> Quick Demo Athlete Sign-In
            </Button>
          </form>
        )}

        <div className="mt-6 pt-6 border-t border-[#1F2E45] text-center text-xs text-[#94A3B8]">
          New to PULSEFIT?{' '}
          <Link href="/auth/signup" className="text-[#CCFF00] font-semibold hover:underline">
            Create an Account
          </Link>
        </div>
      </Card>

      <div className="flex items-center gap-2 mt-8 text-xs text-[#64748B]">
        <ShieldCheck className="w-4 h-4 text-[#00F0FF]" />
        <span>End-to-end encrypted session with Supabase Auth</span>
      </div>
    </div>
  );
}
