'use client';

import React from 'react';
import Link from 'next/link';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ArrowRight } from 'lucide-react';

export default function VerifyPage() {
  return (
    <div className="min-h-screen bg-[#090D14] flex flex-col justify-center items-center px-4 py-12">
      <Link href="/" className="flex items-center gap-2.5 mb-8">
        <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md">
          ⚡
        </div>
        <span className="text-2xl font-black tracking-tight text-[#F8FAFC]">
          PULSE<span className="text-[#CCFF00]">FIT</span>
        </span>
      </Link>

      <Card className="w-full max-w-md sports-card p-6 sm:p-8 text-center">
        <div className="w-14 h-14 rounded-2xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00] mx-auto mb-4 border border-[#CCFF00]/30">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-[#F8FAFC]">Email Verified Successfully</h2>
        <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
          Your account ownership is confirmed and your personal health isolation policy is now active.
        </p>

        <div className="mt-6">
          <Link href="/onboarding">
            <Button variant="primary" className="w-full py-3">
              Proceed to Onboarding <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
}
