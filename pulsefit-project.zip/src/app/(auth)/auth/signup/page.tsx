'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { createClient } from '@/lib/supabase/client';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { ShieldCheck, ArrowRight, Lock } from 'lucide-react';

export default function SignupPage() {
  const router = useRouter();
  const { login } = usePulseFit();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!fullName.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    if (password.length < 8) {
      setError('Password must contain at least 8 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!agreedTerms) {
      setError('You must accept the terms of service and privacy statement.');
      return;
    }

    setLoading(true);

    try {
      const supabase = createClient();
      if (supabase) {
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
            emailRedirectTo: `${window.location.origin}/auth/verify`,
          },
        });

        if (signUpError) {
          setError(signUpError.message);
          setLoading(false);
          return;
        }
      }

      // Initialize session and direct into personalized onboarding
      await login(email);
      router.push('/onboarding');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Signup failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#090D14] flex flex-col justify-center items-center px-4 py-12">
      {/* Brand */}
      <Link href="/" className="flex items-center gap-2.5 mb-8 group">
        <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md group-hover:scale-105 transition-transform">
          ⚡
        </div>
        <span className="text-2xl font-black tracking-tight text-[#F8FAFC]">
          PULSE<span className="text-[#CCFF00]">FIT</span>
        </span>
      </Link>

      <Card className="w-full max-w-md sports-card p-6 sm:p-8">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-black text-[#F8FAFC]">Create Your Athlete Account</h2>
          <p className="text-xs text-[#94A3B8] mt-1">
            Private, secure, and personalized health environment.
          </p>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/15 border border-red-500/30 text-xs text-red-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSignup} className="space-y-4">
          <Input
            label="Full Name"
            type="text"
            placeholder="e.g. Alex Rivera"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            required
          />

          <Input
            label="Email Address"
            type="email"
            placeholder="athlete@domain.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <Input
            label="Password"
            type="password"
            placeholder="Minimum 8 characters"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <Input
            label="Confirm Password"
            type="password"
            placeholder="Repeat password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />

          {/* Consent Checkbox */}
          <div className="flex items-start gap-2.5 pt-1">
            <input
              id="terms-check"
              type="checkbox"
              checked={agreedTerms}
              onChange={(e) => setAgreedTerms(e.target.checked)}
              className="mt-0.5 rounded border-[#1F2E45] bg-[#182233] text-[#CCFF00] focus:ring-[#CCFF00]"
            />
            <label htmlFor="terms-check" className="text-xs text-[#94A3B8] leading-tight">
              I agree to the PULSEFIT{' '}
              <Link href="/privacy" className="text-[#CCFF00] underline">
                Terms of Service
              </Link>{' '}
              and confirm that my fitness records will remain private to my authenticated account.
            </label>
          </div>

          <Button type="submit" variant="primary" className="w-full py-3 mt-2" isLoading={loading}>
            Create Account & Begin Onboarding <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </form>

        <div className="mt-6 pt-6 border-t border-[#1F2E45] text-center text-xs text-[#94A3B8]">
          Already have a PULSEFIT profile?{' '}
          <Link href="/auth/login" className="text-[#CCFF00] font-semibold hover:underline">
            Sign In
          </Link>
        </div>
      </Card>

      <div className="flex items-center gap-2 mt-8 text-xs text-[#64748B]">
        <ShieldCheck className="w-4 h-4 text-[#00F0FF]" />
        <span>Row-Level Security isolates every record to your unique Auth UID</span>
      </div>
    </div>
  );
}
