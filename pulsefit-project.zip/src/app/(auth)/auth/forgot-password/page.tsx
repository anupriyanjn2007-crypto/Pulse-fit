'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { createClient } from '@/lib/supabase/client';
import { KeyRound, ArrowLeft, MailCheck } from 'lucide-react';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    setLoading(true);
    try {
      const supabase = createClient();
      if (supabase) {
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth/login`,
        });
        if (resetError) {
          setError(resetError.message);
          setLoading(false);
          return;
        }
      }
      setSent(true);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Reset failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#090D14] flex flex-col justify-center items-center px-4 py-12">
      <Link href="/" className="flex items-center gap-2.5 mb-8">
        <div className="w-10 h-10 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md">
          ⚡
        </div>
        <span className="text-2xl font-black tracking-tight text-[#F8FAFC]">
          PULSE<span className="text-[#CCFF00]">FIT</span>
        </span>
      </Link>

      <Card className="w-full max-w-md sports-card p-6 sm:p-8">
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-[#182233] flex items-center justify-center text-[#CCFF00] mx-auto mb-3 border border-[#1F2E45]">
            <KeyRound className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-black text-[#F8FAFC]">Reset Password</h2>
          <p className="text-xs text-[#94A3B8] mt-1">
            We will dispatch a secure recovery link to your registered email.
          </p>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/15 border border-red-500/30 text-xs text-red-400">
            {error}
          </div>
        )}

        {sent ? (
          <div className="p-4 rounded-xl bg-[#00F0FF]/15 border border-[#00F0FF]/30 text-center">
            <MailCheck className="w-8 h-8 text-[#00F0FF] mx-auto mb-2" />
            <h4 className="text-sm font-bold text-[#F8FAFC]">Recovery Email Dispatched</h4>
            <p className="text-xs text-[#94A3B8] mt-1">
              Instructions have been sent to <span className="text-[#00F0FF]">{email}</span>.
            </p>
            <Link href="/auth/login" className="inline-block mt-4">
              <Button variant="outline" size="sm">
                Return to Sign In
              </Button>
            </Link>
          </div>
        ) : (
          <form onSubmit={handleReset} className="space-y-4">
            <Input
              label="Email Address"
              type="email"
              placeholder="athlete@domain.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <Button type="submit" variant="primary" className="w-full py-3" isLoading={loading}>
              Send Recovery Link
            </Button>
          </form>
        )}

        <div className="mt-6 pt-6 border-t border-[#1F2E45] text-center">
          <Link
            href="/auth/login"
            className="inline-flex items-center gap-1.5 text-xs text-[#94A3B8] hover:text-[#F8FAFC]"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Sign In
          </Link>
        </div>
      </Card>
    </div>
  );
}
