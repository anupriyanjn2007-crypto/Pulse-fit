import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabaseClient } from '@/lib/supabase/server';

export async function GET(req: NextRequest) {
  try {
    const supabase = await createServerSupabaseClient();
    
    if (!supabase) {
      return NextResponse.json({
        notice: 'PulseFit Demo Mode. Export available directly via in-app storage.'
      });
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch user records under RLS
    const [profileRes, measurementsRes, dailyLogsRes, workoutsRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).single(),
      supabase.from('body_measurements').select('*').eq('user_id', user.id).order('measured_at', { ascending: false }),
      supabase.from('daily_health_logs').select('*').eq('user_id', user.id).order('date', { ascending: false }),
      supabase.from('workout_history').select('*').eq('user_id', user.id).order('completed_at', { ascending: false }),
    ]);

    const exportBundle = {
      exportDate: new Date().toISOString(),
      user: { id: user.id, email: user.email },
      profile: profileRes.data,
      measurements: measurementsRes.data,
      dailyLogs: dailyLogsRes.data,
      workoutHistory: workoutsRes.data,
      privacyStatement: 'This export contains your personal health information. Transmitted under user-directed request.',
    };

    return NextResponse.json(exportBundle);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Export failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
