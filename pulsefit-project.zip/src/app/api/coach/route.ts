import { NextRequest, NextResponse } from 'next/server';
import { generateAICoachReply } from '@/lib/ai/gemini-service';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, context } = body;

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Valid prompt string is required' }, { status: 400 });
    }

    if (prompt.length > 1000) {
      return NextResponse.json({ error: 'Prompt exceeds allowable character limit (1000)' }, { status: 400 });
    }

    const coachResponse = await generateAICoachReply(prompt, context || {});
    return NextResponse.json(coachResponse);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Internal coach error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
