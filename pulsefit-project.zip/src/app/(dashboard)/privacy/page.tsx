'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import {
  ShieldCheck,
  Lock,
  Download,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  EyeOff,
  Sparkles,
} from 'lucide-react';

export default function PrivacyPage() {
  const { exportUserData, deleteUserAccount, consents, updateConsent } = usePulseFit();

  const [isExporting, setIsExporting] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [aiConsentEnabled, setAiConsentEnabled] = useState(true);

  async function handleExport() {
    setIsExporting(true);
    const dataStr = await exportUserData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PulseFit_Full_Health_Export_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setIsExporting(false);
  }

  async function handleDeleteAccount() {
    if (deleteConfirmText.toLowerCase() === 'delete') {
      await deleteUserAccount();
    }
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Privacy & Data Sovereignty</h1>
            <Badge variant="lime">Private by Default</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Database Row-Level Security, zero advertising trackers, and full data export.
          </p>
        </div>

        <Button variant="outline" size="sm" onClick={handleExport} isLoading={isExporting}>
          <Download className="w-3.5 h-3.5 mr-1" /> Export All Health Records (JSON)
        </Button>
      </div>

      {/* Security Architecture Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="sports-card p-5">
          <div className="flex items-center gap-2 mb-2 text-[#CCFF00]">
            <Lock className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">No Public Profiles</span>
          </div>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Your body measurements, weight progression, and workout logs are never visible to other users.
            There are no social feeds or public leaderboards.
          </p>
        </Card>

        <Card className="sports-card p-5">
          <div className="flex items-center gap-2 mb-2 text-[#00F0FF]">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Row-Level Security</span>
          </div>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Every table in Supabase PostgreSQL is guarded by PostgreSQL policies ensuring{' '}
            <code className="text-[#00F0FF] font-mono">auth.uid() = user_id</code>.
          </p>
        </Card>

        <Card className="sports-card p-5">
          <div className="flex items-center gap-2 mb-2 text-purple-400">
            <EyeOff className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Zero Ad Trackers</span>
          </div>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            PULSEFIT does not embed third-party advertising SDKs, Facebook pixels, or tracking beacons.
          </p>
        </Card>
      </div>

      {/* AI Processing Consent Controls */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#00F0FF]" />
            <CardTitle>AI Processing & Personalization Consent</CardTitle>
          </div>
          <Badge variant="cyan">User Controlled</Badge>
        </CardHeader>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-sm font-bold text-[#F8FAFC]">
              Anonymized Contextual Coaching
            </span>
            <p className="text-xs text-[#94A3B8] max-w-xl leading-relaxed">
              When enabled, your age, target goals, and step tallies are provided anonymously to the AI service
              to personalize feedback. Your email and name are strictly stripped before processing.
            </p>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={aiConsentEnabled}
              onChange={(e) => setAiConsentEnabled(e.target.checked)}
              className="w-5 h-5 rounded border-[#1F2E45] bg-[#111827] text-[#CCFF00] focus:ring-[#CCFF00]"
            />
            <span className="text-xs font-bold text-[#F8FAFC]">
              {aiConsentEnabled ? 'Enabled' : 'Disabled'}
            </span>
          </label>
        </div>
      </Card>

      {/* Danger Zone: Permanent Account Deletion */}
      <Card className="sports-card p-6 border-red-500/30 bg-red-500/5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-red-400">
              <AlertTriangle className="w-4 h-4" />
              <h3 className="text-sm font-bold">Permanent Account Deletion (GDPR / CCPA)</h3>
            </div>
            <p className="text-xs text-[#94A3B8] mt-1 max-w-xl">
              Permanently purges your user profile, measurements, activity logs, daily checklists, and workout
              history across all database tables. This action cannot be undone.
            </p>
          </div>

          <Button
            variant="danger"
            size="sm"
            onClick={() => setIsDeleteModalOpen(true)}
            className="shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5 mr-1" /> Delete My Account
          </Button>
        </div>
      </Card>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Confirm Irreversible Deletion"
        description="Type 'DELETE' below to purge your entire health history."
      >
        <div className="space-y-4">
          <p className="text-xs text-red-400 font-medium">
            Warning: All 23 relational database tables associated with your account will be deleted immediately.
          </p>

          <Input
            placeholder="Type 'DELETE' to confirm"
            value={deleteConfirmText}
            onChange={(e) => setDeleteConfirmText(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setIsDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              disabled={deleteConfirmText.toLowerCase() !== 'delete'}
              onClick={handleDeleteAccount}
            >
              Confirm Account Destruction
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
