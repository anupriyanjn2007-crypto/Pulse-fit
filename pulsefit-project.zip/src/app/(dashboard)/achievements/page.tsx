'use client';

import React from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import confetti from 'canvas-confetti';
import {
  Award,
  Flame,
  Droplets,
  Footprints,
  Dumbbell,
  CheckCircle2,
  Lock,
  Sparkles,
  Heart,
} from 'lucide-react';

export default function AchievementsPage() {
  const { achievements, currentStreak, todayLog } = usePulseFit();

  function triggerCelebration() {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#CCFF00', '#00F0FF', '#ffffff'],
    });
  }

  const unlockedCount = achievements.filter((a) => a.is_unlocked).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Achievements & Milestones</h1>
            <Badge variant="lime">Healthy Motivation</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Celebrating consistent personal habits. Private to you—no stressful public leaderboards.
          </p>
        </div>

        <Button variant="outline" size="sm" onClick={triggerCelebration}>
          <Sparkles className="w-3.5 h-3.5 mr-1 text-[#CCFF00]" /> Celebrate Progress
        </Button>
      </div>

      {/* Streak Hero Card */}
      <Card className="sports-card p-6 bg-gradient-to-r from-[#111827] via-[#182233] to-[#111827]">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00] border border-[#CCFF00]/30 shadow-lg shadow-[#CCFF00]/10">
              <Flame className="w-9 h-9 fill-[#CCFF00]" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#94A3B8]">
                Active Habit Consistency
              </span>
              <div className="text-4xl font-black text-[#F8FAFC]">{currentStreak} Days</div>
              <p className="text-xs text-[#CCFF00] font-mono mt-0.5">
                4-Day Streak Unlocked • Keep going strong!
              </p>
            </div>
          </div>

          <div className="text-center sm:text-right">
            <span className="text-xs font-bold uppercase tracking-wider text-[#94A3B8] block">
              Badges Earned
            </span>
            <div className="text-3xl font-black text-[#00F0FF]">
              {unlockedCount} / {achievements.length}
            </div>
          </div>
        </div>
      </Card>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((ach) => {
          const pct = Math.min(100, Math.round((ach.progress_val / ach.target_val) * 100));

          return (
            <Card
              key={ach.id}
              className={`sports-card p-6 flex flex-col justify-between transition-all ${
                ach.is_unlocked
                  ? 'border-[#CCFF00]/40 bg-[#182233] cursor-pointer hover:scale-[1.02]'
                  : 'opacity-70 bg-[#111827]'
              }`}
              onClick={() => {
                if (ach.is_unlocked) triggerCelebration();
              }}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center border ${
                      ach.is_unlocked
                        ? 'bg-[#CCFF00]/20 text-[#CCFF00] border-[#CCFF00]/50'
                        : 'bg-[#182233] text-[#64748B] border-[#1F2E45]'
                    }`}
                  >
                    {ach.is_unlocked ? <Award className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
                  </div>
                  <Badge variant={ach.is_unlocked ? 'lime' : 'neutral'}>
                    {ach.is_unlocked ? 'Unlocked' : 'In Progress'}
                  </Badge>
                </div>

                <h3 className="text-base font-bold text-[#F8FAFC]">{ach.badge_name}</h3>
                <p className="text-xs text-[#94A3B8] mt-1.5 leading-relaxed">
                  {ach.badge_description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#1F2E45]/60">
                <div className="flex justify-between text-[11px] font-mono mb-1.5">
                  <span className="text-[#94A3B8]">Progress</span>
                  <span className="text-[#F8FAFC]">
                    {ach.progress_val} / {ach.target_val}
                  </span>
                </div>
                <Progress value={pct} color={ach.is_unlocked ? 'lime' : 'cyan'} />
              </div>
            </Card>
          );
        })}
      </div>

      {/* Non-Shaming Philosophy Banner */}
      <Card className="sports-card p-5 border-[#1F2E45]">
        <div className="flex items-start gap-3">
          <Heart className="w-5 h-5 text-[#00F0FF] shrink-0 mt-0.5" />
          <div className="text-xs text-[#94A3B8] leading-relaxed">
            <strong className="text-[#F8FAFC]">PulseFit Gamification Philosophy: </strong>
            Gamification in PULSEFIT is designed to celebrate healthy, sustainable momentum. We do not punish
            missed days, show guilt-inducing alerts, or compare you with strangers on stressful public leaderboards.
            Your progress is exclusively personal.
          </div>
        </div>
      </Card>
    </div>
  );
}
