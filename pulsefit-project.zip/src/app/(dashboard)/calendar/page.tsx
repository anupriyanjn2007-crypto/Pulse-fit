'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Calendar as CalendarIcon,
  Footprints,
  Dumbbell,
  Droplets,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export default function CalendarPage() {
  const { todayLog, workoutHistory, goals } = usePulseFit();

  const [currentMonth, setCurrentMonth] = useState('November 2026');
  const [selectedDay, setSelectedDay] = useState(6); // Current simulated day

  const stepGoal = goals?.daily_step_goal || 8000;

  // Calendar grid generator for 30-day month starting Sunday
  const daysInMonth = Array.from({ length: 30 }, (_, i) => i + 1);

  // Simulated activity metadata per day
  function getDayMeta(day: number) {
    if (day > selectedDay) {
      return { status: 'future', steps: 0, workout: false };
    }
    if (day === selectedDay) {
      return { status: 'today', steps: todayLog.total_steps, workout: workoutHistory.length > 0 };
    }
    // past days
    const steps = 7000 + ((day * 370) % 3500);
    return {
      status: 'past',
      steps,
      hitStepGoal: steps >= stepGoal,
      workout: day % 2 === 0,
    };
  }

  const selectedMeta = getDayMeta(selectedDay);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Fitness & Activity Calendar</h1>
            <Badge variant="lime">Schedule & Log</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Month-at-a-glance streak consistency and scheduled workout routines.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-xs font-bold text-[#F8FAFC] font-mono px-2">{currentMonth}</span>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Month Calendar Grid (2 cols) */}
        <Card className="sports-card p-6 lg:col-span-2">
          {/* Weekday Headers */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-[#94A3B8] mb-3 uppercase">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {daysInMonth.map((day) => {
              const meta = getDayMeta(day);
              const isSelected = selectedDay === day;

              return (
                <button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  className={`p-2.5 rounded-xl border text-left min-h-[70px] flex flex-col justify-between transition-all ${
                    isSelected
                      ? 'border-[#CCFF00] bg-[#182233] shadow-md shadow-[#CCFF00]/15'
                      : meta.status === 'today'
                      ? 'border-[#00F0FF] bg-[#111827]'
                      : 'border-[#1F2E45] bg-[#111827] hover:border-[#94A3B8]/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold ${
                        isSelected
                          ? 'text-[#CCFF00]'
                          : meta.status === 'today'
                          ? 'text-[#00F0FF]'
                          : 'text-[#F8FAFC]'
                      }`}
                    >
                      {day}
                    </span>
                    {meta.workout && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#CCFF00]" title="Workout Completed" />
                    )}
                  </div>

                  {meta.status !== 'future' && (
                    <div className="text-[10px] font-mono text-[#94A3B8]">
                      {meta.steps >= stepGoal ? (
                        <span className="text-[#CCFF00] font-bold">✓ Goal</span>
                      ) : (
                        <span>{(meta.steps / 1000).toFixed(1)}k</span>
                      )}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </Card>

        {/* Selected Day Inspection Sidebar */}
        <Card className="sports-card p-6 flex flex-col justify-between">
          <div>
            <CardHeader>
              <CardTitle>Day Inspection: Nov {selectedDay}</CardTitle>
              <Badge variant="cyan">Activity Summary</Badge>
            </CardHeader>

            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[#94A3B8]">Total Step Count</span>
                  <Footprints className="w-4 h-4 text-[#CCFF00]" />
                </div>
                <div className="text-xl font-black text-[#F8FAFC]">
                  {selectedMeta.steps.toLocaleString()}
                </div>
                <span className="text-[10px] text-[#94A3B8] font-mono">
                  {selectedMeta.steps >= stepGoal ? 'Goal achieved!' : 'Target not met'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[#94A3B8]">Workout Status</span>
                  <Dumbbell className="w-4 h-4 text-[#00F0FF]" />
                </div>
                <div className="text-base font-bold text-[#F8FAFC]">
                  {selectedMeta.workout ? 'Workout Session Completed' : 'Rest / Recovery Day'}
                </div>
                <span className="text-[10px] text-[#94A3B8] font-mono">
                  {selectedMeta.workout ? 'Logged with RPE rating' : 'Active walking recovery'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[#94A3B8]">Hydration Level</span>
                  <Droplets className="w-4 h-4 text-[#00F0FF]" />
                </div>
                <div className="text-xl font-black text-[#F8FAFC]">
                  {todayLog.water_ml.toLocaleString()} ml
                </div>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-[#64748B] mt-4">
            All calendar days are saved privately to Supabase user history.
          </div>
        </Card>
      </div>
    </div>
  );
}
