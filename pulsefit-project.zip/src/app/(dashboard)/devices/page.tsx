'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Cpu,
  Smartphone,
  Watch,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  Compass,
} from 'lucide-react';

export default function DevicesPage() {
  const { devices, updateDeviceStatus } = usePulseFit();
  const [syncing, setSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  async function handleSyncAll() {
    setSyncing(true);
    setSyncSuccess(false);
    setTimeout(() => {
      setSyncing(false);
      setSyncSuccess(true);
    }, 1200);
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Connected Devices & Health Bridge</h1>
            <Badge variant="cyan">Multi-Source Engine</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Bridge hardware sensors, Health Connect, and wearables with verified source tagging.
          </p>
        </div>

        <Button variant="primary" size="sm" onClick={handleSyncAll} isLoading={syncing}>
          <RefreshCw className="w-3.5 h-3.5 mr-1" /> Sync All Sources
        </Button>
      </div>

      {syncSuccess && (
        <div className="p-3.5 rounded-xl bg-[#CCFF00]/15 border border-[#CCFF00]/30 text-xs text-[#CCFF00] flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Device synchronization verified. Duplicate-record elimination filter applied.</span>
        </div>
      )}

      {/* Integration Sources Grid */}
      <div className="space-y-4">
        {/* Source 1: DeviceMotion Accelerometer */}
        <Card className="sports-card p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00] shrink-0 border border-[#CCFF00]/30">
                <Compass className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-[#F8FAFC]">
                    Device Accelerometer (DeviceMotion API)
                  </h3>
                  <Badge variant="lime">Active Support</Badge>
                </div>
                <p className="text-xs text-[#94A3B8] mt-1 leading-relaxed">
                  Real-time acceleration peak vectoring during active walking sessions.
                  Operates entirely in-browser with zero third-party tracking.
                </p>
                <span className="text-[10px] text-[#64748B] font-mono mt-1 block">
                  Priority Rank 3 • Debounced ~320ms cadence window
                </span>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => updateDeviceStatus('device_motion', 'connected')}
            >
              Calibrated
            </Button>
          </div>
        </Card>

        {/* Source 2: Android Health Connect Bridge */}
        <Card className="sports-card p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#00F0FF]/15 flex items-center justify-center text-[#00F0FF] shrink-0 border border-[#00F0FF]/30">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-[#F8FAFC]">
                    Android Health Connect (Capacitor Companion)
                  </h3>
                  <Badge variant="cyan">Native Bridge Ready</Badge>
                </div>
                <p className="text-xs text-[#94A3B8] mt-1 leading-relaxed">
                  Direct native integration pathway via `@capacitor-community/health-connect`. Reads verified
                  background step records without battery drain.
                </p>
                <span className="text-[10px] text-[#64748B] font-mono mt-1 block">
                  Priority Rank 1 • Overlapping interval deduplication enforced
                </span>
              </div>
            </div>

            <Button
              variant="secondary"
              size="sm"
              onClick={() => updateDeviceStatus('health_connect', 'connected', 'Health Connect (Pixel)')}
            >
              Connect Bridge
            </Button>
          </div>
        </Card>

        {/* Source 3: Wearable Ecosystems */}
        <Card className="sports-card p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#182233] border border-[#1F2E45] flex items-center justify-center text-[#94A3B8] shrink-0">
                <Watch className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-[#F8FAFC]">Wearable Platforms (Fitbit / Garmin / Apple)</h3>
                  <Badge variant="neutral">Cloud Sync</Badge>
                </div>
                <p className="text-xs text-[#94A3B8] mt-1 leading-relaxed">
                  Direct OAuth sync for multi-sensor heart rate and GPS session imports.
                </p>
                <span className="text-[10px] text-[#64748B] font-mono mt-1 block">
                  Priority Rank 2 • Direct API connector
                </span>
              </div>
            </div>

            <Button variant="outline" size="sm" disabled>
              Coming in v2.2
            </Button>
          </div>
        </Card>
      </div>

      {/* Deduplication Guarantee */}
      <Card className="sports-card p-5 border-[#1F2E45]">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-[#CCFF00] shrink-0 mt-0.5" />
          <div className="text-xs text-[#94A3B8] leading-relaxed">
            <strong className="text-[#F8FAFC]">Duplicate Step Prevention Architecture: </strong>
            When both Android Health Connect and the browser motion sensor report steps for the same hour,
            PULSEFIT uses timestamp interval union algorithm. Your step counts are never double-tallied.
          </div>
        </div>
      </Card>
    </div>
  );
}
