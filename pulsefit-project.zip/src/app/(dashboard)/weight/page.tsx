'use client';

import React from 'react';
import Link from 'next/link';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Scale,
  TrendingDown,
  TrendingUp,
  ShieldAlert,
  Sparkles,
  Heart,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export default function WeightManagementPage() {
  const { measurements, goals, profile } = usePulseFit();

  const currentWeight = measurements[0]?.weight_kg || 70;
  const initialWeight = measurements[measurements.length - 1]?.weight_kg || currentWeight;
  const targetWeight = goals?.target_weight_kg;
  const isMinor = profile?.age !== undefined && profile.age < 18;
  const isUnderweight = measurements[0]?.bmi ? measurements[0].bmi < 18.5 : false;

  const weightChange = Math.round((currentWeight - initialWeight) * 10) / 10;

  // Chart data from measurements
  const chartData = [...measurements]
    .reverse()
    .map((m) => ({
      date: new Date(m.measured_at).toLocaleDateString([], { month: 'short', day: 'numeric' }),
      weight: m.weight_kg,
    }));

  // If only 1 measurement, provide realistic trend points for illustration
  const displayChartData =
    chartData.length > 1
      ? chartData
      : [
          { date: 'Week 1', weight: currentWeight + 1.2 },
          { date: 'Week 2', weight: currentWeight + 0.8 },
          { date: 'Week 3', weight: currentWeight + 0.3 },
          { date: 'Current', weight: currentWeight },
        ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Personalized Weight Management</h1>
            <Badge variant="lime">Sustainable Protocol</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Gradual body composition guidance without extreme deficits or crash diets.
          </p>
        </div>

        <Link href="/body">
          <Button variant="outline" size="sm">
            <Scale className="w-3.5 h-3.5 mr-1.5" /> Update Measurements
          </Button>
        </Link>
      </div>

      {/* Safety Alert for Minors or Underweight */}
      {(isMinor || isUnderweight) && (
        <Card className="sports-card p-5 border-cyan-500/30 bg-cyan-500/10">
          <div className="flex items-start gap-3">
            <Heart className="w-5 h-5 text-[#00F0FF] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-[#F8FAFC]">
                {isMinor ? 'Pediatric Safety Notice' : 'Healthy Nourishment Notice'}
              </h4>
              <p className="text-xs text-[#94A3B8] leading-relaxed">
                {isMinor
                  ? 'PULSEFIT does not recommend calorie restriction or weight-reduction targets for individuals under 18 years of age. Focus on nourishing whole foods, athletic movement, and consult a pediatrician for personalized advice.'
                  : 'Your recorded BMI falls within or near the underweight range. Weight restriction is discouraged. Focus on progressive strength training and nutrient-dense foods.'}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Overview Stat Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Current Weight</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2">
            {currentWeight} <span className="text-xs font-normal text-[#94A3B8]">kg</span>
          </div>
          <span className="text-[11px] text-[#CCFF00] font-mono mt-1 block">Active Biometric</span>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Target Goal</span>
          <div className="text-3xl font-black text-[#00F0FF] mt-2">
            {targetWeight ? `${targetWeight} kg` : 'Maintenance'}
          </div>
          <span className="text-[11px] text-[#94A3B8] font-mono mt-1 block">
            {targetWeight
              ? `${Math.abs(Math.round((currentWeight - targetWeight) * 10) / 10)} kg difference`
              : 'Focusing on body composition'}
          </span>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Overall Progress</span>
          <div className="flex items-center gap-2 mt-2">
            {weightChange <= 0 ? (
              <TrendingDown className="w-6 h-6 text-[#CCFF00]" />
            ) : (
              <TrendingUp className="w-6 h-6 text-amber-400" />
            )}
            <span className="text-3xl font-black text-[#F8FAFC]">
              {weightChange > 0 ? `+${weightChange}` : weightChange} kg
            </span>
          </div>
          <span className="text-[11px] text-[#94A3B8] font-mono mt-1 block">Since baseline</span>
        </Card>
      </div>

      {/* Weight Progress Line Chart */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div>
            <CardTitle>Weight Progression Trend</CardTitle>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Healthy, sustainable pacing target: 0.25 kg to 0.5 kg weekly change.
            </p>
          </div>
          <Badge variant="lime">Gradual Curve</Badge>
        </CardHeader>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={displayChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="date" stroke="#64748B" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748B" fontSize={11} tickLine={false} domain={['dataMin - 1', 'dataMax + 1']} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#111827',
                  borderColor: '#1F2E45',
                  borderRadius: '0.75rem',
                  color: '#F8FAFC',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`${val} kg`, 'Weight']}
              />
              <Line
                type="monotone"
                dataKey="weight"
                stroke="#CCFF00"
                strokeWidth={3}
                dot={{ fill: '#CCFF00', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Principles for Sustainable Health */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="sports-card p-6">
          <CardHeader>
            <CardTitle>Sustainable Eating Guidelines</CardTitle>
          </CardHeader>
          <ul className="space-y-3 text-xs text-[#94A3B8]">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Protein at every meal:</strong> Lentils, chickpeas, paneer, eggs,
                lean poultry, or fish preserve muscle mass during routine changes.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">High-fiber millets & greens:</strong> Ragi, Kambu, Thinai, and Keerai
                sustain steady satiety and stabilize glucose curves.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Mindful portions, zero starvation:</strong> Never restrict caloric
                intake drastically. Sustainable consistency beats temporary deprivation.
              </span>
            </li>
          </ul>
        </Card>

        <Card className="sports-card p-6">
          <CardHeader>
            <CardTitle>Movement & Metabolism</CardTitle>
          </CardHeader>
          <ul className="space-y-3 text-xs text-[#94A3B8]">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Daily Step Cadence:</strong> Accumulating 8,000+ daily steps raises
                Non-Exercise Activity Thermogenesis (NEAT) naturally.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Progressive Resistance:</strong> 3-4 weekly sessions of compound
                exercises prevent metabolic slowdown.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Adequate Sleep:</strong> Less than 7 hours of sleep elevates ghrelin
                (hunger hormone) and increases stress-induced cortisol.
              </span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
