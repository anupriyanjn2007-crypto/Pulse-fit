'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import { EXERCISE_LIBRARY, ExerciseDef } from '@/lib/data/exercise-library';
import {
  Zap,
  Search,
  Filter,
  CheckCircle2,
  ShieldCheck,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

export default function ExerciseLibraryPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [activeExercise, setActiveExercise] = useState<ExerciseDef | null>(null);

  const filteredExercises = EXERCISE_LIBRARY.filter((ex) => {
    const matchesSearch =
      ex.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ex.targetMuscle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'all' || ex.category === selectedCategory;
    const matchesDiff = selectedDifficulty === 'all' || ex.difficulty === selectedDifficulty;
    return matchesSearch && matchesCat && matchesDiff;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Exercise & Technique Library</h1>
            <Badge variant="lime">{EXERCISE_LIBRARY.length} Movements</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Biomechanical cues, progression instructions, and joint-friendly low-impact alternatives.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <Card className="sports-card p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search exercise or muscle group (e.g. Squat, Glutes, Chest)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl pl-10 pr-4 py-2.5 text-xs text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#CCFF00]"
            />
          </div>

          <div className="flex gap-2">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#182233] border border-[#1F2E45] rounded-xl px-3 py-2 text-xs text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
            >
              <option value="all">All Disciplines</option>
              <option value="strength">Strength</option>
              <option value="cardio">Cardio</option>
              <option value="mobility">Mobility</option>
              <option value="yoga">Yoga</option>
              <option value="core">Core</option>
            </select>

            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="bg-[#182233] border border-[#1F2E45] rounded-xl px-3 py-2 text-xs text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
            >
              <option value="all">All Levels</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Exercises Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredExercises.map((ex) => (
          <Card
            key={ex.id}
            className="sports-card p-5 cursor-pointer hover:border-[#CCFF00]/60 transition-all flex flex-col justify-between"
            onClick={() => setActiveExercise(ex)}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <Badge
                  variant={
                    ex.difficulty === 'beginner'
                      ? 'lime'
                      : ex.difficulty === 'intermediate'
                      ? 'cyan'
                      : 'warning'
                  }
                >
                  {ex.difficulty}
                </Badge>
                <span className="text-[10px] text-[#94A3B8] capitalize font-mono">{ex.equipment}</span>
              </div>
              <h3 className="text-base font-bold text-[#F8FAFC]">{ex.name}</h3>
              <p className="text-xs text-[#CCFF00] font-mono mt-0.5">{ex.targetMuscle}</p>
              <p className="text-xs text-[#94A3B8] mt-2 line-clamp-2 leading-relaxed">
                {ex.instructions[0]}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-[#1F2E45] flex items-center justify-between text-xs text-[#94A3B8]">
              <span className="capitalize">{ex.category}</span>
              <span className="text-[#CCFF00] font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                Technique Cues <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </Card>
        ))}
      </div>

      {/* Detail / Technique Modal */}
      {activeExercise && (
        <Modal
          isOpen={!!activeExercise}
          onClose={() => setActiveExercise(null)}
          title={activeExercise.name}
          description={`Targeting ${activeExercise.targetMuscle} • ${activeExercise.difficulty.toUpperCase()}`}
          maxWidth="lg"
        >
          <div className="space-y-5">
            {/* Steps */}
            <div>
              <h4 className="text-xs font-bold text-[#94A3B8] uppercase tracking-wider mb-2">
                Execution Instructions
              </h4>
              <ol className="space-y-2 text-xs text-[#F8FAFC]">
                {activeExercise.instructions.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#182233] text-[#CCFF00] font-bold flex items-center justify-center shrink-0 border border-[#1F2E45]">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed mt-0.5">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Technique Cue */}
            <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
              <span className="text-xs font-bold text-[#00F0FF] uppercase block mb-1">
                Form & Posture Tip
              </span>
              <p className="text-xs text-[#94A3B8] leading-relaxed">{activeExercise.tips}</p>
            </div>

            {/* Low-Impact Joint-Friendly Alternative */}
            {activeExercise.lowImpactAlternative && (
              <div className="p-3.5 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30">
                <span className="text-xs font-bold text-[#CCFF00] uppercase block mb-1">
                  Low-Impact Joint-Friendly Alternative
                </span>
                <p className="text-xs text-[#F8FAFC]">
                  If experiencing joint sensitivity: <strong>{activeExercise.lowImpactAlternative}</strong>
                </p>
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <Button variant="primary" size="sm" onClick={() => setActiveExercise(null)}>
                Got It
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
