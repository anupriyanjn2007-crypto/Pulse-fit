'use client';

import React, { useState, useEffect, useRef } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Modal } from '@/components/ui/modal';
import { calculateStepMetrics } from '@/lib/calculations/stride';
import {
  Footprints,
  Compass,
  Play,
  Square,
  Plus,
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  History,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export default function StepTrackerPage() {
  const {
    todayLog,
    goals,
    stepRecords,
    addStepRecord,
    currentMeasurement,
    profile,
  } = usePulseFit();

  const stepGoal = goals?.daily_step_goal || 8000;
  const heightCm = currentMeasurement?.height_cm || 175;
  const weightKg = currentMeasurement?.weight_kg || 70;

  // Live Accelerometer Session State
  const [isTrackingSession, setIsTrackingSession] = useState(false);
  const [sessionSteps, setSessionSteps] = useState(0);
  const [sessionDurationSec, setSessionDurationSec] = useState(0);
  const [sensorStatus, setSensorStatus] = useState<
    'unsupported' | 'permission_needed' | 'active' | 'idle'
  >('idle');
  const [sensorError, setSensorError] = useState<string | null>(null);

  // Manual Step Modal
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualSteps, setManualSteps] = useState<number>(2000);
  const [manualNote, setManualNote] = useState('Evening stroll');

  // Accelerometer algorithm references
  const lastMagnitudeRef = useRef<number>(9.8);
  const lastStepTimeRef = useRef<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Check DeviceMotion Support
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (!('DeviceMotionEvent' in window)) {
        setSensorStatus('unsupported');
      }
    }
  }, []);

  // Timer for session duration
  useEffect(() => {
    if (isTrackingSession) {
      timerRef.current = setInterval(() => {
        setSessionDurationSec((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isTrackingSession]);

  // Request Permission & Start Motion Tracking
  async function startSensorTracking() {
    setSensorError(null);

    if (typeof window === 'undefined' || !('DeviceMotionEvent' in window)) {
      setSensorStatus('unsupported');
      setSensorError('DeviceMotionEvent is not supported on this device/browser.');
      return;
    }

    try {
      // iOS 13+ requires explicit permission request
      if (
        typeof (DeviceMotionEvent as any).requestPermission === 'function'
      ) {
        const permissionState = await (DeviceMotionEvent as any).requestPermission();
        if (permissionState !== 'granted') {
          setSensorStatus('permission_needed');
          setSensorError('Motion sensor permission was denied by the user.');
          return;
        }
      }

      setSessionSteps(0);
      setSessionDurationSec(0);
      setIsTrackingSession(true);
      setSensorStatus('active');

      window.addEventListener('devicemotion', handleDeviceMotion, false);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Sensor initialization failed';
      setSensorError(message);
      setSensorStatus('unsupported');
    }
  }

  function handleDeviceMotion(event: DeviceMotionEvent) {
    const acc = event.accelerationIncludingGravity;
    if (!acc || acc.x === null || acc.y === null || acc.z === null) return;

    // Calculate 3D vector magnitude: sqrt(x^2 + y^2 + z^2)
    const magnitude = Math.sqrt(acc.x * acc.x + acc.y * acc.y + acc.z * acc.z);
    const now = Date.now();

    // Step detection threshold:
    // Earth gravity = 9.8 m/s^2. Normal walking peak acceleration = 11.5 - 13.5 m/s^2
    // Minimum cadence debounce = 320ms (max ~3.1 steps/sec) to avoid double counting
    const delta = magnitude - lastMagnitudeRef.current;
    if (delta > 2.2 && magnitude > 11.5 && now - lastStepTimeRef.current > 320) {
      setSessionSteps((prev) => prev + 1);
      lastStepTimeRef.current = now;
    }

    lastMagnitudeRef.current = magnitude;
  }

  async function stopSensorTracking() {
    if (typeof window !== 'undefined') {
      window.removeEventListener('devicemotion', handleDeviceMotion);
    }
    setIsTrackingSession(false);
    setSensorStatus('idle');

    if (sessionSteps > 0) {
      await addStepRecord(sessionSteps, 'device_motion', 'Device Accelerometer');
    }
  }

  async function handleManualSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (manualSteps <= 0) return;
    await addStepRecord(manualSteps, 'manual', `Manual Entry (${manualNote})`);
    setIsManualModalOpen(false);
  }

  const sessionMetrics = calculateStepMetrics(sessionSteps, heightCm, weightKg, profile?.gender);
  const totalMetrics = calculateStepMetrics(todayLog.total_steps, heightCm, weightKg, profile?.gender);

  const stepPct = Math.min(100, Math.round((todayLog.total_steps / stepGoal) * 100));

  // Format Session duration
  const minutes = Math.floor(sessionDurationSec / 60);
  const seconds = sessionDurationSec % 60;
  const timeFormatted = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Precision Step Tracking</h1>
            <Badge variant="lime">Hardware & Sensor Engine</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Real sensor telemetry and biomechanical stride distance modeling.
          </p>
        </div>

        <Button
          variant="secondary"
          size="sm"
          onClick={() => setIsManualModalOpen(true)}
          className="text-xs"
        >
          <Plus className="w-3.5 h-3.5 mr-1" /> Manual Step Entry
        </Button>
      </div>

      {/* Main Metric Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="sports-card p-6 md:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2">
              <span className="font-bold uppercase tracking-wider">Today&apos;s Total Steps</span>
              <Footprints className="w-5 h-5 text-[#CCFF00]" />
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl sm:text-5xl font-black text-[#F8FAFC]">
                {todayLog.total_steps.toLocaleString()}
              </span>
              <span className="text-sm text-[#94A3B8] font-mono">
                / {stepGoal.toLocaleString()} goal
              </span>
            </div>
            <div className="mt-4">
              <Progress value={stepPct} color="lime" className="h-3" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-6 pt-4 border-t border-[#1F2E45]/60 text-xs">
            <div>
              <span className="text-[#94A3B8] block text-[11px]">Est. Distance</span>
              <span className="font-bold text-[#F8FAFC] font-mono">{totalMetrics.distanceKm} km</span>
            </div>
            <div>
              <span className="text-[#94A3B8] block text-[11px]">Active Calories</span>
              <span className="font-bold text-[#F8FAFC] font-mono">
                {totalMetrics.estimatedActiveCalories} kcal
              </span>
            </div>
            <div>
              <span className="text-[#94A3B8] block text-[11px]">Active Time</span>
              <span className="font-bold text-[#F8FAFC] font-mono">
                {totalMetrics.activeMinutesEstimate} mins
              </span>
            </div>
          </div>
        </Card>

        {/* Accuracy & Stride Calibration Card */}
        <Card className="sports-card p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Compass className="w-4 h-4 text-[#00F0FF]" />
              <CardTitle>Biomech Calibration</CardTitle>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">
              Walking distance is computed from your personal calibrated stride length:
            </p>
            <div className="p-3 mt-3 rounded-xl bg-[#182233] border border-[#1F2E45] space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-[#94A3B8]">Height:</span>
                <span className="font-mono text-[#F8FAFC]">{heightCm} cm</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#94A3B8]">Computed Stride:</span>
                <span className="font-mono text-[#CCFF00] font-bold">
                  {totalMetrics.strideLengthMeters} m
                </span>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-[#64748B] mt-4">
            Notice: Calorie burns and distance are estimations derived from peer-reviewed biomechanical formulas.
          </div>
        </Card>
      </div>

      {/* Live Motion Sensor Tracking Session */}
      <Card className="sports-card p-6 border-[#00F0FF]/30 bg-gradient-to-br from-[#111827] to-[#182233]">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  isTrackingSession ? 'bg-[#CCFF00] animate-ping' : 'bg-[#64748B]'
                }`}
              />
              <CardTitle>Live Device Accelerometer Session</CardTitle>
            </div>
            <p className="text-xs text-[#94A3B8] mt-1">
              Real-time hardware motion detection on compatible smartphones & laptops.
            </p>
          </div>

          {!isTrackingSession ? (
            <Button
              variant="primary"
              onClick={startSensorTracking}
              className="bg-[#00F0FF] text-black hover:bg-[#00d4e0] font-bold"
            >
              <Play className="w-4 h-4 mr-1.5 fill-black" /> Start Live Tracking Session
            </Button>
          ) : (
            <Button variant="danger" onClick={stopSensorTracking}>
              <Square className="w-4 h-4 mr-1.5 fill-red-400" /> End & Save Session
            </Button>
          )}
        </div>

        {sensorError && (
          <div className="p-3 mb-4 rounded-xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{sensorError} You can still log steps manually below.</span>
          </div>
        )}

        {/* Live Session Counter */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 rounded-xl bg-[#090D14]/80 border border-[#1F2E45]">
          <div>
            <span className="text-[11px] text-[#94A3B8] block">Session Steps</span>
            <span className="text-3xl font-black text-[#00F0FF] font-mono">
              {sessionSteps}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-[#94A3B8] block">Session Time</span>
            <span className="text-3xl font-black text-[#F8FAFC] font-mono">
              {timeFormatted}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-[#94A3B8] block">Session Distance</span>
            <span className="text-3xl font-black text-[#F8FAFC] font-mono">
              {sessionMetrics.distanceKm} <span className="text-xs font-normal">km</span>
            </span>
          </div>
          <div>
            <span className="text-[11px] text-[#94A3B8] block">Session Energy</span>
            <span className="text-3xl font-black text-orange-400 font-mono">
              {sessionMetrics.estimatedActiveCalories}{' '}
              <span className="text-xs font-normal">kcal</span>
            </span>
          </div>
        </div>
      </Card>

      {/* Step History & Source Verification Log */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#CCFF00]" />
            <CardTitle>Recorded Step Batches & Origin Verification</CardTitle>
          </div>
          <Badge variant="cyan">Zero Fabricated Records</Badge>
        </CardHeader>

        <div className="space-y-2.5">
          {stepRecords.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#94A3B8]">
              No individual batch step syncs recorded yet today. Use the live session tracker or manual input above.
            </div>
          ) : (
            stepRecords.map((rec) => (
              <div
                key={rec.id}
                className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3">
                  <Footprints className="w-4 h-4 text-[#CCFF00]" />
                  <div>
                    <span className="text-sm font-bold text-[#F8FAFC]">
                      +{rec.step_count.toLocaleString()} steps
                    </span>
                    <span className="text-xs text-[#94A3B8] block">
                      {(rec.distance_meters / 1000).toFixed(2)} km • {rec.source_device || rec.source}
                    </span>
                  </div>
                </div>

                <Badge
                  variant={
                    rec.source === 'health_connect'
                      ? 'lime'
                      : rec.source === 'device_motion'
                      ? 'cyan'
                      : 'neutral'
                  }
                >
                  {rec.source === 'device_motion'
                    ? 'Motion Sensor'
                    : rec.source === 'health_connect'
                    ? 'Health Connect'
                    : 'Manual Entry'}
                </Badge>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Manual Step Entry Modal */}
      <Modal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        title="Manual Step Input"
        description="Explicitly records manual fallback data with source verification."
      >
        <form onSubmit={handleManualSubmit} className="space-y-4">
          <Input
            label="Step Count"
            type="number"
            min="10"
            max="100000"
            value={manualSteps}
            onChange={(e) => setManualSteps(parseInt(e.target.value, 10) || 0)}
            required
          />

          <Input
            label="Activity Label / Context"
            placeholder="e.g. Treadmill jog, morning market walk"
            value={manualNote}
            onChange={(e) => setManualNote(e.target.value)}
          />

          <div className="p-3 rounded-xl bg-[#182233] border border-[#1F2E45] text-xs text-[#94A3B8]">
            <span className="text-[#CCFF00] font-semibold">Transparency: </span>
            This batch will be stored with tag <Badge variant="neutral">Manual Entry</Badge> to differentiate it
            from hardware-measured steps.
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsManualModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Record Steps
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
