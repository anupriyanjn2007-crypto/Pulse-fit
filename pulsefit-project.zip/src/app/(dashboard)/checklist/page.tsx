'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Modal } from '@/components/ui/modal';
import { ChecklistItem, TimeOfDay } from '@/types/pulsefit';
import {
  CheckSquare,
  Plus,
  Trash2,
  Sun,
  Sunset,
  Moon,
  Coffee,
  Sparkles,
  Clock,
  CheckCircle2,
  Calendar,
} from 'lucide-react';

export default function ChecklistPage() {
  const {
    checklistItems,
    toggleChecklistItem,
    addCustomChecklistItem,
    deleteChecklistItem,
    todayLog,
  } = usePulseFit();

  const [activeTab, setActiveTab] = useState<'all' | TimeOfDay>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form states for new custom task
  const [taskTitle, setTaskTitle] = useState('');
  const [taskCategory, setTaskCategory] = useState<ChecklistItem['category']>('custom');
  const [taskTimeOfDay, setTaskTimeOfDay] = useState<TimeOfDay>('morning');
  const [taskReminder, setTaskReminder] = useState('08:00');

  const completedCount = checklistItems.filter((i) => i.is_completed).length;
  const totalCount = checklistItems.length;
  const completionPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const filteredItems = checklistItems.filter((item) => {
    if (activeTab === 'all') return true;
    return item.time_of_day === activeTab;
  });

  const morningItems = checklistItems.filter((i) => i.time_of_day === 'morning');
  const afternoonItems = checklistItems.filter((i) => i.time_of_day === 'afternoon');
  const eveningItems = checklistItems.filter((i) => i.time_of_day === 'evening');
  const nightItems = checklistItems.filter((i) => i.time_of_day === 'night');

  async function handleCreateTask(e: React.FormEvent) {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    await addCustomChecklistItem(taskTitle, taskCategory, taskTimeOfDay, taskReminder);
    setTaskTitle('');
    setIsAddModalOpen(false);
  }

  return (
    <div className="space-y-6">
      {/* Page Title & Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Advanced Daily Checklist</h1>
            <Badge variant="lime">Live Routine</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Personalized four-phase habit tracker synchronized to your local timezone.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsAddModalOpen(true)}
          className="shadow-md shadow-[#CCFF00]/15"
        >
          <Plus className="w-4 h-4 mr-1.5" /> Add Custom Task
        </Button>
      </div>

      {/* Completion Score Overview Banner */}
      <Card className="sports-card p-6 bg-gradient-to-r from-[#111827] via-[#182233] to-[#111827]">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider text-[#94A3B8] font-bold">
              Today&apos;s Routine Progress
            </span>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-black text-[#CCFF00]">{completionPct}%</span>
              <span className="text-xs text-[#94A3B8] font-mono">
                {completedCount} of {totalCount} habits completed
              </span>
            </div>
          </div>

          <div className="w-full sm:w-64">
            <Progress value={completionPct} color="lime" className="h-3" />
            <div className="flex justify-between text-[10px] text-[#94A3B8] font-mono mt-1.5">
              <span>Remaining: {totalCount - completedCount} tasks</span>
              <span className="text-[#CCFF00]">
                {completionPct === 100 ? 'Day Mastered!' : 'Keep Moving'}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Time-of-Day Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#1F2E45]/60">
        {[
          { id: 'all', label: 'All Phases', count: totalCount, icon: CheckSquare },
          { id: 'morning', label: 'Morning', count: morningItems.length, icon: Coffee },
          { id: 'afternoon', label: 'Afternoon', count: afternoonItems.length, icon: Sun },
          { id: 'evening', label: 'Evening', count: eveningItems.length, icon: Sunset },
          { id: 'night', label: 'Night', count: nightItems.length, icon: Moon },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#CCFF00] text-black font-bold shadow-md shadow-[#CCFF00]/20'
                  : 'bg-[#182233] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#1F2E45]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  isActive ? 'bg-black text-[#CCFF00]' : 'bg-[#111827] text-[#94A3B8]'
                }`}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Interactive Tasks List */}
      <div className="space-y-3">
        {filteredItems.length === 0 ? (
          <div className="text-center py-12 p-6 rounded-2xl bg-[#111827] border border-[#1F2E45]">
            <CheckCircle2 className="w-10 h-10 text-[#64748B] mx-auto mb-3" />
            <p className="text-sm text-[#F8FAFC] font-semibold">No tasks scheduled in this phase</p>
            <p className="text-xs text-[#94A3B8] mt-1">Tap &quot;Add Custom Task&quot; to build your tailored checklist.</p>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className={`flex items-center justify-between p-4 rounded-xl border transition-all duration-150 ${
                item.is_completed
                  ? 'bg-[#111827]/60 border-[#1F2E45]/40 opacity-75'
                  : 'bg-[#182233] border-[#1F2E45] hover:border-[#CCFF00]/40'
              }`}
            >
              <div className="flex items-center gap-3.5 flex-1 min-w-0">
                <button
                  type="button"
                  onClick={() => toggleChecklistItem(item.id)}
                  className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                    item.is_completed
                      ? 'bg-[#CCFF00] text-black font-black scale-105'
                      : 'border-2 border-[#64748B] hover:border-[#CCFF00]'
                  }`}
                  aria-label="Toggle task completion"
                >
                  {item.is_completed && <CheckSquare className="w-4 h-4 stroke-[3]" />}
                </button>

                <div className="min-w-0">
                  <span
                    className={`text-sm font-medium block truncate ${
                      item.is_completed ? 'line-through text-[#64748B]' : 'text-[#F8FAFC]'
                    }`}
                  >
                    {item.title}
                  </span>
                  <div className="flex items-center gap-2 mt-0.5 text-[11px] text-[#64748B]">
                    <span className="capitalize text-[#00F0FF]">{item.time_of_day}</span>
                    <span>•</span>
                    <span className="capitalize">{item.category}</span>
                    {item.reminder_time && (
                      <>
                        <span>•</span>
                        <span className="flex items-center gap-1 font-mono text-[#94A3B8]">
                          <Clock className="w-3 h-3" /> {item.reminder_time}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => deleteChecklistItem(item.id)}
                className="p-2 text-[#64748B] hover:text-red-400 rounded-lg hover:bg-[#111827] transition-colors"
                title="Remove task"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Missed Tasks Educational Non-Shaming Guidance */}
      <Card className="sports-card p-5 border-amber-500/20 bg-amber-500/5">
        <div className="flex items-start gap-3">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-[#94A3B8] leading-relaxed">
            <span className="text-[#F8FAFC] font-semibold">PulseFit Consistency Philosophy: </span>
            Life happens. If you miss a task during a busy day, there are no streak penalties or guilt. Focus on
            gradual habit building. Tomorrow morning reset starts fresh.
          </div>
        </div>
      </Card>

      {/* Add Custom Task Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add Custom Daily Task"
        description="Expand your personalized checklist routine."
      >
        <form onSubmit={handleCreateTask} className="space-y-4">
          <Input
            label="Task Name"
            placeholder="e.g. 15-min post-lunch walk"
            value={taskTitle}
            onChange={(e) => setTaskTitle(e.target.value)}
            required
          />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                Phase of Day
              </label>
              <select
                value={taskTimeOfDay}
                onChange={(e) => setTaskTimeOfDay(e.target.value as TimeOfDay)}
                className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-3 py-2 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
              >
                <option value="morning">Morning</option>
                <option value="afternoon">Afternoon</option>
                <option value="evening">Evening</option>
                <option value="night">Night</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                Category
              </label>
              <select
                value={taskCategory}
                onChange={(e) => setTaskCategory(e.target.value as any)}
                className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-3 py-2 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
              >
                <option value="movement">Movement</option>
                <option value="hydration">Hydration</option>
                <option value="nutrition">Nutrition</option>
                <option value="recovery">Recovery</option>
                <option value="mindset">Mindset</option>
                <option value="custom">Custom</option>
              </select>
            </div>
          </div>

          <Input
            label="Target Reminder Time"
            type="time"
            value={taskReminder}
            onChange={(e) => setTaskReminder(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Task
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
