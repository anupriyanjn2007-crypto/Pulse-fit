'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Settings,
  User,
  Target,
  LogOut,
  CheckCircle2,
  Globe,
  Clock,
  Sparkles,
} from 'lucide-react';

export default function SettingsPage() {
  const { profile, goals, logout, updateStepGoal, updateWaterGoal } = usePulseFit();

  const [fullName, setFullName] = useState(profile?.full_name || 'Alex Rivera');
  const [country, setCountry] = useState(profile?.country || 'IN');
  const [preferredLanguage, setPreferredLanguage] = useState(profile?.preferred_language || 'en');
  const [stepGoal, setStepGoal] = useState<number>(goals?.daily_step_goal || 8000);
  const [waterGoal, setWaterGoal] = useState<number>(goals?.daily_water_goal_ml || 2500);
  const [saveSuccess, setSaveSuccess] = useState(false);

  async function handleSaveSettings(e: React.FormEvent) {
    e.preventDefault();
    await updateStepGoal(stepGoal);
    await updateWaterGoal(waterGoal);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Account & Profile Settings</h1>
            <Badge variant="lime">Preferences</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Manage your personal bio, daily targets, and session credentials.
          </p>
        </div>

        <Button variant="danger" size="sm" onClick={logout}>
          <LogOut className="w-3.5 h-3.5 mr-1" /> Sign Out
        </Button>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-xl bg-[#CCFF00]/15 border border-[#CCFF00]/30 text-xs text-[#CCFF00] flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Account preferences and fitness targets updated successfully.</span>
        </div>
      )}

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Personal Details Card */}
        <Card className="sports-card p-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-[#CCFF00]" />
              <CardTitle>Personal Profile</CardTitle>
            </div>
          </CardHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
              <Input
                label="Email Address"
                value={profile?.email || 'athlete@pulsefit.app'}
                readOnly
                hint="Managed by authenticated identity provider"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Country
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
                >
                  <option value="IN">India</option>
                  <option value="US">United States</option>
                  <option value="GB">United Kingdom</option>
                  <option value="SG">Singapore</option>
                  <option value="AE">United Arab Emirates</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Language
                </label>
                <select
                  value={preferredLanguage}
                  onChange={(e) => setPreferredLanguage(e.target.value)}
                  className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
                >
                  <option value="en">English</option>
                  <option value="ta">Tamil (தமிழ்)</option>
                  <option value="hi">Hindi (हिन्दी)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Local Timezone
                </label>
                <input
                  type="text"
                  readOnly
                  value={profile?.timezone || 'UTC'}
                  className="w-full bg-[#182233]/60 border border-[#1F2E45] rounded-xl px-4 py-2.5 text-sm text-[#94A3B8] font-mono"
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Daily Targets Customization */}
        <Card className="sports-card p-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-[#00F0FF]" />
              <CardTitle>Daily Athletic Targets</CardTitle>
            </div>
          </CardHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Daily Step Goal"
              type="number"
              min="1000"
              max="50000"
              step="500"
              value={stepGoal}
              onChange={(e) => setStepGoal(parseInt(e.target.value, 10) || 8000)}
            />

            <Input
              label="Daily Hydration Goal (ml)"
              type="number"
              min="1000"
              max="6000"
              step="100"
              value={waterGoal}
              onChange={(e) => setWaterGoal(parseInt(e.target.value, 10) || 2500)}
            />
          </div>
        </Card>

        <div className="flex justify-end pt-2">
          <Button type="submit" variant="primary" className="px-8 py-3">
            Save Preferences
          </Button>
        </div>
      </form>
    </div>
  );
}
