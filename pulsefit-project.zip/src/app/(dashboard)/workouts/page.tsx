'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import { EXERCISE_LIBRARY } from '@/lib/data/exercise-library';
import {
  Dumbbell,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  Flame,
  Pause,
  ArrowRight,
  Sparkles,
  Zap,
} from 'lucide-react';

interface ActiveExercise {
  name: string;
  targetMuscle: string;
  sets: number;
  reps: number;
  restSec: number;
}

export default function WorkoutsPage() {
  const { completeWorkout, workoutHistory } = usePulseFit();

  // Active Workout Runner Modal State
  const [isRunnerOpen, setIsRunnerOpen] = useState(false);
  const [activeRoutineTitle, setActiveRoutineTitle] = useState('Full-Body Foundation Routine');
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [isResting, setIsResting] = useState(false);
  const [timerSec, setTimerSec] = useState(60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [totalWorkoutSeconds, setTotalWorkoutSeconds] = useState(0);

  const activeRoutineExercises: ActiveExercise[] = [
    { name: 'Bodyweight Squats', targetMuscle: 'Quadriceps & Glutes', sets: 3, reps: 12, restSec: 45 },
    { name: 'Push-Ups', targetMuscle: 'Chest & Shoulders', sets: 3, reps: 10, restSec: 60 },
    { name: 'Plank Hold', targetMuscle: 'Core & Stabilizers', sets: 3, reps: 30, restSec: 45 },
    { name: 'Glute Bridges', targetMuscle: 'Glutes & Lower Back', sets: 3, reps: 15, restSec: 45 },
  ];

  const currentExercise = activeRoutineExercises[currentExerciseIndex];

  // Timer Ref
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunnerOpen && isTimerRunning) {
      timerIntervalRef.current = setInterval(() => {
        setTotalWorkoutSeconds((prev) => prev + 1);
        if (isResting) {
          setTimerSec((prev) => {
            if (prev <= 1) {
              setIsResting(false);
              return 0;
            }
            return prev - 1;
          });
        }
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isRunnerOpen, isTimerRunning, isResting]);

  function startRoutine(title: string) {
    setActiveRoutineTitle(title);
    setCurrentExerciseIndex(0);
    setCurrentSet(1);
    setIsResting(false);
    setTimerSec(45);
    setTotalWorkoutSeconds(0);
    setIsTimerRunning(true);
    setIsRunnerOpen(true);
  }

  function handleCompleteSet() {
    if (currentSet < currentExercise.sets) {
      setCurrentSet((prev) => prev + 1);
      setIsResting(true);
      setTimerSec(currentExercise.restSec);
    } else {
      // Advance to next exercise or finish
      if (currentExerciseIndex < activeRoutineExercises.length - 1) {
        setCurrentExerciseIndex((prev) => prev + 1);
        setCurrentSet(1);
        setIsResting(true);
        setTimerSec(60);
      } else {
        // Workout Finished!
        finishWorkout();
      }
    }
  }

  async function finishWorkout() {
    setIsTimerRunning(false);
    const durationMin = Math.max(1, Math.round(totalWorkoutSeconds / 60));
    await completeWorkout(
      activeRoutineTitle,
      durationMin,
      activeRoutineExercises.map((e) => ({
        exercise_name: e.name,
        sets_completed: e.sets,
      })),
      7,
      'Completed via PulseFit Athletic Runner'
    );
    setIsRunnerOpen(false);
  }

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Intelligent Workout Planner</h1>
            <Badge variant="lime">Interactive Runner</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Structured workout routines with sets, reps, and built-in rest interval timers.
          </p>
        </div>

        <Link href="/exercises">
          <Button variant="outline" size="sm">
            <Zap className="w-3.5 h-3.5 mr-1" /> Browse Exercise Library
          </Button>
        </Link>
      </div>

      {/* Recommended Routines Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="sports-card p-6 flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between mb-3">
              <Badge variant="lime">Beginner • Home</Badge>
              <span className="text-xs font-mono text-[#94A3B8]">25 mins</span>
            </div>
            <h3 className="text-lg font-bold text-[#F8FAFC]">Full-Body Foundation Routine</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Bodyweight squats, push-up progressions, glute bridges, and core stability holds.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-[#1F2E45]">
            <Button
              variant="primary"
              className="w-full text-xs py-2.5"
              onClick={() => startRoutine('Full-Body Foundation Routine')}
            >
              <Play className="w-3.5 h-3.5 mr-1 fill-black" /> Launch Workout Runner
            </Button>
          </div>
        </Card>

        <Card className="sports-card p-6 flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between mb-3">
              <Badge variant="cyan">Intermediate • Strength</Badge>
              <span className="text-xs font-mono text-[#94A3B8]">35 mins</span>
            </div>
            <h3 className="text-lg font-bold text-[#F8FAFC]">Dumbbell Athletic Hypertrophy</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Romanian deadlifts, overhead presses, goblet squats, and bent-over dumbbell rows.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-[#1F2E45]">
            <Button
              variant="primary"
              className="w-full text-xs py-2.5 bg-[#00F0FF] text-black hover:bg-[#00d4e0]"
              onClick={() => startRoutine('Dumbbell Athletic Hypertrophy')}
            >
              <Play className="w-3.5 h-3.5 mr-1 fill-black" /> Launch Workout Runner
            </Button>
          </div>
        </Card>

        <Card className="sports-card p-6 flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between mb-3">
              <Badge variant="neutral">Recovery • Mobility</Badge>
              <span className="text-xs font-mono text-[#94A3B8]">20 mins</span>
            </div>
            <h3 className="text-lg font-bold text-[#F8FAFC]">Spinal Reset & Surya Namaskar</h3>
            <p className="text-xs text-[#94A3B8] mt-2 leading-relaxed">
              Cat-Cow flows, hip openers, hamstring stretches, and mindful deep breathing.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-[#1F2E45]">
            <Button
              variant="secondary"
              className="w-full text-xs py-2.5"
              onClick={() => startRoutine('Spinal Reset & Surya Namaskar')}
            >
              <Play className="w-3.5 h-3.5 mr-1" /> Launch Workout Runner
            </Button>
          </div>
        </Card>
      </div>

      {/* Completed Workout History */}
      <Card className="sports-card p-6">
        <CardHeader>
          <CardTitle>Session History & Performance Logs</CardTitle>
          <Badge variant="cyan">Verified Completed</Badge>
        </CardHeader>

        <div className="space-y-3">
          {workoutHistory.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#94A3B8]">
              No workouts logged yet. Start a session using the runner cards above.
            </div>
          ) : (
            workoutHistory.map((wh) => (
              <div
                key={wh.id}
                className="flex items-center justify-between p-4 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00]">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#F8FAFC]">{wh.workout_title}</h4>
                    <span className="text-xs text-[#94A3B8]">
                      {wh.duration_minutes} min duration • ~{wh.calories_burned} active kcal
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs text-[#94A3B8] font-mono block">
                    {new Date(wh.completed_at).toLocaleDateString()}
                  </span>
                  {wh.perceived_exertion && (
                    <Badge variant="lime" className="mt-1">
                      RPE {wh.perceived_exertion}/10
                    </Badge>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Active Workout Runner Modal */}
      <Modal
        isOpen={isRunnerOpen}
        onClose={() => setIsRunnerOpen(false)}
        title={activeRoutineTitle}
        description={`Exercise ${currentExerciseIndex + 1} of ${activeRoutineExercises.length}`}
        maxWidth="lg"
      >
        <div className="space-y-6 text-center">
          {/* Active Exercise Detail */}
          <div className="p-6 rounded-2xl bg-[#090D14] border border-[#1F2E45]">
            <Badge variant="lime" className="mb-2">
              {currentExercise?.targetMuscle}
            </Badge>
            <h2 className="text-3xl font-black text-[#F8FAFC]">{currentExercise?.name}</h2>

            <div className="flex items-center justify-center gap-6 mt-4">
              <div>
                <span className="text-xs text-[#94A3B8] uppercase block">Set</span>
                <span className="text-2xl font-black text-[#CCFF00] font-mono">
                  {currentSet} / {currentExercise?.sets}
                </span>
              </div>
              <div className="w-px h-8 bg-[#1F2E45]" />
              <div>
                <span className="text-xs text-[#94A3B8] uppercase block">Target Reps</span>
                <span className="text-2xl font-black text-[#F8FAFC] font-mono">
                  {currentExercise?.reps}
                </span>
              </div>
            </div>
          </div>

          {/* Rest Interval Display */}
          {isResting && (
            <div className="p-4 rounded-xl bg-[#00F0FF]/15 border border-[#00F0FF]/30 animate-pulse">
              <span className="text-xs font-bold text-[#00F0FF] uppercase tracking-wider block">
                Rest Interval (Catch Breath)
              </span>
              <span className="text-4xl font-black text-[#00F0FF] font-mono mt-1 block">
                {timerSec}s
              </span>
            </div>
          )}

          {/* Total Elapsed Time */}
          <div className="text-xs text-[#94A3B8] font-mono">
            Elapsed Routine Time:{' '}
            {Math.floor(totalWorkoutSeconds / 60)}:
            {(totalWorkoutSeconds % 60).toString().padStart(2, '0')}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-3 pt-2">
            <Button
              type="button"
              variant="primary"
              size="lg"
              className="text-base px-8 py-3.5"
              onClick={handleCompleteSet}
            >
              <CheckCircle2 className="w-5 h-5 mr-2" />
              {currentSet === currentExercise?.sets &&
              currentExerciseIndex === activeRoutineExercises.length - 1
                ? 'Finish Workout Session'
                : isResting
                ? 'Skip Rest & Next Set'
                : 'Complete Set'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
