'use client';

import React from 'react';
import Link from 'next/link';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Footprints,
  Flame,
  Droplets,
  Moon,
  CheckSquare,
  Scale,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Dumbbell,
  AlertCircle,
  Plus,
  Compass,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export default function DashboardPage() {
  const {
    profile,
    goals,
    todayLog,
    measurements,
    checklistItems,
    addWaterLog,
    devices,
  } = usePulseFit();

  const currentWeight = measurements[0]?.weight_kg ?? 70;
  const bmiVal = measurements[0]?.bmi ?? 22.8;
  const bmiCat = measurements[0]?.bmi_category ?? 'Normal weight';
  const targetWeight = goals?.target_weight_kg;

  const stepGoal = goals?.daily_step_goal ?? 8000;
  const stepPct = Math.min(100, Math.round((todayLog.total_steps / stepGoal) * 100));

  const waterGoal = goals?.daily_water_goal_ml ?? 2500;
  const waterPct = Math.min(100, Math.round((todayLog.water_ml / waterGoal) * 100));

  const sleepGoalHrs = goals?.daily_sleep_goal_hrs ?? 8.0;
  const sleepHrs = Math.round((todayLog.sleep_minutes / 60) * 10) / 10;
  const sleepPct = Math.min(100, Math.round((sleepHrs / sleepGoalHrs) * 100));

  const completedChecklists = checklistItems.filter((i) => i.is_completed).length;
  const totalChecklists = checklistItems.length;

  const activeSensors = devices.filter((d) => d.status === 'connected');

  // 7-Day Activity Trend Data
  const weeklyData = [
    { day: 'Mon', steps: 7200, target: stepGoal },
    { day: 'Tue', steps: 8100, target: stepGoal },
    { day: 'Wed', steps: 6800, target: stepGoal },
    { day: 'Thu', steps: 9400, target: stepGoal },
    { day: 'Fri', steps: 7800, target: stepGoal },
    { day: 'Sat', steps: 8500, target: stepGoal },
    { day: 'Sun', steps: todayLog.total_steps, target: stepGoal },
  ];

  // Dynamic AI Insight generation based on actual recorded metrics
  let dynamicInsight = '';
  if (stepPct < 50) {
    const remainingSteps = stepGoal - todayLog.total_steps;
    const estWalkMinutes = Math.round(remainingSteps / 100);
    dynamicInsight = `You have completed ${stepPct}% of your movement goal. A gentle ${estWalkMinutes}-minute walk this afternoon will help you comfortably achieve your ${stepGoal.toLocaleString()} step target.`;
  } else if (stepPct < 100) {
    const remainingSteps = stepGoal - todayLog.total_steps;
    dynamicInsight = `Solid momentum! You are ${remainingSteps.toLocaleString()} steps away from your daily goal. An evening stroll or workout cooldown will close the gap.`;
  } else {
    dynamicInsight = `Excellent performance! You have exceeded your daily step target with ${todayLog.total_steps.toLocaleString()} steps recorded. Focus on recovery and evening hydration.`;
  }

  return (
    <div className="space-y-6">
      {/* Dynamic AI Insights Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#182233] via-[#111827] to-[#182233] border border-[#00F0FF]/30 p-5 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/15 flex items-center justify-center text-[#00F0FF] shrink-0 border border-[#00F0FF]/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                Daily AI Insight
              </span>
              <span className="text-[10px] text-[#64748B] font-mono">
                Contextual Analysis
              </span>
            </div>
            <p className="text-sm text-[#F8FAFC] leading-relaxed">{dynamicInsight}</p>
          </div>
          <Link href="/coach" className="hidden sm:inline-flex shrink-0">
            <Button variant="outline" size="sm" className="text-xs border-[#00F0FF]/40 text-[#00F0FF]">
              Ask Coach <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Primary 4-Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Steps */}
        <Card className="sports-card p-5 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2">
            <span className="font-medium uppercase tracking-wider">Step Count</span>
            <Footprints className="w-4 h-4 text-[#CCFF00]" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#F8FAFC]">
              {todayLog.total_steps.toLocaleString()}
            </span>
            <span className="text-xs text-[#94A3B8] font-mono">/ {stepGoal.toLocaleString()}</span>
          </div>
          <div className="mt-3">
            <Progress value={stepPct} color="lime" />
          </div>
          <div className="flex items-center justify-between text-[11px] text-[#94A3B8] mt-2 font-mono">
            <span>{(todayLog.distance_meters / 1000).toFixed(2)} km</span>
            <span className="text-[#CCFF00] font-bold">{stepPct}%</span>
          </div>
        </Card>

        {/* Metric 2: Active Calories */}
        <Card className="sports-card p-5 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2">
            <span className="font-medium uppercase tracking-wider">Active Energy</span>
            <Flame className="w-4 h-4 text-orange-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#F8FAFC]">
              {todayLog.active_calories}
            </span>
            <span className="text-xs text-[#94A3B8] font-mono">kcal</span>
          </div>
          <div className="mt-3">
            <Progress value={Math.min(100, Math.round((todayLog.active_calories / 500) * 100))} color="gradient" />
          </div>
          <div className="flex items-center justify-between text-[11px] text-[#94A3B8] mt-2 font-mono">
            <span>{todayLog.active_minutes} active mins</span>
            <span className="text-orange-400">Biomech model</span>
          </div>
        </Card>

        {/* Metric 3: Hydration */}
        <Card className="sports-card p-5 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2">
            <span className="font-medium uppercase tracking-wider">Hydration</span>
            <Droplets className="w-4 h-4 text-[#00F0FF]" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#F8FAFC]">
              {todayLog.water_ml.toLocaleString()}
            </span>
            <span className="text-xs text-[#94A3B8] font-mono">/ {waterGoal.toLocaleString()} ml</span>
          </div>
          <div className="mt-3">
            <Progress value={waterPct} color="cyan" />
          </div>
          <div className="flex items-center justify-between text-[11px] text-[#94A3B8] mt-2">
            <div className="flex items-center gap-1">
              <button
                onClick={() => addWaterLog(250)}
                className="px-1.5 py-0.5 rounded bg-[#182233] hover:bg-[#00F0FF]/20 text-[#00F0FF] text-[10px] font-mono border border-[#1F2E45]"
              >
                +250ml
              </button>
              <button
                onClick={() => addWaterLog(500)}
                className="px-1.5 py-0.5 rounded bg-[#182233] hover:bg-[#00F0FF]/20 text-[#00F0FF] text-[10px] font-mono border border-[#1F2E45]"
              >
                +500ml
              </button>
            </div>
            <span className="text-[#00F0FF] font-bold font-mono">{waterPct}%</span>
          </div>
        </Card>

        {/* Metric 4: Daily Checklist */}
        <Card className="sports-card p-5 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2">
            <span className="font-medium uppercase tracking-wider">Daily Checklist</span>
            <CheckSquare className="w-4 h-4 text-[#CCFF00]" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#F8FAFC]">
              {todayLog.checklist_completion_pct}%
            </span>
            <span className="text-xs text-[#94A3B8] font-mono">
              ({completedChecklists}/{totalChecklists})
            </span>
          </div>
          <div className="mt-3">
            <Progress value={todayLog.checklist_completion_pct} color="lime" />
          </div>
          <div className="flex items-center justify-between text-[11px] text-[#94A3B8] mt-2 font-mono">
            <Link href="/checklist" className="text-[#CCFF00] hover:underline">
              Open Routine →
            </Link>
            <span>{totalChecklists - completedChecklists} pending</span>
          </div>
        </Card>
      </div>

      {/* Middle Row: Weekly Activity Chart & Body Composition */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Activity Chart (2 cols) */}
        <Card className="sports-card p-6 lg:col-span-2">
          <CardHeader>
            <div>
              <CardTitle>Weekly Movement & Step Consistency</CardTitle>
              <p className="text-xs text-[#94A3B8] mt-0.5">
                Visualized against your {stepGoal.toLocaleString()} daily target.
              </p>
            </div>
            <Badge variant="lime">7-Day Pacing</Badge>
          </CardHeader>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#111827',
                    borderColor: '#1F2E45',
                    borderRadius: '0.75rem',
                    color: '#F8FAFC',
                    fontSize: '12px',
                  }}
                  formatter={(value: any) => [`${Number(value).toLocaleString()} steps`, 'Activity']}
                />
                <Bar dataKey="steps" fill="#CCFF00" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Body Metrics Summary (1 col) */}
        <Card className="sports-card p-6 flex flex-col justify-between">
          <div>
            <CardHeader>
              <CardTitle>Body Baseline</CardTitle>
              <Link href="/body" className="text-xs text-[#CCFF00] hover:underline">
                Update →
              </Link>
            </CardHeader>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center gap-3">
                  <Scale className="w-4 h-4 text-[#CCFF00]" />
                  <div>
                    <span className="text-xs text-[#94A3B8] block">Current Weight</span>
                    <span className="text-lg font-bold text-[#F8FAFC]">{currentWeight} kg</span>
                  </div>
                </div>
                {targetWeight && (
                  <div className="text-right">
                    <span className="text-xs text-[#94A3B8] block">Target</span>
                    <span className="text-xs font-mono text-[#00F0FF]">{targetWeight} kg</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-4 h-4 text-[#00F0FF]" />
                  <div>
                    <span className="text-xs text-[#94A3B8] block">Body Mass Index</span>
                    <span className="text-lg font-bold text-[#F8FAFC]">{bmiVal}</span>
                  </div>
                </div>
                <Badge variant={measurements[0]?.is_minor ? 'cyan' : 'lime'}>
                  {bmiCat}
                </Badge>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]">
                <div className="flex items-center gap-3">
                  <Moon className="w-4 h-4 text-purple-400" />
                  <div>
                    <span className="text-xs text-[#94A3B8] block">Last Sleep</span>
                    <span className="text-lg font-bold text-[#F8FAFC]">{sleepHrs} hrs</span>
                  </div>
                </div>
                <span className="text-xs font-mono text-[#94A3B8]">
                  Goal: {sleepGoalHrs}h
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-[#1F2E45] text-[11px] text-[#64748B]">
            Screening metrics only. Not a medical evaluation.
          </div>
        </Card>
      </div>

      {/* Bottom Row: Checklist Quick View & Active Device Connectivity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Checklist Quick View */}
        <Card className="sports-card p-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-[#CCFF00]" />
              <CardTitle>Today&apos;s Checklist Routine</CardTitle>
            </div>
            <Link href="/checklist">
              <Button variant="ghost" size="sm" className="text-xs text-[#CCFF00]">
                View All ({totalChecklists})
              </Button>
            </Link>
          </CardHeader>

          <div className="space-y-2.5">
            {checklistItems.slice(0, 4).map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-4 h-4 rounded-md flex items-center justify-center text-[10px] font-bold ${
                      item.is_completed
                        ? 'bg-[#CCFF00] text-black'
                        : 'border border-[#94A3B8]'
                    }`}
                  >
                    {item.is_completed && '✓'}
                  </div>
                  <span
                    className={`text-xs ${
                      item.is_completed ? 'line-through text-[#64748B]' : 'text-[#F8FAFC]'
                    }`}
                  >
                    {item.title}
                  </span>
                </div>
                <span className="text-[10px] text-[#64748B] font-mono capitalize">
                  {item.time_of_day}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Hardware & Sensor Integration Status */}
        <Card className="sports-card p-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#00F0FF]" />
              <CardTitle>Activity Sensors & Sources</CardTitle>
            </div>
            <Link href="/devices">
              <Button variant="ghost" size="sm" className="text-xs text-[#00F0FF]">
                Configure
              </Button>
            </Link>
          </CardHeader>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
              <div>
                <span className="text-xs font-bold text-[#F8FAFC] block">
                  Live Device Motion Sensor
                </span>
                <span className="text-[11px] text-[#94A3B8]">
                  Captures accelerometer step frequency in active sessions.
                </span>
              </div>
              <Badge variant="lime">Supported</Badge>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
              <div>
                <span className="text-xs font-bold text-[#F8FAFC] block">
                  Android Health Connect Bridge
                </span>
                <span className="text-[11px] text-[#94A3B8]">
                  Capacitor companion sync for verified device steps.
                </span>
              </div>
              <Badge variant="neutral">Standby</Badge>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]">
              <div>
                <span className="text-xs font-bold text-[#F8FAFC] block">
                  Manual Fallback Entry
                </span>
                <span className="text-[11px] text-[#94A3B8]">
                  Clear origin tag attached to all user inputs.
                </span>
              </div>
              <Badge variant="cyan">Available</Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
