'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import { WellnessCheckin, MoodType } from '@/types/pulsefit';
import {
  Moon,
  Sun,
  Smile,
  Zap,
  ShieldAlert,
  Plus,
  Heart,
  TrendingUp,
  Clock,
  Sparkles,
} from 'lucide-react';

export default function SleepWellnessPage() {
  const {
    todayLog,
    goals,
    sleepLogs,
    addSleepLog,
    wellnessCheckins,
    saveWellnessCheckin,
  } = usePulseFit();

  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);
  const [sleepStart, setSleepStart] = useState('23:00');
  const [sleepEnd, setSleepEnd] = useState('06:30');
  const [sleepQuality, setSleepQuality] = useState<number>(85);
  const [sleepNotes, setSleepNotes] = useState('Deep restorative rest');

  // Wellness checkin form
  const [mood, setMood] = useState<MoodType>('good');
  const [energyLevel, setEnergyLevel] = useState<number>(8);
  const [stressLevel, setStressLevel] = useState<number>(3);
  const [wellnessNotes, setWellnessNotes] = useState('');

  const sleepGoalHrs = goals?.daily_sleep_goal_hrs || 8.0;
  const currentSleepHrs = Math.round((todayLog.sleep_minutes / 60) * 10) / 10;
  const sleepPct = Math.min(100, Math.round((currentSleepHrs / sleepGoalHrs) * 100));

  async function handleLogSleep(e: React.FormEvent) {
    e.preventDefault();
    // compute duration from start and end strings
    const [startH, startM] = sleepStart.split(':').map(Number);
    const [endH, endM] = sleepEnd.split(':').map(Number);
    let diffMin = (endH * 60 + endM) - (startH * 60 + startM);
    if (diffMin < 0) diffMin += 24 * 60; // crossed midnight

    await addSleepLog(
      new Date().toISOString(),
      new Date().toISOString(),
      diffMin,
      sleepQuality,
      sleepNotes
    );
    setIsSleepModalOpen(false);
  }

  async function handleSaveWellness(e: React.FormEvent) {
    e.preventDefault();
    await saveWellnessCheckin(mood, energyLevel, stressLevel, wellnessNotes);
  }

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Sleep & Holistic Wellness</h1>
            <Badge variant="lime">Rest & Recovery</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Nightly duration, sleep consistency, mood, and subjective nervous system strain.
          </p>
        </div>

        <Button variant="primary" size="sm" onClick={() => setIsSleepModalOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> Log Nightly Sleep
        </Button>
      </div>

      {/* Accuracy Disclosure Alert */}
      <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45] flex items-start gap-3 text-xs text-[#94A3B8]">
        <ShieldAlert className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
        <div>
          <span className="text-[#F8FAFC] font-semibold">Sleep Measurement Integrity: </span>
          PULSEFIT logs sleep intervals and self-reported restfulness. We do not claim to measure sleep stages
          (REM, deep, light) without a verified connected medical-grade polysomnography or wearable sensor.
        </div>
      </div>

      {/* Primary Stat Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Nightly Sleep Duration</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2">
            {currentSleepHrs} <span className="text-xs font-normal text-[#94A3B8]">hrs</span>
          </div>
          <span className="text-[11px] text-[#CCFF00] font-mono mt-1 block">
            Target: {sleepGoalHrs} hrs ({sleepPct}%)
          </span>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Wellness Score</span>
          <div className="text-3xl font-black text-[#00F0FF] mt-2">
            {todayLog.wellness_score} <span className="text-xs font-normal text-[#94A3B8]">/ 100</span>
          </div>
          <span className="text-[11px] text-[#94A3B8] font-mono mt-1 block">
            Integrated energy vs stress
          </span>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Recorded Mood</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2 capitalize">
            {wellnessCheckins[0]?.mood || 'Good'}
          </div>
          <span className="text-[11px] text-[#94A3B8] font-mono mt-1 block">
            Daily check-in active
          </span>
        </Card>
      </div>

      {/* Daily Wellness Check-In Form */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Smile className="w-5 h-5 text-[#CCFF00]" />
            <CardTitle>Daily Wellness Check-In</CardTitle>
          </div>
          <Badge variant="cyan">Subjective Readiness</Badge>
        </CardHeader>

        <form onSubmit={handleSaveWellness} className="space-y-6">
          {/* Mood Selector */}
          <div>
            <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-2">
              Overall Mental & Physical Feeling
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { id: 'great', label: 'Great', emoji: '⚡' },
                { id: 'good', label: 'Good', emoji: '✨' },
                { id: 'okay', label: 'Okay', emoji: '⚖️' },
                { id: 'tired', label: 'Tired', emoji: '🥱' },
                { id: 'stressed', label: 'Stressed', emoji: '🔥' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMood(m.id as MoodType)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    mood === m.id
                      ? 'bg-[#182233] border-[#CCFF00] text-[#CCFF00]'
                      : 'bg-[#111827] border-[#1F2E45] text-[#94A3B8]'
                  }`}
                >
                  <span className="text-xl block mb-1">{m.emoji}</span>
                  <span className="text-xs font-bold">{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-medium text-[#94A3B8] uppercase tracking-wider">
                  Energy Level: {energyLevel} / 10
                </label>
                <Zap className="w-4 h-4 text-[#CCFF00]" />
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={energyLevel}
                onChange={(e) => setEnergyLevel(parseInt(e.target.value, 10))}
                className="w-full accent-[#CCFF00] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#64748B] font-mono mt-1">
                <span>1 (Exhausted)</span>
                <span>10 (Peak Vitality)</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-medium text-[#94A3B8] uppercase tracking-wider">
                  Stress & Tension Level: {stressLevel} / 10
                </label>
                <Heart className="w-4 h-4 text-orange-400" />
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={stressLevel}
                onChange={(e) => setStressLevel(parseInt(e.target.value, 10))}
                className="w-full accent-orange-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#64748B] font-mono mt-1">
                <span>1 (Calm & Grounded)</span>
                <span>10 (Extreme Tension)</span>
              </div>
            </div>
          </div>

          <Input
            label="Wellness Notes / Context"
            placeholder="e.g. Slept through without waking, feeling ready for leg workout"
            value={wellnessNotes}
            onChange={(e) => setWellnessNotes(e.target.value)}
          />

          <div className="flex justify-end">
            <Button type="submit" variant="primary">
              Save Wellness Check-In
            </Button>
          </div>
        </form>
      </Card>

      {/* Sleep Log Modal */}
      <Modal
        isOpen={isSleepModalOpen}
        onClose={() => setIsSleepModalOpen(false)}
        title="Log Sleep Schedule"
        description="Records your sleep and wake timestamps."
      >
        <form onSubmit={handleLogSleep} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Sleep Start (Lights Out)"
              type="time"
              value={sleepStart}
              onChange={(e) => setSleepStart(e.target.value)}
              required
            />
            <Input
              label="Wake Up Time"
              type="time"
              value={sleepEnd}
              onChange={(e) => setSleepEnd(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
              Subjective Restfulness: {sleepQuality}%
            </label>
            <input
              type="range"
              min="20"
              max="100"
              step="5"
              value={sleepQuality}
              onChange={(e) => setSleepQuality(parseInt(e.target.value, 10))}
              className="w-full accent-purple-400 cursor-pointer"
            />
          </div>

          <Input
            label="Notes"
            placeholder="e.g. Woke up once around 3am"
            value={sleepNotes}
            onChange={(e) => setSleepNotes(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsSleepModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Record Sleep
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
