'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import {
  Activity,
  Plus,
  Flame,
  Clock,
  Heart,
  TrendingUp,
  Dumbbell,
  CheckCircle2,
} from 'lucide-react';

export default function ActivityTrackerPage() {
  const { todayLog, completeWorkout, workoutHistory } = usePulseFit();

  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [activityName, setActivityName] = useState('Brisk Walking');
  const [durationMin, setDurationMin] = useState(30);
  const [perceivedExertion, setPerceivedExertion] = useState(5);
  const [notes, setNotes] = useState('');

  async function handleLogActivity(e: React.FormEvent) {
    e.preventDefault();
    await completeWorkout(
      activityName,
      durationMin,
      [{ exercise_name: activityName, sets_completed: 1, notes }],
      perceivedExertion,
      notes
    );
    setIsLogModalOpen(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Daily Activity & Sessions</h1>
            <Badge variant="lime">Exercise Log</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Track workouts, sports sessions, and perceived exertion ratings.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsLogModalOpen(true)}
          className="shadow-md shadow-[#CCFF00]/15"
        >
          <Plus className="w-4 h-4 mr-1.5" /> Log Exercise Session
        </Button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="sports-card p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
            <span>Total Active Minutes</span>
            <Clock className="w-4 h-4 text-[#CCFF00]" />
          </div>
          <div className="text-3xl font-black text-[#F8FAFC]">
            {todayLog.active_minutes} <span className="text-sm font-normal text-[#94A3B8]">min</span>
          </div>
        </Card>

        <Card className="sports-card p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
            <span>Estimated Active Energy</span>
            <Flame className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-3xl font-black text-[#F8FAFC]">
            {todayLog.active_calories} <span className="text-sm font-normal text-[#94A3B8]">kcal</span>
          </div>
        </Card>

        <Card className="sports-card p-5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1">
            <span>Distance Travelled</span>
            <Activity className="w-4 h-4 text-[#00F0FF]" />
          </div>
          <div className="text-3xl font-black text-[#F8FAFC]">
            {(todayLog.distance_meters / 1000).toFixed(2)}{' '}
            <span className="text-sm font-normal text-[#94A3B8]">km</span>
          </div>
        </Card>
      </div>

      {/* Activity Session Feed */}
      <Card className="sports-card p-6">
        <CardHeader>
          <CardTitle>Completed Workouts & Movement Sessions</CardTitle>
          <Badge variant="cyan">Chronological History</Badge>
        </CardHeader>

        <div className="space-y-3">
          {workoutHistory.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#94A3B8]">
              No active exercise bouts logged today yet. Tap &quot;Log Exercise Session&quot; to add a session.
            </div>
          ) : (
            workoutHistory.map((wh) => (
              <div
                key={wh.id}
                className="flex items-center justify-between p-4 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00]">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#F8FAFC]">{wh.workout_title}</h4>
                    <span className="text-xs text-[#94A3B8] block">
                      {wh.duration_minutes} min • ~{wh.calories_burned} kcal burned
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  {wh.perceived_exertion && (
                    <Badge variant="lime">RPE {wh.perceived_exertion}/10</Badge>
                  )}
                  <span className="block text-[10px] text-[#64748B] font-mono mt-1">
                    {new Date(wh.completed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Log Session Modal */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Completed Activity Session"
        description="Record duration and rate of perceived exertion (RPE)."
      >
        <form onSubmit={handleLogActivity} className="space-y-4">
          <Input
            label="Activity Name"
            value={activityName}
            onChange={(e) => setActivityName(e.target.value)}
            required
          />

          <Input
            label="Duration (Minutes)"
            type="number"
            min="5"
            max="300"
            value={durationMin}
            onChange={(e) => setDurationMin(parseInt(e.target.value, 10) || 0)}
            required
          />

          <div>
            <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
              Perceived Exertion (RPE 1-10): {perceivedExertion}
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={perceivedExertion}
              onChange={(e) => setPerceivedExertion(parseInt(e.target.value, 10))}
              className="w-full accent-[#CCFF00] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#64748B] font-mono mt-1">
              <span>1 (Very Easy)</span>
              <span>5 (Moderate)</span>
              <span>10 (Maximum Effort)</span>
            </div>
          </div>

          <Input
            label="Notes / Session Reflections"
            placeholder="e.g. Good leg energy, mild knee stiffness"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsLogModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Session
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
