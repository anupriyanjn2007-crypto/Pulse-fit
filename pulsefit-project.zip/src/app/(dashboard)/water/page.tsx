'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Modal } from '@/components/ui/modal';
import {
  Droplets,
  Plus,
  History,
  Sparkles,
  CupSoda,
  CheckCircle2,
} from 'lucide-react';

export default function WaterTrackerPage() {
  const { todayLog, goals, waterLogs, addWaterLog, updateWaterGoal } = usePulseFit();

  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [newGoal, setNewGoal] = useState<number>(goals?.daily_water_goal_ml || 2500);

  const [customMl, setCustomMl] = useState<number>(300);
  const [beverageType, setBeverageType] = useState('Water');

  const waterGoal = goals?.daily_water_goal_ml || 2500;
  const currentWater = todayLog.water_ml;
  const pct = Math.min(100, Math.round((currentWater / waterGoal) * 100));

  async function handleUpdateGoal(e: React.FormEvent) {
    e.preventDefault();
    if (newGoal <= 500) return;
    await updateWaterGoal(newGoal);
    setIsGoalModalOpen(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Hydration & Water Tracking</h1>
            <Badge variant="cyan">Daily Intake</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Maintain cellular hydration and energy balance with quick intake logging.
          </p>
        </div>

        <Button variant="outline" size="sm" onClick={() => setIsGoalModalOpen(true)}>
          Adjust Goal ({waterGoal} ml)
        </Button>
      </div>

      {/* Hero Hydration Gauge Card */}
      <Card className="sports-card p-6 sm:p-8 bg-gradient-to-r from-[#111827] via-[#182233] to-[#111827]">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center sm:text-left">
            <span className="text-xs uppercase tracking-wider text-[#00F0FF] font-bold">
              Today&apos;s Hydration Level
            </span>
            <div className="flex items-baseline gap-2 justify-center sm:justify-start">
              <span className="text-5xl font-black text-[#00F0FF]">{currentWater.toLocaleString()}</span>
              <span className="text-sm text-[#94A3B8] font-mono">/ {waterGoal.toLocaleString()} ml</span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              {currentWater >= waterGoal
                ? 'Hydration goal achieved for the day! Keep sipping mindfully.'
                : `${(waterGoal - currentWater).toLocaleString()} ml remaining to hit target.`}
            </p>
          </div>

          {/* Quick-Add Buttons Grid */}
          <div className="grid grid-cols-3 gap-3 w-full sm:w-auto">
            <button
              onClick={() => addWaterLog(250, 'Water')}
              className="p-3.5 rounded-xl bg-[#111827] border border-[#1F2E45] hover:border-[#00F0FF] text-center transition-all group"
            >
              <Droplets className="w-5 h-5 text-[#00F0FF] mx-auto mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-bold text-[#F8FAFC] block">+250 ml</span>
              <span className="text-[10px] text-[#64748B]">Glass</span>
            </button>

            <button
              onClick={() => addWaterLog(500, 'Water')}
              className="p-3.5 rounded-xl bg-[#111827] border border-[#1F2E45] hover:border-[#00F0FF] text-center transition-all group"
            >
              <Droplets className="w-5 h-5 text-[#00F0FF] mx-auto mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-bold text-[#F8FAFC] block">+500 ml</span>
              <span className="text-[10px] text-[#64748B]">Bottle</span>
            </button>

            <button
              onClick={() => addWaterLog(750, 'Water')}
              className="p-3.5 rounded-xl bg-[#111827] border border-[#1F2E45] hover:border-[#00F0FF] text-center transition-all group"
            >
              <Droplets className="w-5 h-5 text-[#00F0FF] mx-auto mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-bold text-[#F8FAFC] block">+750 ml</span>
              <span className="text-[10px] text-[#64748B]">Flask</span>
            </button>
          </div>
        </div>

        <div className="mt-6">
          <Progress value={pct} color="cyan" className="h-3" />
        </div>
      </Card>

      {/* Beverage Custom Add & Regional Hydration Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="sports-card p-6">
          <CardHeader>
            <CardTitle>Log Specific Beverage</CardTitle>
          </CardHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {[
                { name: 'Water', ml: 300 },
                { name: 'Neer Mor (Buttermilk)', ml: 250 },
                { name: 'Tender Coconut Water', ml: 300 },
                { name: 'Herbal Tea / Jeera Water', ml: 200 },
              ].map((bev) => (
                <button
                  key={bev.name}
                  onClick={() => addWaterLog(bev.ml, bev.name)}
                  className="p-3 rounded-xl bg-[#182233] border border-[#1F2E45] hover:border-[#00F0FF] text-left text-xs font-semibold"
                >
                  <span className="text-[#F8FAFC] block truncate">{bev.name}</span>
                  <span className="text-[#00F0FF] font-mono mt-1 block">+{bev.ml} ml</span>
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Hydration Insights Card */}
        <Card className="sports-card p-6">
          <CardHeader>
            <CardTitle>Hydration Biomechanics</CardTitle>
          </CardHeader>
          <ul className="space-y-3 text-xs text-[#94A3B8]">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Electrolyte Balance:</strong> Beverages like Neer Mor provide sodium
                and potassium, accelerating rehydration after exercise sessions.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
              <span>
                <strong className="text-[#F8FAFC]">Morning Primer:</strong> Drinking 500ml upon waking offsets overnight
                respiratory water loss and stimulates digestive peristalsis.
              </span>
            </li>
          </ul>
        </Card>
      </div>

      {/* Water History */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#00F0FF]" />
            <CardTitle>Today&apos;s Hydration Timestamp History</CardTitle>
          </div>
        </CardHeader>

        <div className="space-y-2.5">
          {waterLogs.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#94A3B8]">
              No individual hydration entries logged yet today.
            </div>
          ) : (
            waterLogs.map((log) => (
              <div
                key={log.id}
                className="flex items-center justify-between p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3">
                  <Droplets className="w-4 h-4 text-[#00F0FF]" />
                  <div>
                    <span className="text-sm font-bold text-[#F8FAFC]">+{log.amount_ml} ml</span>
                    <span className="text-xs text-[#94A3B8] block">{log.beverage_type}</span>
                  </div>
                </div>
                <span className="text-xs text-[#94A3B8] font-mono">
                  {new Date(log.logged_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Adjust Target Modal */}
      <Modal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        title="Adjust Hydration Goal"
        description="Configure your daily water target in milliliters."
      >
        <form onSubmit={handleUpdateGoal} className="space-y-4">
          <Input
            label="Daily Target (ml)"
            type="number"
            min="1000"
            max="6000"
            step="100"
            value={newGoal}
            onChange={(e) => setNewGoal(parseInt(e.target.value, 10) || 2500)}
            required
          />
          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsGoalModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Goal
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
