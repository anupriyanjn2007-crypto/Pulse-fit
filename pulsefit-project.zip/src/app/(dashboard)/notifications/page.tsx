'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Bell,
  Droplets,
  Dumbbell,
  Footprints,
  Moon,
  CheckSquare,
  Scale,
  Calendar,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

export default function NotificationsPage() {
  const { reminders, toggleReminder } = usePulseFit();
  const [pushStatus, setPushStatus] = useState<string>('default');

  const defaultReminders = [
    { type: 'water', label: 'Hydration Pacing Alerts', desc: 'Prompts to drink water at 10:00 AM, 02:00 PM, and 05:00 PM', icon: Droplets, time: '10:00 AM', enabled: true },
    { type: 'workout', label: 'Scheduled Workout Sessions', desc: 'Reminder 30 minutes before your planned exercise window', icon: Dumbbell, time: '05:00 PM', enabled: true },
    { type: 'walking', label: 'Movement & Posture Break', desc: 'Gentle nudges to stand and walk after prolonged sitting', icon: Footprints, time: '02:30 PM', enabled: true },
    { type: 'checklist', label: 'Daily Routine Check-In', desc: 'Morning habit prompt and evening review notification', icon: CheckSquare, time: '08:00 AM', enabled: true },
    { type: 'sleep', label: 'Screen Wind-Down & Sleep', desc: 'Pre-bedtime reminder to disconnect from blue light screens', icon: Moon, time: '10:15 PM', enabled: true },
    { type: 'weight', label: 'Weekly Measurement Review', desc: 'Weekly morning weigh-in notification (Sundays)', icon: Scale, time: '07:30 AM', enabled: false },
  ];

  async function requestBrowserPush() {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const permission = await Notification.requestPermission();
      setPushStatus(permission);
      if (permission === 'granted') {
        new Notification('PULSEFIT Athletic Engine', {
          body: 'Browser push notifications active. You will receive gentle reminders.',
          icon: '/favicon.ico',
        });
      }
    }
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Smart Reminders & Notifications</h1>
            <Badge variant="lime">User Controlled</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Configure in-app and browser notifications. We never send spam or promotional emails.
          </p>
        </div>

        <Button variant="outline" size="sm" onClick={requestBrowserPush}>
          <Bell className="w-3.5 h-3.5 mr-1 text-[#00F0FF]" /> Enable Push Notifications
        </Button>
      </div>

      {pushStatus === 'granted' && (
        <div className="p-3.5 rounded-xl bg-[#00F0FF]/10 border border-[#00F0FF]/30 text-xs text-[#00F0FF] flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Browser push notification permission is granted and active.</span>
        </div>
      )}

      {/* Reminders List */}
      <Card className="sports-card p-6 space-y-4">
        <CardHeader>
          <CardTitle>Configured Habit Alert Schedules</CardTitle>
          <Badge variant="cyan">Zero Spam Guarantee</Badge>
        </CardHeader>

        <div className="space-y-3">
          {defaultReminders.map((rem) => {
            const Icon = rem.icon;
            return (
              <div
                key={rem.type}
                className="flex items-center justify-between p-4 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-[#111827] border border-[#1F2E45] flex items-center justify-center text-[#CCFF00]">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#F8FAFC]">{rem.label}</h4>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{rem.desc}</p>
                    <span className="text-[10px] text-[#64748B] font-mono mt-1 block">
                      Scheduled: {rem.time}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-[#94A3B8] hidden sm:inline">
                    {rem.enabled ? 'Active' : 'Muted'}
                  </span>
                  <input
                    type="checkbox"
                    defaultChecked={rem.enabled}
                    className="w-5 h-5 rounded border-[#1F2E45] bg-[#111827] text-[#CCFF00] focus:ring-[#CCFF00] cursor-pointer"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
