'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import { calculateBMI } from '@/lib/calculations/bmi';
import {
  Scale,
  Plus,
  History,
  TrendingUp,
  AlertCircle,
  ShieldCheck,
  Calendar,
} from 'lucide-react';

export default function BodyMetricsPage() {
  const { measurements, addMeasurement, profile } = usePulseFit();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [weightKg, setWeightKg] = useState<number>(measurements[0]?.weight_kg || 70);
  const [heightCm, setHeightCm] = useState<number>(measurements[0]?.height_cm || 175);
  const [waistCm, setWaistCm] = useState<number>(measurements[0]?.waist_cm || 80);
  const [bodyFat, setBodyFat] = useState<number>(measurements[0]?.body_fat_pct || 18);
  const [notes, setNotes] = useState('');

  const latest = measurements[0] || {
    weight_kg: 70,
    height_cm: 175,
    bmi: 22.9,
    bmi_category: 'Normal weight',
    is_minor: false,
  };

  const bmiAnalysis = calculateBMI(latest.weight_kg, latest.height_cm, profile?.age);

  async function handleAddMeasurement(e: React.FormEvent) {
    e.preventDefault();
    if (weightKg <= 0 || heightCm <= 0) return;
    await addMeasurement(weightKg, heightCm, waistCm || undefined, bodyFat || undefined, notes);
    setIsModalOpen(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Body Measurements & BMI</h1>
            <Badge variant="lime">Biometric Profile</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Track weight, body mass index, and waist dimensions with age-appropriate safety.
          </p>
        </div>

        <Button variant="primary" size="sm" onClick={() => setIsModalOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> Log New Measurement
        </Button>
      </div>

      {/* Hero Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Current Weight</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2">
            {latest.weight_kg} <span className="text-xs font-normal text-[#94A3B8]">kg</span>
          </div>
          <div className="text-[11px] text-[#CCFF00] font-mono mt-1">Latest Logged Snapshot</div>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Height</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2">
            {latest.height_cm} <span className="text-xs font-normal text-[#94A3B8]">cm</span>
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-1">
            {(latest.height_cm / 100).toFixed(2)} meters
          </div>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Body Mass Index</span>
          <div className="text-3xl font-black text-[#00F0FF] mt-2">{bmiAnalysis.bmi}</div>
          <div className="mt-1">
            <Badge variant={bmiAnalysis.isMinor ? 'cyan' : 'lime'}>{bmiAnalysis.category}</Badge>
          </div>
        </Card>

        <Card className="sports-card p-5">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Waist Circumference</span>
          <div className="text-3xl font-black text-[#F8FAFC] mt-2">
            {latest.waist_cm ? `${latest.waist_cm} cm` : 'Not recorded'}
          </div>
          <div className="text-[11px] text-[#94A3B8] font-mono mt-1">Optional visceral indicator</div>
        </Card>
      </div>

      {/* Clinical Guidance Box */}
      <Card className={`sports-card p-6 border-[#1F2E45] ${bmiAnalysis.bgColor}`}>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-[#111827] border border-[#1F2E45] flex items-center justify-center text-[#CCFF00] shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#F8FAFC]">
                BMI Screening Explanation
              </span>
              <span className="text-[10px] text-[#94A3B8] font-mono">Formula: kg / m²</span>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">{bmiAnalysis.explanation}</p>

            {bmiAnalysis.healthyWeightRange && (
              <p className="text-xs text-[#CCFF00] font-mono pt-1">
                Reference healthy range for adult height ({latest.height_cm} cm):{' '}
                {bmiAnalysis.healthyWeightRange.minKg} kg – {bmiAnalysis.healthyWeightRange.maxKg} kg
              </p>
            )}

            {bmiAnalysis.warning && (
              <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold pt-1">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{bmiAnalysis.warning}</span>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* History of Measurements */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#CCFF00]" />
            <CardTitle>Immutable Measurement History</CardTitle>
          </div>
          <Badge variant="cyan">Preserved Snapshots</Badge>
        </CardHeader>

        <div className="space-y-3">
          {measurements.map((m) => (
            <div
              key={m.id}
              className="flex items-center justify-between p-4 rounded-xl bg-[#182233] border border-[#1F2E45]"
            >
              <div className="flex items-center gap-3.5">
                <Scale className="w-4 h-4 text-[#CCFF00]" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#F8FAFC]">{m.weight_kg} kg</span>
                    <span className="text-xs text-[#94A3B8]">({m.height_cm} cm)</span>
                  </div>
                  <span className="text-xs text-[#94A3B8]">
                    BMI: {m.bmi} • {m.bmi_category}
                    {m.notes ? ` • ${m.notes}` : ''}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-[#94A3B8] font-mono block">
                  {new Date(m.measured_at).toLocaleDateString()}
                </span>
                <span className="text-[10px] text-[#64748B] font-mono">
                  {new Date(m.measured_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Log Measurement Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Log New Body Measurement"
        description="Records a new historical snapshot. Prior logs remain untouched."
      >
        <form onSubmit={handleAddMeasurement} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Weight (kg)"
              type="number"
              step="0.1"
              value={weightKg}
              onChange={(e) => setWeightKg(parseFloat(e.target.value) || 0)}
              required
            />
            <Input
              label="Height (cm)"
              type="number"
              value={heightCm}
              onChange={(e) => setHeightCm(parseFloat(e.target.value) || 0)}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Waist (cm, optional)"
              type="number"
              value={waistCm}
              onChange={(e) => setWaistCm(parseFloat(e.target.value) || 0)}
            />
            <Input
              label="Body Fat % (optional)"
              type="number"
              step="0.1"
              value={bodyFat}
              onChange={(e) => setBodyFat(parseFloat(e.target.value) || 0)}
            />
          </div>

          <Input
            label="Notes"
            placeholder="e.g. Measured first thing morning"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Measurement
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
