'use client';

import React, { useState, useRef, useEffect } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Bot,
  Send,
  Trash2,
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  User,
  Heart,
  Dumbbell,
  Utensils,
  Footprints,
} from 'lucide-react';

export default function AICoachPage() {
  const {
    aiMessages,
    sendAIMessage,
    pendingNaturalLog,
    confirmNaturalLog,
    discardNaturalLog,
    clearAIConversation,
    profile,
    todayLog,
    goals,
    preferences,
  } = usePulseFit();

  const [inputPrompt, setInputPrompt] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiMessages, pendingNaturalLog]);

  async function handleSendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!inputPrompt.trim() || isSubmitting) return;

    const text = inputPrompt;
    setInputPrompt('');
    setIsSubmitting(true);
    await sendAIMessage(text);
    setIsSubmitting(false);
  }

  function handleQuickPrompt(promptText: string) {
    setInputPrompt(promptText);
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto flex flex-col h-[calc(100vh-8.5rem)]">
      {/* Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">AI Personal Fitness Coach</h1>
            <Badge variant="lime">Context-Aware</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-0.5">
            Personalized guidance grounded in your measurements and logged activity.
          </p>
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={clearAIConversation}
          className="text-xs text-[#64748B] hover:text-red-400"
          title="Clear Conversation"
        >
          <Trash2 className="w-3.5 h-3.5 mr-1" /> Clear Chat
        </Button>
      </div>

      {/* Safety Notice Banner */}
      <div className="p-3 rounded-xl bg-[#182233] border border-[#1F2E45] flex items-center justify-between text-xs text-[#94A3B8] shrink-0">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#00F0FF] shrink-0" />
          <span>
            PULSEFIT Coach is an intelligent wellness assistant, not a doctor. In an emergency, call emergency services.
          </span>
        </div>
        <span className="hidden sm:inline text-[10px] text-[#CCFF00] font-mono">
          Minor Safety Guard Active
        </span>
      </div>

      {/* Chat Messages Container */}
      <Card className="sports-card flex-1 p-4 sm:p-6 overflow-y-auto flex flex-col space-y-4">
        {aiMessages.length === 0 ? (
          <div className="my-auto text-center py-10 max-w-md mx-auto space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-[#00F0FF]/15 flex items-center justify-center text-[#00F0FF] mx-auto border border-[#00F0FF]/30">
              <Bot className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#F8FAFC]">
                Welcome, {profile?.full_name?.split(' ')[0] || 'Athlete'}
              </h3>
              <p className="text-xs text-[#94A3B8] mt-1 leading-relaxed">
                I am your personal fitness companion. I can suggest customized workouts, answer nutrition questions for{' '}
                {preferences?.cuisine_preferences?.join(', ') || 'Tamil Nadu'} cuisine, or log data with natural language!
              </p>
            </div>

            {/* Quick Prompt Suggestions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left pt-2">
              <button
                type="button"
                onClick={() => handleQuickPrompt('What workout should I do today with dumbbells?')}
                className="p-2.5 rounded-xl bg-[#182233] border border-[#1F2E45] hover:border-[#CCFF00] text-xs text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
              >
                <Dumbbell className="w-3.5 h-3.5 text-[#CCFF00] mb-1" />
                What workout should I do today?
              </button>
              <button
                type="button"
                onClick={() => handleQuickPrompt('Give me a high-protein Tamil Nadu vegetarian dinner idea.')}
                className="p-2.5 rounded-xl bg-[#182233] border border-[#1F2E45] hover:border-[#00F0FF] text-xs text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
              >
                <Utensils className="w-3.5 h-3.5 text-[#00F0FF] mb-1" />
                Tamil Nadu meal recommendation
              </button>
              <button
                type="button"
                onClick={() => handleQuickPrompt('I walked 4,000 steps this morning.')}
                className="p-2.5 rounded-xl bg-[#182233] border border-[#1F2E45] hover:border-[#CCFF00] text-xs text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
              >
                <Footprints className="w-3.5 h-3.5 text-[#CCFF00] mb-1" />
                &quot;I walked 4,000 steps this morning&quot;
              </button>
              <button
                type="button"
                onClick={() => handleQuickPrompt('Drank 500 ml water.')}
                className="p-2.5 rounded-xl bg-[#182233] border border-[#1F2E45] hover:border-[#00F0FF] text-xs text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#00F0FF] mb-1" />
                &quot;Drank 500 ml water&quot;
              </button>
            </div>
          </div>
        ) : (
          aiMessages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role !== 'user' && (
                <div className="w-8 h-8 rounded-xl bg-[#00F0FF]/15 flex items-center justify-center text-[#00F0FF] shrink-0 border border-[#00F0FF]/30 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-[#CCFF00] text-black font-medium shadow-md'
                    : 'bg-[#182233] text-[#F8FAFC] border border-[#1F2E45]'
                }`}
              >
                <div className="whitespace-pre-line">{msg.content}</div>
                <span
                  className={`block text-[10px] mt-2 font-mono ${
                    msg.role === 'user' ? 'text-black/60 text-right' : 'text-[#64748B]'
                  }`}
                >
                  {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-[#CCFF00]/20 flex items-center justify-center text-[#CCFF00] shrink-0 border border-[#CCFF00]/40 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))
        )}

        {/* Pending Natural Language Confirmation Dialog */}
        {pendingNaturalLog && (
          <div className="p-4 rounded-xl bg-[#111827] border-2 border-[#CCFF00] shadow-xl animate-fade-in my-2">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-[#CCFF00] shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="text-xs font-bold uppercase tracking-wider text-[#CCFF00]">
                  Natural Language Entry Detected
                </span>
                <p className="text-xs text-[#F8FAFC] mt-1 font-medium">
                  {pendingNaturalLog.confirmation_prompt}
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={confirmNaturalLog}
                    className="text-xs px-3 py-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Confirm & Log
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={discardNaturalLog}
                    className="text-xs px-3 py-1.5 text-[#94A3B8]"
                  >
                    Discard
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {isSubmitting && (
          <div className="flex items-center gap-2 text-xs text-[#94A3B8] p-2 font-mono">
            <span className="w-2 h-2 rounded-full bg-[#00F0FF] animate-ping" />
            <span>AI Coach is synthesizing biological context...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </Card>

      {/* Input Field */}
      <form onSubmit={handleSendMessage} className="flex items-center gap-2 shrink-0">
        <input
          type="text"
          placeholder="Ask a fitness question or type 'Walked 5,000 steps'..."
          value={inputPrompt}
          onChange={(e) => setInputPrompt(e.target.value)}
          disabled={isSubmitting}
          className="flex-1 bg-[#182233] border border-[#1F2E45] rounded-xl px-4 py-3 text-sm text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#CCFF00] focus:ring-1 focus:ring-[#CCFF00] transition-colors"
        />
        <Button
          type="submit"
          variant="primary"
          disabled={isSubmitting || !inputPrompt.trim()}
          className="px-5 py-3 h-auto"
        >
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
}
