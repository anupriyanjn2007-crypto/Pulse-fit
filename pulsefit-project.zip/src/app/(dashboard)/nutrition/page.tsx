'use client';

import React, { useState } from 'react';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Modal } from '@/components/ui/modal';
import { REGIONAL_FOOD_DATABASE, FoodItemDef } from '@/lib/data/tamil-nadu-foods';
import { MealLog } from '@/types/pulsefit';
import {
  Utensils,
  Plus,
  Sparkles,
  Info,
  CheckCircle2,
  Coffee,
  Sun,
  Sunset,
  Moon,
} from 'lucide-react';

export default function NutritionTrackerPage() {
  const { mealLogs, addMealLog, preferences } = usePulseFit();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [mealType, setMealType] = useState<MealLog['meal_type']>('breakfast');
  const [foodItems, setFoodItems] = useState('');
  const [estCalories, setEstCalories] = useState<number>(350);
  const [proteinG, setProteinG] = useState<number>(15);
  const [carbsG, setCarbsG] = useState<number>(45);
  const [fatG, setFatG] = useState<number>(10);
  const [notes, setNotes] = useState('');

  // Calculate totals
  const totalCalories = mealLogs.reduce((acc, m) => acc + (m.est_calories || 0), 0);
  const totalProtein = Math.round(mealLogs.reduce((acc, m) => acc + (m.est_protein_g || 0), 0));
  const totalCarbs = Math.round(mealLogs.reduce((acc, m) => acc + (m.est_carbs_g || 0), 0));
  const totalFat = Math.round(mealLogs.reduce((acc, m) => acc + (m.est_fat_g || 0), 0));

  async function handleAddMeal(e: React.FormEvent) {
    e.preventDefault();
    if (!foodItems.trim()) return;
    await addMealLog(mealType, foodItems, estCalories, proteinG, carbsG, fatG, notes);
    setFoodItems('');
    setNotes('');
    setIsModalOpen(false);
  }

  async function handleQuickAddRegionalFood(food: FoodItemDef) {
    await addMealLog(
      food.mealType,
      `${food.name} (${food.serving})`,
      food.estCalories,
      food.estProteinG,
      food.estCarbsG,
      food.estFatG,
      food.healthBenefits
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-[#F8FAFC]">Nutrition & Diet Tracking</h1>
            <Badge variant="lime">Regional & Whole Foods</Badge>
          </div>
          <p className="text-xs text-[#94A3B8] mt-1">
            Nutritional tracking with native support for Tamil Nadu and South Indian cuisines.
          </p>
        </div>

        <Button variant="primary" size="sm" onClick={() => setIsModalOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> Log Custom Meal
        </Button>
      </div>

      {/* Accuracy Disclosure Alert */}
      <div className="p-3.5 rounded-xl bg-[#182233] border border-[#1F2E45] flex items-start gap-3 text-xs text-[#94A3B8]">
        <Info className="w-4 h-4 text-[#00F0FF] shrink-0 mt-0.5" />
        <div>
          <span className="text-[#F8FAFC] font-semibold">Nutritional Transparency: </span>
          All calorie and macronutrient figures are approximations derived from standard food composition tables.
          Actual energy availability varies depending on cooking preparation, spices, and absorption.
        </div>
      </div>

      {/* Daily Macro Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="sports-card p-4">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Total Intake</span>
          <div className="text-2xl font-black text-[#F8FAFC] mt-1">
            {totalCalories} <span className="text-xs font-normal text-[#94A3B8]">kcal</span>
          </div>
          <span className="text-[10px] text-[#CCFF00] font-mono mt-0.5 block">Estimated total</span>
        </Card>

        <Card className="sports-card p-4">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Protein</span>
          <div className="text-2xl font-black text-[#00F0FF] mt-1">
            {totalProtein} <span className="text-xs font-normal text-[#94A3B8]">g</span>
          </div>
          <span className="text-[10px] text-[#94A3B8] font-mono mt-0.5 block">Muscle preservation</span>
        </Card>

        <Card className="sports-card p-4">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Carbohydrates</span>
          <div className="text-2xl font-black text-amber-400 mt-1">
            {totalCarbs} <span className="text-xs font-normal text-[#94A3B8]">g</span>
          </div>
          <span className="text-[10px] text-[#94A3B8] font-mono mt-0.5 block">Glycogen energy</span>
        </Card>

        <Card className="sports-card p-4">
          <span className="text-xs font-bold text-[#94A3B8] uppercase">Dietary Fat</span>
          <div className="text-2xl font-black text-purple-400 mt-1">
            {totalFat} <span className="text-xs font-normal text-[#94A3B8]">g</span>
          </div>
          <span className="text-[10px] text-[#94A3B8] font-mono mt-0.5 block">Hormonal balance</span>
        </Card>
      </div>

      {/* Regional Tamil Nadu Quick-Add Pantry */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div>
            <CardTitle>Regional Tamil Nadu & Indian Nourishing Staples</CardTitle>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              One-click logging for traditional fiber-dense and protein-rich meals.
            </p>
          </div>
          <Badge variant="cyan">Traditional Superfoods</Badge>
        </CardHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {REGIONAL_FOOD_DATABASE.map((food) => (
            <div
              key={food.id}
              className="p-4 rounded-xl bg-[#182233] border border-[#1F2E45] flex flex-col justify-between hover:border-[#CCFF00]/40 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <Badge variant={food.dietType === 'non_vegetarian' ? 'warning' : 'lime'}>
                    {food.dietType}
                  </Badge>
                  <span className="text-[10px] text-[#00F0FF] font-mono uppercase">{food.mealType}</span>
                </div>
                <h4 className="text-xs font-bold text-[#F8FAFC] leading-snug">{food.name}</h4>
                <p className="text-[11px] text-[#94A3B8] mt-1">{food.serving}</p>
                <div className="flex items-center gap-2 text-[11px] font-mono text-[#CCFF00] mt-2">
                  <span>~{food.estCalories} kcal</span>
                  <span>•</span>
                  <span>P: {food.estProteinG}g</span>
                  <span>•</span>
                  <span>C: {food.estCarbsG}g</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1F2E45] flex items-center justify-between">
                <span className="text-[10px] text-[#64748B] italic truncate max-w-[150px]">
                  {food.healthBenefits}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs py-1 px-2.5 h-auto"
                  onClick={() => handleQuickAddRegionalFood(food)}
                >
                  <Plus className="w-3 h-3 mr-1" /> Log
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Logged Meals List */}
      <Card className="sports-card p-6">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Utensils className="w-4 h-4 text-[#CCFF00]" />
            <CardTitle>Today&apos;s Logged Nutrition Diary</CardTitle>
          </div>
        </CardHeader>

        <div className="space-y-3">
          {mealLogs.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#94A3B8]">
              No meals logged today yet. Quick-add a regional dish above or log a custom meal.
            </div>
          ) : (
            mealLogs.map((meal) => (
              <div
                key={meal.id}
                className="flex items-center justify-between p-4 rounded-xl bg-[#182233] border border-[#1F2E45]"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-[#CCFF00]/15 flex items-center justify-center text-[#CCFF00]">
                    {meal.meal_type === 'breakfast' && <Coffee className="w-4 h-4" />}
                    {meal.meal_type === 'lunch' && <Sun className="w-4 h-4" />}
                    {meal.meal_type === 'snack' && <Sunset className="w-4 h-4" />}
                    {meal.meal_type === 'dinner' && <Moon className="w-4 h-4" />}
                  </div>
                  <div>
                    <span className="text-xs text-[#00F0FF] font-mono uppercase block">
                      {meal.meal_type}
                    </span>
                    <h4 className="text-sm font-bold text-[#F8FAFC]">{meal.food_items}</h4>
                    {meal.notes && <p className="text-xs text-[#94A3B8]">{meal.notes}</p>}
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-bold text-[#CCFF00] font-mono">
                    ~{meal.est_calories} kcal
                  </span>
                  <div className="text-[10px] text-[#94A3B8] font-mono">
                    P: {meal.est_protein_g}g • C: {meal.est_carbs_g}g • F: {meal.est_fat_g}g
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Custom Meal Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Log Custom Meal Intake"
        description="Enter foods consumed with estimated macros."
      >
        <form onSubmit={handleAddMeal} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#94A3B8] uppercase tracking-wider mb-1.5">
              Meal Schedule
            </label>
            <select
              value={mealType}
              onChange={(e) => setMealType(e.target.value as any)}
              className="w-full bg-[#182233] border border-[#1F2E45] rounded-xl px-3 py-2 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#CCFF00]"
            >
              <option value="breakfast">Breakfast</option>
              <option value="lunch">Lunch</option>
              <option value="snack">Evening Snack</option>
              <option value="dinner">Dinner</option>
            </select>
          </div>

          <Input
            label="Food Items & Quantity"
            placeholder="e.g. 2 whole eggs, 2 multigrain rotis, dal"
            value={foodItems}
            onChange={(e) => setFoodItems(e.target.value)}
            required
          />

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Input
              label="Calories (kcal)"
              type="number"
              value={estCalories}
              onChange={(e) => setEstCalories(parseInt(e.target.value, 10) || 0)}
            />
            <Input
              label="Protein (g)"
              type="number"
              value={proteinG}
              onChange={(e) => setProteinG(parseFloat(e.target.value) || 0)}
            />
            <Input
              label="Carbs (g)"
              type="number"
              value={carbsG}
              onChange={(e) => setCarbsG(parseFloat(e.target.value) || 0)}
            />
            <Input
              label="Fat (g)"
              type="number"
              value={fatG}
              onChange={(e) => setFatG(parseFloat(e.target.value) || 0)}
            />
          </div>

          <Input
            label="Notes / Dietary Satisfaction"
            placeholder="e.g. Felt energized, good satiety"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Meal
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
