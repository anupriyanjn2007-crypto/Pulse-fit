'use client';

import React from 'react';
import { Sidebar } from '@/components/layout/sidebar';
import { Header } from '@/components/layout/header';
import { MobileNav } from '@/components/layout/mobile-nav';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { useRouter } from 'next/navigation';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isOnboarded, isLoading } = usePulseFit();
  const router = useRouter();

  React.useEffect(() => {
    if (!isLoading && !isOnboarded) {
      router.push('/onboarding');
    }
  }, [isLoading, isOnboarded, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#090D14] flex flex-col items-center justify-center text-[#F8FAFC]">
        <div className="w-12 h-12 rounded-2xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-2xl animate-pulse mb-4">
          ⚡
        </div>
        <p className="text-sm font-mono text-[#94A3B8]">Loading PulseFit Athletic Engine...</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#090D14] text-[#F8FAFC]">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full pb-24 lg:pb-12">
          {children}
        </main>
        <MobileNav />
      </div>
    </div>
  );
}
