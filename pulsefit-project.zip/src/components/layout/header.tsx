'use client';

import React from 'react';
import Link from 'next/link';
import { usePulseFit } from '@/lib/store/pulsefit-store';
import { Flame, Bell, Bot, ShieldCheck, User } from 'lucide-react';

export function Header() {
  const { profile, currentStreak, todayLog, devices } = usePulseFit();

  const [formattedDate, setFormattedDate] = React.useState('Today');

  React.useEffect(() => {
    setFormattedDate(
      new Date().toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      })
    );
  }, []);

  const activeSensors = devices.filter((d) => d.status === 'connected');

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 py-3.5 bg-[#090D14]/90 backdrop-blur-md border-b border-[#1F2E45]">
      {/* Left: Greeting & Date */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-base sm:text-lg font-bold text-[#F8FAFC]">
            Hey, {profile?.full_name ? profile.full_name.split(' ')[0] : 'Athlete'}
          </h1>
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#CCFF00]/15 text-[#CCFF00] border border-[#CCFF00]/30">
            <Flame className="w-3 h-3 fill-[#CCFF00]" />
            {currentStreak} Day Streak
          </span>
        </div>
        <p className="text-xs text-[#94A3B8] font-mono">{formattedDate}</p>
      </div>

      {/* Right: Quick Actions & Status */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Device Status Pill */}
        <Link
          href="/devices"
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#182233] border border-[#1F2E45] text-[11px] text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
          title="Hardware and Sensor Status"
        >
          <span
            className={`w-2 h-2 rounded-full ${
              activeSensors.length > 0 ? 'bg-[#CCFF00] shadow-[0_0_8px_#CCFF00]' : 'bg-[#64748B]'
            }`}
          />
          <span>{activeSensors.length > 0 ? 'Sensor Active' : 'No Devices'}</span>
        </Link>

        {/* AI Coach Quick Access */}
        <Link
          href="/coach"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#182233] border border-[#00F0FF]/40 text-[#00F0FF] text-xs font-semibold hover:bg-[#00F0FF]/10 transition-colors shadow-sm"
        >
          <Bot className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">AI Coach</span>
        </Link>

        {/* Notifications */}
        <Link
          href="/notifications"
          className="relative p-2 rounded-xl bg-[#182233] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#1F2E45] transition-colors"
          title="Reminders & Notifications"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#CCFF00]" />
        </Link>

        {/* User Profile Avatar */}
        <Link
          href="/settings"
          className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-br from-[#CCFF00]/30 to-[#00F0FF]/30 border border-[#CCFF00]/50 text-xs font-bold text-[#F8FAFC] hover:scale-105 transition-transform"
          title="Profile & Settings"
        >
          {profile?.full_name ? profile.full_name.charAt(0).toUpperCase() : <User className="w-4 h-4" />}
        </Link>
      </div>
    </header>
  );
}
