'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Activity,
  CheckSquare,
  Footprints,
  Dumbbell,
  Scale,
  Utensils,
  Droplets,
  Moon,
  Bot,
  BarChart3,
  Calendar,
  Award,
  Bell,
  Cpu,
  ShieldCheck,
  Settings,
  Zap,
} from 'lucide-react';
import { clsx } from 'clsx';

export const NAV_LINKS = [
  { href: '/dashboard', label: 'Dashboard', icon: Activity, section: 'Overview' },
  { href: '/checklist', label: 'Daily Checklist', icon: CheckSquare, section: 'Daily Tracking' },
  { href: '/steps', label: 'Step Tracker', icon: Footprints, section: 'Daily Tracking' },
  { href: '/workouts', label: 'Workout Planner', icon: Dumbbell, section: 'Fitness' },
  { href: '/exercises', label: 'Exercise Library', icon: Zap, section: 'Fitness' },
  { href: '/body', label: 'Body Metrics', icon: Scale, section: 'Health' },
  { href: '/weight', label: 'Weight Goal', icon: Scale, section: 'Health' },
  { href: '/nutrition', label: 'Nutrition & Diet', icon: Utensils, section: 'Health' },
  { href: '/water', label: 'Water Tracker', icon: Droplets, section: 'Health' },
  { href: '/sleep', label: 'Sleep & Wellness', icon: Moon, section: 'Health' },
  { href: '/coach', label: 'AI Coach', icon: Bot, section: 'Intelligence', badge: 'AI' },
  { href: '/analytics', label: 'Analytics', icon: BarChart3, section: 'Reports' },
  { href: '/calendar', label: 'Calendar', icon: Calendar, section: 'Reports' },
  { href: '/achievements', label: 'Achievements', icon: Award, section: 'Motivation' },
  { href: '/notifications', label: 'Reminders', icon: Bell, section: 'System' },
  { href: '/devices', label: 'Connected Devices', icon: Cpu, section: 'System' },
  { href: '/privacy', label: 'Privacy & Data', icon: ShieldCheck, section: 'System' },
  { href: '/settings', label: 'Settings', icon: Settings, section: 'System' },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-[#090D14] border-r border-[#1F2E45] min-h-screen p-4 sticky top-0 h-screen overflow-y-auto">
      {/* Brand Header */}
      <Link href="/dashboard" className="flex items-center gap-2.5 px-3 py-3 mb-4 group">
        <div className="w-9 h-9 rounded-xl bg-[#CCFF00] flex items-center justify-center text-black font-black text-xl shadow-md group-hover:scale-105 transition-transform">
          ⚡
        </div>
        <div>
          <span className="text-xl font-black tracking-tight text-[#F8FAFC]">
            PULSE<span className="text-[#CCFF00]">FIT</span>
          </span>
          <span className="block text-[10px] text-[#94A3B8] font-mono tracking-widest uppercase">
            AI ATHLETIC ENGINE
          </span>
        </div>
      </Link>

      {/* Navigation Sections */}
      <nav className="flex-1 space-y-1">
        {NAV_LINKS.map((link) => {
          const isActive = pathname === link.href;
          const Icon = link.icon;

          return (
            <Link
              key={link.href}
              href={link.href}
              className={clsx(
                'flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-150',
                isActive
                  ? 'bg-[#182233] text-[#CCFF00] font-semibold border-l-2 border-[#CCFF00]'
                  : 'text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#111827]'
              )}
            >
              <div className="flex items-center gap-3">
                <Icon className={clsx('w-4 h-4', isActive ? 'text-[#CCFF00]' : 'text-[#64748B]')} />
                <span>{link.label}</span>
              </div>
              {link.badge && (
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-[#CCFF00]/20 text-[#CCFF00] border border-[#CCFF00]/40">
                  {link.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Privacy Badge */}
      <div className="mt-auto pt-4 border-t border-[#1F2E45]/60 px-3">
        <div className="flex items-center gap-2 text-[11px] text-[#64748B]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#00F0FF]" />
          <span>Private Account (RLS Protected)</span>
        </div>
      </div>
    </aside>
  );
}
