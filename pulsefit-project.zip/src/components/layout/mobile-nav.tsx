'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Activity, CheckSquare, Footprints, Dumbbell, Bot } from 'lucide-react';
import { clsx } from 'clsx';

export function MobileNav() {
  const pathname = usePathname();

  const primaryMobileLinks = [
    { href: '/dashboard', label: 'Home', icon: Activity },
    { href: '/steps', label: 'Steps', icon: Footprints },
    { href: '/checklist', label: 'Checklist', icon: CheckSquare },
    { href: '/workouts', label: 'Workout', icon: Dumbbell },
    { href: '/coach', label: 'AI Coach', icon: Bot, isAccent: true },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#090D14]/95 backdrop-blur-lg border-t border-[#1F2E45] px-2 py-2 flex items-center justify-around safe-area-inset-bottom">
      {primaryMobileLinks.map((link) => {
        const isActive = pathname === link.href;
        const Icon = link.icon;

        return (
          <Link
            key={link.href}
            href={link.href}
            className={clsx(
              'flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all',
              isActive
                ? 'text-[#CCFF00]'
                : link.isAccent
                ? 'text-[#00F0FF]'
                : 'text-[#94A3B8] hover:text-[#F8FAFC]'
            )}
          >
            <div
              className={clsx(
                'p-1 rounded-lg transition-transform',
                isActive && 'bg-[#CCFF00]/15 scale-110',
                link.isAccent && !isActive && 'bg-[#00F0FF]/15'
              )}
            >
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium tracking-tight mt-0.5">{link.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
