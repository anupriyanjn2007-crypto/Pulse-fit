import * as React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'lime' | 'cyan' | 'neutral' | 'warning' | 'danger' | 'outline';
}

export function Badge({
  className,
  variant = 'lime',
  children,
  ...props
}: BadgeProps) {
  const variants = {
    lime: 'bg-[#CCFF00]/15 text-[#CCFF00] border-[#CCFF00]/30',
    cyan: 'bg-[#00F0FF]/15 text-[#00F0FF] border-[#00F0FF]/30',
    neutral: 'bg-[#182233] text-[#94A3B8] border-[#1F2E45]',
    warning: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    danger: 'bg-red-500/15 text-red-400 border-red-500/30',
    outline: 'border border-[#1F2E45] text-[#F8FAFC]',
  };

  return (
    <span
      className={twMerge(
        clsx(
          'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border tracking-wide uppercase',
          variants[variant],
          className
        )
      )}
      {...props}
    >
      {children}
    </span>
  );
}
