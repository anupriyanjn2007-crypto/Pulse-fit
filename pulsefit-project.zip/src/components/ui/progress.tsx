import * as React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number; // 0 to 100
  color?: 'lime' | 'cyan' | 'gradient';
}

export function Progress({
  value,
  color = 'lime',
  className,
  ...props
}: ProgressProps) {
  const clamped = Math.min(100, Math.max(0, value));

  const colorStyles = {
    lime: 'bg-[#CCFF00]',
    cyan: 'bg-[#00F0FF]',
    gradient: 'bg-gradient-to-r from-[#CCFF00] to-[#00F0FF]',
  };

  return (
    <div
      className={twMerge(clsx('w-full bg-[#182233] rounded-full h-2.5 overflow-hidden', className))}
      {...props}
    >
      <div
        className={twMerge(clsx('h-full transition-all duration-500 ease-out rounded-full', colorStyles[color]))}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
